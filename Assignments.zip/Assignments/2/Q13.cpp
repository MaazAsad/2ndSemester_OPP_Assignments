#include<iostream>
using namespace std;


bool isSafe(int** board, int row, int col,int N)
{
    int rowcheck, colcheck;
    for (rowcheck = 0; rowcheck < col; rowcheck++)
        if (board[row][rowcheck])
            return false;

    for (rowcheck=row, colcheck=col; rowcheck>=0 && colcheck>=0; rowcheck--, colcheck--)
        if (board[rowcheck][colcheck])
            return false;

    for (rowcheck=row, colcheck=col; colcheck>=0 && rowcheck<N; rowcheck++, colcheck--)
        if (board[rowcheck][colcheck])
            return false;

    return true;
}

bool solveNQUtil(int **board, int N, int col){

    if (col >= N)
        return true;

    for (int i = 0; i < N; i++)
    {
        if ( isSafe(board, i, col,N) )
        {
            board[i][col] = 1;
            if ( solveNQUtil(board,N, col + 1) )
                return true;
            board[i][col] = 0;
        }
    }
    return false;
}



int main(){
    int ** board = new int*[5];
    for (int i = 0; i < 5; i++)
    {
    board[i] = new int[5];
    for (int j = 0; j < 5; j++)
    board[i][j] = 0;
    }
    return 0;
}
