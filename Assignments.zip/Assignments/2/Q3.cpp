#include<iostream>
using namespace std;


char findUpperCase(char *s, int index){
    if(*s){
        if(*s >= 'A' && *s <= 'Z'){
            return *s;
        }
        else{
            return Upper(s+1);
        }
    }

    return '\0';
}

// int main(){
//
//     char a[6]="hllPo";
//     cout<< Upper(a) << endl;
//
//     return 0;
// }
