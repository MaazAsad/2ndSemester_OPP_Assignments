void SumWelp(int** one2darray, int row,int columns, int &oddsum, int &evensum){
    if(columns-1 >=0){
        if(one2darray[row-1][column-1]%2 == 0){
            evenSum += one2darray[row-1][columns-1];

        }
        else{
            oddSum += one2darray[row-1][columns-1];
        }
    }
    SumWelp(one2darray,row, columns-1,oddSum,evenSum);
}

void calculateSum(int **matrix1, int row, int column, int &evenSum, int &oddSum)
{

    if(row-1>=0){
        SumWelp(matrix1,row,column,oddSum,evenSum);
        calculateSum(matrix1,row-1,column,evenSum,oddSum);
    }


}
