#include<iostream>
#include<fstream>
using namespace std;
void printChar(char ch,int t,fstream &output){
    if(t>0){
        cout << ch;
        printChar(ch,t-1,output);
    }
}
void printPattern2(int mline, int startLine, int space, fstream &output)
{
    if(startLine<space+mline+1){
        printChar(' ',space-1,output);
        printChar('*',startLine,output);
        cout << endl;
        printPattern2(mline,startLine+2,space-1,output);

    }
    printChar(' ',space-1,output);
    printChar('*',startLine,output);
    cout << endl;
}


int main(){
    fstream output("Q8.txt", ios::out);
    printPattern2(5,1,5,output);
    cout << endl;
}
