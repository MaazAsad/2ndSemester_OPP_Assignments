#include <iostream>
using namespace std;

int find(int array[], int length, int target){
	if(length >= 0){
		if(array[length-1] == target){
			return length-1;
		}
		else{
			return find(array,length-1,target);
		}
	}
	else{
		return -1;
	}
}
// 
//
//
// int main() {
// 	int a[] = {1,2,3,4,5,6};
// 	cout << find(a,6,9)<<endl;
// 	return 0;
// }
