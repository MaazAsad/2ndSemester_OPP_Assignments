#include <iostream>
using namespace std;

void sum(int **tri,int row,int column,int x){
    if(column>x-2){
        tri[row][column] = tri[row+1][column] + tri[row+1][column-1];
        sum(tri,row,column-1,x);
    }

}

void printSumTriangle(int arr[], int size, int **sumTriangle, int row, int column)
{
    if(row == column){
        if(size>=0){
            sumTriangle[row-1][size-1] = arr[size-1];
            printSumTriangle(arr,size-1,sumTriangle,row,column);
        }
    }
    if(size>=2 && size<=row){
            sum(sumTriangle,row-size,column-1,size);
    }

}

int main(){
    	int **res = new int*[5];
    	for (int i = 0; i <5; i++)
    	{	res[i] = new int[5]; }
        for (int i = 0; i < 5; i++)
    		{
    		 for (int j = 0; j <5 ; j++)
    		{
    		res[i][j]=-1;
    		}
    		}


    int arr[]={1,2,3,4,5};
    printSumTriangle(arr,5,res,5,5);
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            cout << res[i][j] << ' ';
        }
        cout << endl;
    }
    cout << endl;
    return 0;
}
