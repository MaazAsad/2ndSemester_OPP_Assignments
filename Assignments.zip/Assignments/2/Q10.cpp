#include<iostream>
using namespace std;

int factorial(int a){
    if(a == 0 || a == 1){
        return 1;
    }
    return a*factorial(a-1);
}

long permutate(int n, int r)
{
    return factorial(n) / factorial(n-r);
}



int main(){

    cout << permutate(7,4) << endl;
    return 0;
}
