#include<iostream>
#include<fstream>
using namespace std;
void printChar(char ch,int t,fstream &output){
    if(t>0){
        cout << ch;
        printChar(ch,t-1,output);
    }
}

void printPattern3(int sp, int mLine, fstream &output)
{
    if(sp!=mLine){
        printChar(' ',sp-1,output);
        cout << '*';
        printChar(' ', 2*(mLine-sp)-1,output);
        cout << '*'<<endl;
        printPattern3(sp+1,mLine,output);
    }

    printChar(' ',sp-1,output);
    cout << '*';
    printChar(' ', 2*(mLine-sp)-1,output);

    if(sp !=mLine)
        cout << '*'<<endl;
    else
        cout << endl;
}

int main(){
    fstream output("Q9.txt", ios::out);
    printPattern3(1,5,output);
    cout << endl;
}
