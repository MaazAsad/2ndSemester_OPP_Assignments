#include<iostream>
#include<fstream>
#include<cmath>
#include<string.h>
using namespace std;

int find(int array[], int length, int target){
	if(length >= 0){
		if(array[length-1] == target){
			return length-1;
		}
		else{
			return find(array,length-1,target);
		}
	}
	else{
		return -1;
	}
}

bool isPrime(int n, int i = 2){
    if(n<=2){
        if(n==2){
            return true;
        }
        else{
            return false;
        }
    }
    if(n%i == 0){
        return false;
    }
    if(i*i>n){
        return true;
    }

    return isPrime(n,i+1);
}

char findUpperCase(char * str, int index){
    if(*str){
        if(*str >= 'A' && *str <= 'Z'){
            return *str;
        }
        else{
            return findUpperCase(str+1,index);
        }
    }

    return NULL;
}

float calculatePi(int n){
    if(n==1){
        return 4*1.0;
    }
    else{
        return (4 *( pow(-1,n+1)* (1.0/(2*n-1))) + calculatePi(n-1));
    }
}

int checkEqual(int ** matrix1, int **matrix2, int row, int column){
    bool x=false;
    if(row-1<0){
        return 1;
    }
    if(column-1<0){
        return 1;
    }

    x = (matrix1[row-1][column-1] == matrix2[row-1][column-1]);
    return (x &&  checkEqual(matrix1,matrix2,row-1,column) && checkEqual(matrix1,matrix2,row,column-1));
}

void SumWelp(int* arr, int cols, int &evenSum, int &oddSum){
	if(cols>=0){
		if(arr[cols]%2 ==0){
			evenSum += arr[cols];
		}
		else{
			oddSum += arr[cols];
		}
		SumWelp(arr,cols-1,evenSum,oddSum);
	}
}
void calculateSum(int **matrix1, int row, int column, int &evenSum, int &oddSum){
    if(row>=0){
		SumWelp(matrix1[row],column,evenSum,oddSum);
        calculateSum(matrix1,row-1,column,evenSum,oddSum);
    }
}


void printChar(char ch,int t,fstream &output){
    if(t>0){
        output << ch;
        printChar(ch,t-1,output);
    }
}

void printPattern1(int start, int end,fstream &output){
    if(start<end-1){
			printChar(' ',start-1,output);
			output << '*'<<endl;
			printPattern1(start+1,end-1,output);

		}
        printChar(' ',start-1,output);
        output << '*'<<endl;

}

void printPattern2(int mline, int startLine, int space, fstream &output){
	if(startLine<space+mline+1){
		printChar(' ',space-1,output);
		printChar('*',startLine,output);
		output << endl;
		printPattern2(mline,startLine+2,space-1,output);

	}
	printChar(' ',space-1,output);
	printChar('*',startLine,output);
	output << endl;
}

void printPattern3(int sp, int mLine, fstream &output){
	if(sp!=mLine){
		printChar(' ',sp-1,output);
		output << '*';
		printChar(' ', 2*(mLine-sp)-1,output);
		output << '*'<<endl;
		printPattern3(sp+1,mLine,output);
	}

	printChar(' ',sp-1,output);
	output << '*';
	printChar(' ', 2*(mLine-sp)-1,output);

	if(sp !=mLine)
		output << '*'<<endl;
	else
		output << endl;
}

int factorial(int a){
    if(a == 0 || a == 1){
        return 1;
    }
    return a*factorial(a-1);
}
long permutate(int n, int r){
    return factorial(n) / factorial(n-r);
}

void sum(int **tri,int row,int column,int x){
    if(column>x-2){
        tri[row][column] = tri[row+1][column] + tri[row+1][column-1];
        sum(tri,row,column-1,x);
    }

}
void printSumTriangle(int arr[], int size, int **sumTriangle, int row, int column){
    if(row == column){
        if(size>=0){
            sumTriangle[row-1][size-1] = arr[size-1];
            printSumTriangle(arr,size-1,sumTriangle,row,column);
        }
    }
    if(size>=2 && size<=row){
            sum(sumTriangle,row-size,column-1,size);
    }

}

int res(int coco, int rap){
    if (coco < rap)
        return 0;
    int moreCoco = coco/rap;
    return moreCoco + res(moreCoco + coco%rap,
                              rap);
}
int countMaxChoco(int money, int price, int wrap){
    int num = money/price;
    return num + res(num, wrap);
}

bool isSafe(int** board, int row, int col,int N)
{
    int rowcheck, colcheck;
    for (rowcheck = 0; rowcheck < col; rowcheck++)
        if (board[row][rowcheck])
            return false;

    for (rowcheck=row, colcheck=col; rowcheck>=0 && colcheck>=0; rowcheck--, colcheck--)
        if (board[rowcheck][colcheck])
            return false;

    for (rowcheck=row, colcheck=col; colcheck>=0 && rowcheck<N; rowcheck++, colcheck--)
        if (board[rowcheck][colcheck])
            return false;

    return true;
}

bool solveNQUtil(int **board, int N, int col){

    if (col >= N)
        return true;

    for (int i = 0; i < N; i++)
    {

        if ( isSafe(board, i, col,N) )
        {
            board[i][col] = 1;

            if ( solveNQUtil(board,N, col + 1) )
                return true;


            board[i][col] = 0;
        }
    }

    return false;
}

// bool solveNQUtil(int **board, int N, int col)
// {
// //write your code here for question 13
// }
