#include <iostream>
using namespace std;

void printChar(char ch,int t,fstream &output){
    if(t>0){
        output << ch;
        printChar(ch,t-1);
    }
}

void printPattern1(int start, int end,fstream &output)
{
    if(start<end-1){
			printChar(' ',start-1,output);
			output << '*'<<endl;
			printPattern1(start+1,end-1,output);

		}
        printChar(' ',start-1);
        output << '*'<<endl;

}

int main(){
    fstream output("Q7.txt", ios::out);
      		if (output)
      		{
      		printPattern1(1, 10,output);
      		}
      		output.close();

    printPattern1(1,10,output);
    cout << endl;
    return 0;
}
