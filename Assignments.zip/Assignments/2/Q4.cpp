#include <iostream>
#include<cmath>
using namespace std;

float calculatePi(int n)
{
    if(n==1){
        return 4*1.0;
    }
    else{
        return (4 *( pow(-1,n+1)* (1.0/(2*n-1))) + calculatePi(n-1));
    }
}


int main(){
    cout << calculatePi(5)<<endl;
    return 0;
}
