#include<iostream>
using namespace std;

int res(int coco, int rap)
{
    if (coco < rap)
        return 0;
    int moreCoco = coco/rap;
    return moreCoco + res(moreCoco + coco%rap,
                              rap);
}

int countMaxChoco(int money, int price, int wrap)
{
    int num = money/price;
    return num + res(num, wrap);
}

int main(){
    cout << countMaxChoco(16,2,2)<<endl;
    return 0;
}
