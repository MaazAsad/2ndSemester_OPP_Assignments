#include<iostream>
using namespace std;


int checkEqual(int ** matrix1, int **matrix2, int row, int column)
{
    bool x=false;
    if(row-1<0)
        return 1;
    if(column-1<0)
        return 1;
      x = (matrix1[row-1][column-1] == matrix2[row-1][column-1]);
    return (x &&  checkEqual(matrix1,matrix2,row-1,column) && checkEqual(matrix1,matrix2,row,column-1));
}


int main(){
    int **a = new int*[3];
    for(int i=0;i<3;i++){
        a[i]= new int[3];
    }

    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            if(i==j)
                a[i][j] = 5;
            else
                a[i][j] = 1;
        }
    }

    int** b = new int*[3];
    for(int i=0;i<3;i++){
        b[i]= new int[3];
    }
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            b[i][j] = 1;
        }
    }

    cout << checkEqual(a,b,3,3)<<endl;


    return 0;
}
