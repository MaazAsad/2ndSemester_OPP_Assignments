/*
 * ALU.h
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#ifndef ALU_H_
#define ALU_H_

class ALU {
	int NoOfAdders;
	int NoOfSubtractors;
	int NoOfRegisters;
	int sizeOfRegisters;
public:
	ALU();
	ALU(int NOA,int NOS, int NOR, int SOR);
	int getNoOfAdders();
	int getNoOfSubtractors();
	int getNoOfRegisters();
	int getsizeOfRegisters();
	void setNoOfAdders(int n);
	void setNoOfSubtractors(int n);
	void setNoOfRegisters(int n);
	void setsizeOfRegisters(int s);
};

#endif /* ALU_H_ */
