/*
 * CPU.cpp
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#include "CPU.h"

CPU::CPU():alu(),cu()
{

}

CPU::CPU(int NOA,int NOS,int NOR, int SOR, float c):alu(NOA,NOS,NOR,SOR),cu(c)
{

}

ALU CPU::getAlu()
{
	return alu;
}

ControlUnit CPU::getCu()
{
	return cu;
}

void CPU::setAlu(ALU &alu)
{
	this->alu=alu;
}

void CPU::setCu(ControlUnit &cu)
{
	this->cu=cu;
}
