/*
 * CPU.h
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#ifndef CPU_H_
#define CPU_H_
#include "ControlUnit.h"
#include "ALU.h"

class CPU {
	ALU alu;
	ControlUnit cu;
public:
	CPU();
	CPU(int NOA,int NOS,int NOR, int SOR, float c);
	ALU getAlu();
	ControlUnit getCu();
	void setAlu(ALU &alu);
	void setCu(ControlUnit &cu);
};

#endif /* CPU_H_ */
