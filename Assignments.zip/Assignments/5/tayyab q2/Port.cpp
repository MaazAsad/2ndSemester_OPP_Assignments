/*
 * Port.cpp
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#include "Port.h"

Port::Port()
{
	type="";
	baud_rate=0;
}
Port::Port(string t,int br)
{
	type=t;
	baud_rate=br;
}
void Port::setType(string t)
{
	type=t;
}
void Port::setBaud_rate(int br)
{
	baud_rate=br;
}
string Port::getType()
{
	return type;
}
int Port::getBaudRate()
{
	return baud_rate;
}

