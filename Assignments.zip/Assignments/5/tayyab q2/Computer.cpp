/*
 * Computer.cpp
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#include "Computer.h"

Computer::Computer():pm(new PhysicalMemory),mb(new MotherBoard),cpu(new CPU)
{
}
Computer::Computer(int PMcapacity,int MBcap,string MBtechType,string *MBtype,int *MBbr,int MBsize,int CPUNOA,int CPUNOS,int CPUNOR, int CPUSOR, float CPUc)
:pm(new PhysicalMemory(PMcapacity)),mb(new MotherBoard(MBcap,MBtechType,MBtype,MBbr,MBsize)),cpu(new CPU(CPUNOA,CPUNOS,CPUNOR,CPUSOR,CPUc))
{
}
PhysicalMemory Computer::getPm()
{
	return *pm;
}
MotherBoard Computer::getMb()
{
	return *mb;
}
CPU Computer::getCpu()
{
	return *cpu;
}
Computer::~Computer()
{

}

