/*
 * MainMemory.cpp
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#include "MainMemory.h"

MainMemory::MainMemory() {
	capacity=0;
	technologyType="";
}

MainMemory::MainMemory(int cap,string techType)
{
	capacity=cap;
	technologyType=techType;

}
int MainMemory::getCapacity()
{
	return capacity;
}
string MainMemory::getTechnologyType()
{
	return technologyType;
}
void MainMemory::setCapacity(int cap)
{
	capacity=cap;
}
void MainMemory::setTechnologyType(string techType)
{
	technologyType=techType;
}
