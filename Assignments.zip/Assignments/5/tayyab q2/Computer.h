/*
 * Computer.h
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#ifndef COMPUTER_H_
#define COMPUTER_H_
#include "PhysicalMemory.h"
#include "MotherBoard.h"
#include "CPU.h"

class Computer {
	PhysicalMemory *pm;
	MotherBoard *mb;
	CPU *cpu;
public:
	Computer();
	Computer(int PMcapacity,int MBcap,string MBtechType,string *MBtype,int *MBbr,int MBsize,int CPUNOA,int CPUNOS,int CPUNOR, int CPUSOR, float CPUc);
	PhysicalMemory getPm();
	MotherBoard getMb();
	CPU getCpu();
	~Computer();
};

#endif /* COMPUTER_H_ */
