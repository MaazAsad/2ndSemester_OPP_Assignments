/*
 * ControlUnit.cpp
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#include "ControlUnit.h"

ControlUnit::ControlUnit()
{
	clock=0;
}

ControlUnit::ControlUnit(float c)
{
	clock=c;
}
void ControlUnit::setClock(float c)
{
	clock=c;
}
float ControlUnit::getClock()
{
	return clock;
}

