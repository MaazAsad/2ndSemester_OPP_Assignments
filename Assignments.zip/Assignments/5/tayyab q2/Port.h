/*
 * Port.h
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#ifndef PORT_H_
#define PORT_H_
#include <iostream>
#include <cstring>
using namespace std;

class Port {
	string type;
	int baud_rate;
public:
	Port();
	Port(string t,int br);
	void setType(string t);
	void setBaud_rate(int br);
	string getType();
	int getBaudRate();
};

#endif /* PORT_H_ */
