/*
 * PhysicalMemory.h
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#ifndef PHYSICALMEMORY_H_
#define PHYSICALMEMORY_H_

class PhysicalMemory {
	int capacity;
public:
	PhysicalMemory();
	PhysicalMemory(int cap);
	void setCapacity(int cap);
	int getCapacity();
};

#endif /* PHYSICALMEMORY_H_ */
