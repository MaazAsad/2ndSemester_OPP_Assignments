/*
 * ControlUnit.h
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#ifndef CONTROLUNIT_H_
#define CONTROLUNIT_H_

class ControlUnit {
	float clock;
public:
	ControlUnit();
	ControlUnit(float c);
	void setClock(float c);
	float getClock();

};

#endif /* CONTROLUNIT_H_ */
