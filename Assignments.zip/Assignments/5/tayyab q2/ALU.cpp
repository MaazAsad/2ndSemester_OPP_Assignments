/*
 * ALU.cpp
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#include "ALU.h"

ALU::ALU()
{
	NoOfAdders=0;
	NoOfSubtractors=0;
	NoOfRegisters=0;
	sizeOfRegisters=0;
}
ALU::ALU(int NOA,int NOS, int NOR, int SOR)
{
	NoOfAdders=NOA;
	NoOfSubtractors=NOS;
	NoOfRegisters=NOR;
	sizeOfRegisters=SOR;
}
int ALU::getNoOfAdders()
{
	return NoOfAdders;
}
int ALU::getNoOfSubtractors()
{
	return NoOfSubtractors;
}
int ALU::getNoOfRegisters()
{
	return NoOfRegisters;
}
int ALU::getsizeOfRegisters()
{
	return sizeOfRegisters;
}
void ALU::setNoOfAdders(int n)
{
	NoOfAdders=n;
}
void ALU::setNoOfSubtractors(int n)
{
	NoOfSubtractors=n;
}
void ALU::setNoOfRegisters(int n)
{
	NoOfRegisters=n;
}
void ALU::setsizeOfRegisters(int s)
{
	sizeOfRegisters=s;
}
