/*
 * PhysicalMemory.cpp
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#include "PhysicalMemory.h"

PhysicalMemory::PhysicalMemory()
{
	capacity=0;
}
PhysicalMemory::PhysicalMemory(int cap)
{
	capacity=cap;
}
void PhysicalMemory::setCapacity(int cap)
{
	capacity=cap;
}
int PhysicalMemory::getCapacity()
{
	return capacity;
}
