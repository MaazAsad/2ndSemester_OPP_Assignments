/*
 * MainMemory.h
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#ifndef MAINMEMORY_H_
#define MAINMEMORY_H_
#include <iostream>
#include <cstring>
using namespace std;

class MainMemory {
	int capacity;
	string technologyType;
public:
	MainMemory();
	MainMemory(int cap,string techType);
	int getCapacity();
	string getTechnologyType();

	void setCapacity(int cap);
	void setTechnologyType(string techType);
};

#endif /* MAINMEMORY_H_ */
