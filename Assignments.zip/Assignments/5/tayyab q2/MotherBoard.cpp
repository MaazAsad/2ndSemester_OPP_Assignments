/*
 * MotherBoard.cpp
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#include "MotherBoard.h"

MotherBoard::MotherBoard():mm(new MainMemory),ports(new Port[1])
{
	size=1;
	index=0;
	for (int i=0;i<size;i++)
	{
		ports[i].setType("");
		ports[i].setBaud_rate(0);
	}
}
MotherBoard::MotherBoard(int cap,string techType,string *type,int *br,int size):mm(new MainMemory(cap,techType)),ports(new Port[size])
{
	this->size=size;
	index=0;
	for (int i=0;i<size;i++)
	{
		ports[i].setType(type[i]);
		ports[i].setBaud_rate(br[i]);
	}
}
MainMemory MotherBoard::getMm()
{
	return *mm;
}
Port MotherBoard::getPorts(int i)
{
	if (i>=0 && i<size)
	{
		return ports[i];
	}
	return ports[0];
}
//void setMm(MainMemory& m);
//void addPort(Port& p);
MotherBoard::~MotherBoard()
{
	delete []ports;
}
