/*
 * MotherBoard.h
 *
 *  Created on: 21 Apr 2019
 *      Author: silicon systems
 */

#ifndef MOTHERBOARD_H_
#define MOTHERBOARD_H_
#include "Port.h"
#include "MainMemory.h"

class MotherBoard {
	MainMemory *mm;
	Port *ports;
	int size;
	int index;
public:
	MotherBoard();
	MotherBoard(int cap,string techType,string *type,int *br,int size);
	MainMemory getMm();
	Port getPorts(int);
	//void setMm(MainMemory& m);
	//void addPort(Port& p);
	~MotherBoard();
};

#endif /* MOTHERBOARD_H_ */
