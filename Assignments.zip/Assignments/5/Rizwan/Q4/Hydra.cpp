/*
 * Hydra.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: rozi
 */

#include "Hydra.h"

Hydra::Hydra(string n, int l, int h, int f, int nl, int pd, int p ):Creature(n,l,h,f,p),neckLength(nl),poisonDose(pd){

}
Hydra::~Hydra(){

}
void Hydra::InjectPoison(Creature& c){
	/*
	 * if the hydra and the creature are alive and the creature is in range of the head of the hydra, then
the hydra inflicts damage to the creature; the creature weakens by the number of attack points
of the hydra plus its dose of poison;
	 */
	/*
		if((points>0)&& (c.getPoints()>0)){
			if(distance(position,c.position)<=neckLength){

		c.Weak(AttackPoints()+poisonDose);
									}
		else{
			points-=distance(position,c.position);
			}
			

						}
		if(points>0&& c.getPoints()<=0){
			level+=1;				
				}
*/

	if(c.alive()&&alive()&&(distance(position,c.position))<=neckLength)
{
			c.Weak(AttackPoints()+poisonDose);
			Weak(distance(position,c.position));
			if(alive()&&!c.alive()){
				level+=1;
			}
		}


}
