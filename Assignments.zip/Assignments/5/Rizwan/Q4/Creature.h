/*
 * Creature.h
 *
 *  Created on: Apr 22, 2019
 *      Author: rozi
 */

#ifndef CREATURE_H_
#define CREATURE_H_
#include<iostream>
using namespace std;
#include<string>

//-----------Class Creature.h--------------
class Creature {
protected:
	string name;
	int level;
	int points;
	int force;
public:
	int getPoints();
	int position;
	Creature(string n, int l, int h, int f, int p = 0);
	~Creature();
	bool alive();
	int AttackPoints();
	void Move(int x);
	void GoodBye();
	void Weak(int x);
	void display();
	int distance(int x, int y);
};


#endif /* CREATURE_H_ */
