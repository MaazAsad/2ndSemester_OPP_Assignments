/*
 * Dragon.cpp
 *
 *  Created on: Apr 22, 2019
 *      Author: rozi
 */

#include "Dragon.h"

Dragon::Dragon(string n, int l, int h, int f, int fr, int p ):Creature(n,l,h,f,p),flameRange(fr){

}

Dragon::~Dragon(){

}
void Dragon::Fly(int pos){
	Move(pos);

}
void Dragon::BlowFlame(Creature& c){
	/*if(points>0&&c.getPoints()>0){
		if(distance(position,c.position)<=flameRange){
			c.Weak(AttackPoints());
			points-=distance(position,c.position);
		}
		else{
			points-=distance(position,c.position);
		}
	}*/
	if(c.alive()&&alive()){
     // if(distance(position,c.position)<=flameRange){
		c.Weak(AttackPoints());
		Weak((distance(position,c.position)));
		if(alive()&&!c.alive()){
			level+=1;
		}
	//	}

	}
}
