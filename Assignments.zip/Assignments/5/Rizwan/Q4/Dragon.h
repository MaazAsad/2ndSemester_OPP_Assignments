/*
 * Dragon.h
 *
 *  Created on: Apr 22, 2019
 *      Author: rozi
 */

#ifndef DRAGON_H_
#define DRAGON_H_
#include "Creature.h"

class Dragon: public Creature {
	int flameRange;
public:
	Dragon(string n, int l, int h, int f, int fr, int p = 0);
	~Dragon();
	void Fly(int pos);
	void BlowFlame(Creature& c);
};
#endif /* DRAGON_H_ */
