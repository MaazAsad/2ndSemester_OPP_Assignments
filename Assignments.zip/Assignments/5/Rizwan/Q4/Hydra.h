/*
 * Hydra.h
 *
 *  Created on: Apr 23, 2019
 *      Author: rozi
 */

#ifndef HYDRA_H_
#define HYDRA_H_

#include "Creature.h"

class Hydra: public Creature {
private:
	int neckLength;
	int poisonDose;
public:
	Hydra(string n, int l, int h, int f, int nl, int pd, int p = 0);
	~Hydra();
	void InjectPoison(Creature& c);
};

#endif /* HYDRA_H_ */
