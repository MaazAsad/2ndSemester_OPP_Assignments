/*
 * Creature.cpp
 *
 *  Created on: Apr 22, 2019
 *      Author: rozi
 */

#include "Creature.h"

Creature::Creature(string n, int l, int h, int f, int p ){
	 name=n;
	 level=l;
	 points=h;
	 force=f;
	 position=p;
}
int Creature::getPoints(){
	return points;
}
Creature::~Creature(){

}
bool Creature::alive(){
	if(points>0){
		return true;
	}
	return false;
}
int Creature::AttackPoints(){
	if(alive()){
		return (level*force);
	}
	return 0;
}
void Creature::Move(int x){
	position+=x;

}
void Creature::GoodBye(){
	cout<<name<<" is no more!";

}
void Creature::Weak(int x){
	if(alive()){
	points-=x;
	}
	else
	{
		points=0;
		GoodBye();
	}
}

void Creature::display(){
	cout<<name<<", level: "<<level<<", health_status: "<<points<<", force: "<<force<<", Attacking Points: "<<AttackPoints()<<", position: "<<position;
}
int Creature::distance(int x, int y){
	 return abs(x - y);
}
