/*
 * ThreeDShape.h
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#ifndef THREEDSHAPE_H_
#define THREEDSHAPE_H_
#include"Shape.h"
#include"ThreeDPoint.h"
#include<sstream>
class ThreeDShape:public Shape {
ThreeDPoint td;

public:
	ThreeDShape();
	ThreeDShape(const string& color , double x, double y,double z); //Parameterized constructor that invokes the base Shape constructor to set color then sets its own coordinates instance value.
	virtual double voulme(); //this overriding member function computes and returns the Spehere object's volume value.
	virtual string toString();
	//virtual double perimeter(); //member function that computes and returns the object's perimeter. It must be overridden in each derived class.
	virtual ~ThreeDShape();
 string help1(double in);
	 ThreeDPoint getPosition() const;
};

#endif /* THREEDSHAPE_H_ */
