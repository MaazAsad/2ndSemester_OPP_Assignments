/*
 * Shape.h
 *
 *  Created on: Apr 20, 2019
 *      Author: rizwa
 */

#ifndef SHAPE_H_
#define SHAPE_H_
#include<iostream>
using namespace std;
#include<string>
class Shape {
	string color;
public:
	Shape();
	virtual ~Shape();
	 //function that returns the shape's description (color, type,position, measurements, and area) as a string. It must be overridden in each derived class.
	Shape(const string& color); // a constructor that sets the color instance value.
	const string& getColor() const ;
	virtual string toString();
	void setColor(const string& color);
};

#endif /* SHAPE_H_ */
