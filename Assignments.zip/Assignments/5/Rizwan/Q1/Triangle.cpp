/*
 * Triangle.cpp
 *
 *  Created on: Apr 20, 2019
 *      Author: rizwa
 */

#include "Triangle.h"

Triangle::Triangle(){
side1=0;
side2=0;
side3=0;
}
Triangle::Triangle(const string& color, double x, double y , double s1,double s2,double s3):TwoDShape(color,x,y),side1(s1),side2(s2),side3(s3){
	//a constructor that invokes the base 2DShape constructor then sets its own radius instance value.
}
double Triangle::area(){
double s=side1+side2+side3;
s/=2;
double area=s*(s-side1)*(s-side2)*(s-side3);
area=pow(area,0.5);
return area;
	//this overriding member function computes and returns the Circle object's area value.
}
double Triangle::perimeter (){
return (side1+side2+side3);
	//this overriding member function computes and returns the Circle object's perimeter value.
}
string Triangle::toString(){
	string col=TwoDShape::getColor();
	string to_ret=col;
	to_ret+=" Triangle Position:(";

	to_ret+=help(getPosition().getX());
	to_ret+=",";
//Green Triangle Position:(1.1,1.1) Side1:2.2 Side2:2.2 Side3:2.2 Perimeter:8.8 Area:4.84";
	to_ret+=help(getPosition().getY());
	to_ret+=") Side1:";
	to_ret+=help(side1);
	to_ret+=" Side2:";
	to_ret+=help(side2);
	to_ret+=" Side3:";
	to_ret+=help(side3);
	to_ret+=" Perimeter:";
	to_ret+=help(perimeter());
	to_ret+=" Area:";
	to_ret+=help(area());
	return to_ret;
	//this overriding member function returns the Circle object's description ( color, type, measurements, perimeter and area) like Red Circle Position:(x,y) Radius:Value1 Perimeter:Value2 Area:Value3
}
Triangle::~Triangle(){

}

double Triangle::getSide1() const {
	return side1;
}

void Triangle::setSide1(double side1) {
	this->side1 = side1;
}

double Triangle::getSide2() const {
	return side2;
}

void Triangle::setSide2(double side2) {
	this->side2 = side2;
}

double Triangle::getSide3() const {
	return side3;
}

void Triangle::setSide3(double side3) {
	this->side3 = side3;
}
