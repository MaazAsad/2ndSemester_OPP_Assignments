/*
 * TwoDShape.cpp
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#include "TwoDShape.h"


TwoDShape::TwoDShape(){
	//Default constructor
}
TwoDShape::TwoDShape(const string& color , double x, double y):Shape(color),twod(x,y){

	//Parameterized constructor that invokes the base Shape constructor to set color then sets its own coordinates instance value.
}


	TwoDPoint TwoDShape::getPosition() const {
		return twod;
	}

	string TwoDShape::toString(){

	}
string TwoDShape::help(double in){

stringstream ss;

  ss << in;
  string d=ss.str();
return d;
}


 double TwoDShape::perimeter(){

 }
double TwoDShape::area(){

	}
TwoDShape::~TwoDShape(){

}
