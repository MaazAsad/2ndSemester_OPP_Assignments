/*
 * Triangle.h
 *
 *  Created on: Apr 20, 2019
 *      Author: rizwa
 */

#ifndef Triangle_H_
#define Triangle_H_
#include<iostream>
using namespace std;
#include<string>
#include"TwoDShape.h"
#include<cmath>
class Triangle:public TwoDShape {
	double side1,side2,side3;
public:
	Triangle();
	Triangle(const string& color, double x, double y , double w,double h,double l); //a constructor that invokes the base 2DShape constructor then sets its own radius instance value.
	double area(); //this overriding member function computes and returns the Circle object's area value.
	double perimeter (); //this overriding member function computes and returns the Circle object's perimeter value.
	virtual string toString(); //this overriding member function returns the Circle object's description ( color, type, measurements, perimeter and area) like Red Circle Position:(x,y) Radius:Value1 Perimeter:Value2 Area:Value3
	virtual ~Triangle();

	double getSide1() const ;
	void setSide1(double side1);
	double getSide2() const ;
	void setSide2(double side2) ;
	double getSide3() const ;
	void setSide3(double side3) ;
};

#endif /* Triangle_H_ */
