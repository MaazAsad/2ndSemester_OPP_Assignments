/*
 * Cube.h
 *
 *  Created on: Apr 20, 2019
 *      Author: rizwa
 */

#ifndef CUBE_H_
#define CUBE_H_
#include<iostream>
using namespace std;
#include<string>
#include"ThreeDShape.h"
class Cube:public ThreeDShape {
double length;
public:

	Cube();
	Cube(const string& color, double x, double y, double z, double radius);
	virtual double voulme(); //this overriding member function computes and returns the Spehere object's volume value.
	virtual string toString();//this overriding member function returned the object's description ( color, type, measurements, volume) like
		//Red Sphere Position:(x,y,z) Radius:Value1 Vloume:Value3
	virtual ~Cube();
};

#endif /* CUBE_H_ */
