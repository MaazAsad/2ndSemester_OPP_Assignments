//============================================================================
// Name        : q1.cpp
// Author      : Rizwan
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include"ShapeFactory.h"

ShapeFactory::ShapeFactory(){

}
void ShapeFactory::getShape(){

	cout<<"What Kind Of Shape Do You Wnat to have: \nFor 2-d Shape ENter 1\nFor 3-D shape Enter 2\n";
	int des;//description of the shape means what kind of shape user wanted to have
	cin>>des;
		if(des==1){
			TwoDShape *ptr;
			cout<<"Which Shape Do You Want to Have: \nFor Circle Enter 1\nFor Triangle Enter 2\nFor Square Enter 3\n";
			int type;
			cin>>type;
			if(type==1){
				
				double radius;
				cout<<"\nEnter the Radius\n";
				cin>>radius;
				cout<<"\nEnter Value of X\n";
				double x;
				cin>>x;
				cout<<"\nEnter Value of Y\n";
				double y;
				cin>>y;
				cout<<"\nEnter Color\n";
				string color;
				cin>>color;
				ptr=new Circle(color,x,y,radius);
				
				cout<<ptr->toString();


			}
			else if(type==2){
				
				cout<<"\nEnter side 1\n";
				double s1;
				cin>>s1;
				cout<<"\nEnter side 2\n";
				double s2;
				cin>>s2;
				cout<<"\nEnter side 3\n";
				double s3;
				cin>>s3;
				cout<<"\nEnter value of X\n";
				double x;
				cin>>x;
				cout<<"\nEnter value of Y\n";
				double y;
				cin>>y;
				cout<<"\nEnter color\n";
				string color;
				cin>>color;
				ptr=new Triangle(color,x,y,s1,s2,s3);
				
				cout<<ptr->toString();

			}
			else if(type==3){
				
				cout<<"\nENter length\n";
				double len;
				cin>>len;
				cout<<"\nEnter Color\n";
				string color;
				cin>>color;
				cout<<"\nEnter Value of X\n";
				double x;
				cin>>x;
				cout<<"\nEnter value of Y\n";
				double y;
				cin>>y;
				ptr=new Square(color,x,y,len);
				
				cout<<ptr->toString();

			}
			}
		else if(des==2){
			ThreeDShape *ptr;
					cout<<"Which Shape Do You Want to Have: \nFor Cube Enter 1\nFor Tetrahydron Enter 2\nFor Sphere Enter 3\n";
					int type;
					cin>>type;
					if(type==1){
						
						double side;
						cout<<"\nEnter the Side\n";
						cin>>side;
						cout<<"\nEnter Value of X\n";
						double x;
						cin>>x;
						cout<<"\nEnter Value of Y\n";
						double y;
						cin>>y;
						cout<<"\nEnter Value of Z\n";
						double z;
						cin>>z;
						cout<<"\nEnter Color\n";
						string color;
						cin>>color;
						ptr=new Cube(color,x,y,z,side);
						
						cout<<ptr->toString();


					}
					else if(type==2){
						
						cout<<"\nEnter Length of Edge\n";
						double len;
						cin>>len;
						cout<<"\nEnter value of X\n";
						double x;
						cin>>x;
						cout<<"\nEnter value of Y\n";
						double y;
						cin>>y;
						cout<<"\nEnter value of Z\n";
						double z;
						cin>>z;
						cout<<"\nEnter color\n";
						string color;
						cin>>color;
						ptr=new Tetrahedron(color,x,y,z,len);
						
						cout<<ptr->toString();

					}
					else if(type==3){
						
						cout<<"\nENter radius\n";
						double radi;
						cin>>radi;
						cout<<"\nEnter Color\n";
						string color;
						cin>>color;
						cout<<"\nEnter Value of X\n";
						double x;
						cin>>x;
						cout<<"\nEnter value of Y\n";
						double y;
						cin>>y;
						cout<<"\nEnter value of Z\n";
						double z;
						cin>>z;
						ptr=new Sphere(color,x,y,z,radi);
						
						cout<<ptr->toString();

					}

		}
	}

