/*
 * Circle.h
 *
 *  Created on: Apr 19, 2019
 *      Author: rizwa
 */

#ifndef CIRCLE_H_
#define CIRCLE_H_
#include<iostream>
using namespace std;
#include<string>
#include<math.h>
#include"TwoDShape.h"
class Circle:public TwoDShape {
	double radius;

public:
	Circle();
	Circle(const string& color, double x, double y , double radius); //a constructor that invokes the base 2DShape constructor then sets its own radius instance value.
	double area(); //this overriding member function computes and returns the Circle object's area value.
	double perimeter (); //this overriding member function computes and returns the Circle object's perimeter value.
	string toString(); //this overriding member function returns the Circle object's description ( color, type, measurements, perimeter and area) like Red Circle Position:(x,y) Radius:Value1 Perimeter:Value2 Area:Value3
	virtual ~Circle();

	double getRadius() const ;
	void setRadius(double radius) ;
};

#endif /* CIRCLE_H_ */
