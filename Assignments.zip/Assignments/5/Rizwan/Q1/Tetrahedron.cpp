/*
 * Tetrahedron.cpp
 *
 *  Created on: Apr 20, 2019
 *      Author: rizwa
 */

#include "Tetrahedron.h"

Tetrahedron::Tetrahedron():length(0.0){

}

Tetrahedron::Tetrahedron(const string& color, double x, double y, double z, double radius):ThreeDShape(color,x,y,z),length(radius){

}
double Tetrahedron::voulme(){
	double vol=(length*length*length);
	vol/=8.48;
	return vol;
	//this overriding member function computes and returns the Spehere object's volume value.
}
string Tetrahedron::toString(){
	string col=getColor();
			string to_ret=col;
			to_ret+=" Tetrahedron Position:(";
//"Green Sphere Position:(1.1,1.1,1,1) LengthOfEdge:2.2 Volume:1.25488";
			to_ret+=help1(getPosition().getX());
			to_ret+=",";
			to_ret+=help1(getPosition().getY());
			to_ret+=",";
			to_ret+=help1(getPosition().getZ());
			to_ret+=") LengthOfEdge:";
			to_ret+=help1(length);
			to_ret+=" Volume:";
			to_ret+=help1(voulme());

			return to_ret;
	//this overriding member function returned the object's description ( color, type, measurements, volume) like
}
			//Red Sphere Position:(x,y,z) Radius:Value1 Vloume:Value3
Tetrahedron::~Tetrahedron(){

}


double Tetrahedron::getLength() const {
	return length;
}

void Tetrahedron::setLength(double length) {
	this->length = length;
}

