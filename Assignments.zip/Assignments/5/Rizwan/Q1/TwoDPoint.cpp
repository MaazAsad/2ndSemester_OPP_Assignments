/*
 * TwoDPoint.cpp
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#include "TwoDPoint.h"

TwoDPoint::TwoDPoint(){
	x=0.0;
	y=0.0;
	//Default constructor
}
TwoDPoint::TwoDPoint(double X, double Y):x(X),y(Y){
	//Parameterized constructor
}
double TwoDPoint::getX() const{
	return x;
		//a const member function returning the x coordinate value
}
void TwoDPoint::setX(double X){
		x=X;
	//a member function setting the x coordinate value
}
double TwoDPoint::getY()const{
	return y;
	// a const member function returning the y coordinate value.
}
void TwoDPoint::setY(double Y){
	y=Y;
	//a member function setting the y coordinate value.
}

TwoDPoint::~TwoDPoint(){

}
