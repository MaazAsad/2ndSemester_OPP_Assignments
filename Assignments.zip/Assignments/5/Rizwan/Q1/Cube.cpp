/*
 * Cube.cpp
 *
 *  Created on: Apr 20, 2019
 *      Author: rizwa
 */

#include "Cube.h"

Cube::Cube():length(0.0){

}
Cube::Cube(const string& color, double x, double y, double z, double radius):ThreeDShape(color,x,y,z),length(radius){

}
double Cube::voulme(){
	return (length*length*length);
	//this overriding member function computes and returns the Spehere object's volume value.
}
 string Cube::toString(){
	string col=getColor();
		string to_ret=col;
		to_ret+=" Cube Position:(";
//Green Cube Position:(1.1,1.1,1,1) Side:2.2 Volume:10.65";
		to_ret+=help1(getPosition().getX());
		to_ret+=",";
		to_ret+=help1(getPosition().getY());
		to_ret+=",";
		to_ret+=help1(getPosition().getZ());
		to_ret+=") Side:";
		to_ret+=help1(length);
		to_ret+=" Volume:";
		to_ret+=help1(voulme());

		return to_ret;
	//this overriding member function returned the object's description ( color, type, measurements, volume) like
}
	//Red Sphere Position:(x,y,z) Radius:Value1 Vloume:Value3
Cube::~Cube(){

}

