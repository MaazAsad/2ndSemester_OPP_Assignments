/*
 * Shape.cpp
 *
 *  Created on: Apr 20, 2019
 *      Author: rizwa
 */

#include "Shape.h"

Shape::Shape() {
	// TODO Auto-generated constructor stub
color="";
}

Shape::~Shape() {
	// TODO Auto-generated destructor stub
}

Shape::Shape(const string& color){
	(*this).color=color;
}
const string& Shape::getColor() const {
	return color;
}

void Shape::setColor(const string& color) {
	this->color = color;
}
 string Shape::toString(){
return color;
}
