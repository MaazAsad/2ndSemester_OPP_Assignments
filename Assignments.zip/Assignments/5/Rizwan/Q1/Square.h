/*
 * Square.h
 *
 *  Created on: Apr 20, 2019
 *      Author: rizwa
 */

#ifndef SQUARE_H_
#define SQUARE_H_
#include<iostream>
using namespace std;
#include<string>
#include"TwoDShape.h"
class Square:public TwoDShape {
	double length;
public:
	Square();
	Square(const string& color, double x, double y , double len); //a constructor that invokes the base 2DShape constructor then sets its own radius instance value.
	double area(); //this overriding member function computes and returns the Circle object's area value.
	double perimeter (); //this overriding member function computes and returns the Circle object's perimeter value.
	string toString(); //this overriding member function returns the Circle object's description ( color, type, measurements, perimeter and area) like Red Circle Position:(x,y) Radius:Value1 Perimeter:Value2 Area:Value3
	virtual ~Square();

	double getLength() const;
	void setLength(double length);
};

#endif /* SQUARE_H_ */
