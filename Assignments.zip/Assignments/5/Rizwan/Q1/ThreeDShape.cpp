/*
 * ThreeDShape.cpp
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#include "ThreeDShape.h"

ThreeDShape::ThreeDShape(){

}
ThreeDShape::ThreeDShape(const string& color , double x, double y,double z):Shape(color),td(x,y,z){
	//Parameterized constructor that invokes the base Shape constructor to set color then sets its own coordinates instance value.
}
 ThreeDShape::~ThreeDShape(){

}
 ThreeDPoint ThreeDShape::getPosition() const {
 		return td;
 	}

	double  ThreeDShape::voulme(){

	}
	 string ThreeDShape::toString(){

	 }
string ThreeDShape::help1(double in){

stringstream ss;

  ss << in;
  string d=ss.str();
return d;
}
