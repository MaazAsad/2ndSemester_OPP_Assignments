/*
 * Traingle_test.cpp
 *
 *  Created on: Apr 20, 2019
 *      Author: rizwa
 */

#include "Traingle.h"

