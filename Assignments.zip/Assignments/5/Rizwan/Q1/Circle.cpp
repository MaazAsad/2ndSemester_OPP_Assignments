/*
 * Circle.cpp
 *
 *  Created on: Apr 19, 2019
 *      Author: rizwa
 */

#include "Circle.h"

/*
string help(double in)
{
stringstream ss;

  ss << in;
  string d=ss.str();
 return d;
}*/
Circle::Circle(){
	radius=0.0;

}
Circle::Circle(const string& color, double x, double y , double radius):TwoDShape(color,x,y),radius(radius){
	//a constructor that invokes the base 2DShape constructor then sets its own radius instance value.
}
double Circle::area(){
double area=(3.14)*pow(radius,2);
return area;
//this overriding member function computes and returns the Circle object's area value.
}
double Circle::perimeter (){
	double peri=2*(3.14*radius);
return peri;
	//this overriding member function computes and returns the Circle object's perimeter value.
}
string Circle::toString(){
	//this overriding member function returns the Circle object's description ( color, type, measurements, perimeter and area) like Red Circle Position:(x,y) Radius:Value1 Perimeter:Value2 Area:Value3
	//( color, type, measurements, perimeter and area) like Red Circle Position:(x,y) Radius:Value1 Perimeter:Value2 Area:Value3
string col=getColor();
		string to_ret=col;
to_ret+=" Circle Position:(";

//"Red Circle Position:(1.1,1.1) Radius:2.2 Perimeter:13.816 Area:15.1976";
to_ret+=help(getPosition().getX());
to_ret+=",";
to_ret+=help(getPosition().getY());
to_ret+=") Radius:";
to_ret+=help(radius);
to_ret+=" Perimeter:";
to_ret+=help(perimeter());
to_ret+=" Area:";
to_ret+=help(area());
return to_ret;
}

Circle::~Circle(){

}
double Circle::getRadius() const {
	return radius;
}

void Circle::setRadius(double radius) {
	this->radius = radius;
}
