/*
 * Square.cpp
 *
 *  Created on: Apr 20, 2019
 *      Author: rizwa
 */

#include "Square.h"

Square::Square(){
	length=0.0;

}
Square::Square(const string& color, double x, double y , double len):TwoDShape(color,x,y),length(len){
	//a constructor that invokes the base 2DShape constructor then sets its own radius instance value.
}
double Square::area(){
return (length*length);
	//this overriding member function computes and returns the Circle object's area value.
}
double Square::perimeter (){
	return (length*4);
	//this overriding member function computes and returns the Circle object's perimeter value.
}
string Square::toString(){
	string col=TwoDShape::getColor();
	string to_ret=col;
	to_ret+=" Square Position:(";
//"Red Square Position:(1.1,1.1) Side:2.2 Perimeter:8.8 Area:4.84";
	to_ret+=help(getPosition().getX());
	to_ret+=",";
	to_ret+=help(getPosition().getY());
	to_ret+=") Side:";
	to_ret+=help(length);
	to_ret+=" Perimeter:";
	to_ret+=help(perimeter());
	to_ret+=" Area:";
	to_ret+=help(area());
	return to_ret;
	//this overriding member function returns the Circle object's description ( color, type, measurements, perimeter and area) like Red Circle Position:(x,y) Radius:Value1 Perimeter:Value2 Area:Value3
}
Square::~Square(){

}
double Square::getLength() const {
		return length;
	}

	void Square::setLength(double length) {
		this->length = length;
	}
