/*
 * Sphere.h
 *
 *  Created on: Apr 20, 2019
 *      Author: rizwa
 */

#ifndef SPHERE_H_
#define SPHERE_H_
#include<iostream>
using namespace std;
#include<string>
#include<math.h>
#include"ThreeDShape.h"
class Sphere:public ThreeDShape {
double radius;
public:
	Sphere();
	Sphere(const string& color, double x, double y, double z, double radius);//a constructor that invokes the base 3DShape constructor then sets its own radius instance value.
	virtual double voulme(); //this overriding member function computes and returns the Spehere object's volume value.
	virtual string toString();//this overriding member function returned the object's description ( color, type, measurements, volume) like
	//Red Sphere Position:(x,y,z) Radius:Value1 Vloume:Value3
	virtual ~Sphere();

	double getRadius() const ;
	void setRadius(double radius);
};

#endif /* SPHERE_H_ */
