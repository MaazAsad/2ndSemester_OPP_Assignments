/*
 * TwoDPoint.h
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#ifndef TWODPOINT_H_
#define TWODPOINT_H_

class TwoDPoint {
	double x,y;
public:
	TwoDPoint(); //Default constructor
	TwoDPoint(double, double); //Parameterized constructor
	double getX() const; //a const member function returning the x coordinate value
	void setX(double); //a member function setting the x coordinate value
	double getY()const; // a const member function returning the y coordinate value.
	void setY(double); //a member function setting the y coordinate value.
	virtual ~TwoDPoint();
};

#endif /* TWODPOINT_H_ */
