/*
 * TwoDShape.h
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#ifndef TWODSHAPE_H_
#define TWODSHAPE_H_
#include"TwoDPoint.h"
#include<iostream>
using namespace std;
#include<string>
#include"Shape.h"
#include<sstream>
class TwoDShape:public Shape {
	TwoDPoint twod;

public:

	TwoDShape(); //Default constructor
	TwoDShape(const string& color , double x, double y); //Parameterized constructor that invokes the base Shape constructor to set color then sets its own coordinates instance value.
	virtual string toString();
	virtual double area(); //member function that computes and returns the object's area. It must be overridden in each derived class.
	virtual double perimeter(); //member function that computes and returns the object's perimeter. It must be overridden in each derived class.
	virtual ~TwoDShape();
	 string help(double in);
 TwoDPoint getPosition() const ;
};

#endif /* TWODSHAPE_H_ */
