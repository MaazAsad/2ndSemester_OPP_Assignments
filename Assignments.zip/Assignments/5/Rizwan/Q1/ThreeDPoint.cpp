/*
 * ThreeDPoint.cpp
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#include "ThreeDPoint.h"


	ThreeDPoint::ThreeDPoint(){

		z=0.0;
		//Default constructor
	}
	ThreeDPoint::ThreeDPoint(double X,double Y, double Z):TwoDPoint(X,Y){

z=Z;
		//Parameterized constructor that invokes the base 2DPoint class to set x,y coordinates values then sets its z dimension.
	}
	double ThreeDPoint::getZ()const{
	return z;

		// a const member function returning the Z coordinate value.
	}
	void ThreeDPoint::setZ(double Z){
		z=Z;
		//a member function setting the Z coordinate value.
	}
ThreeDPoint::~ThreeDPoint(){

	}
