/*
 * Shop.cpp
 *
 *  Created on: Apr 25, 2019
 *      Author: sameet_asadullah
 */

#include "Shop.h"

Shop::Shop()  {
curr=0;
cap=1;	
ptr = new Computer;
}

Shop::Shop(int s) {
	
		cap = s;
		curr = 0;
		ptr = new Computer[cap];
	
}

void Shop::manufactureComputer() {
	if (curr < cap) {
		int cap, tp, noa, nos, nor, sor;
		string type;
		float clk;
		cout << "\t\t\tEnter no of adders: ";
			cin >> noa;
			cout << "\t\t\tEnter no of subtractors: ";
			cin >> nos;
			cout << "\t\t\tEnter no of registers: ";
			cin >> nor;
			cout << "\t\t\tEnter cap of registers: ";
			cin >> sor;
			cout << "\t\t\tEnter clock: ";
			cin >> clk;
			CPU cpu(noa, nos, nor, sor, clk);
		cout << "\t\t\tEnter Capacity of Physical Memory: ";
		cin >> cap;
		PhysicalMemory pm(cap);

		cout << "\t\t\tEnter Total Ports: ";
		cin >> tp;
		string *typ=new string[tp];
		int *br=new int[tp];
		for (int i = 0; i < tp; i++) {

			cout << "\t\tType of port " << i + 1 << ": ";
			cin>>typ[i];
			cout << "\t\tBaud_rate of port " << i + 1 << ": ";
			cin >> br[i];

		}
		cout << "Enter Capacity of Main Memory: ";
		cin >> cap;
		cout << "Enter Technology type of Main Memory: ";
		cin >> type;
		MainMemory mm(cap, type);
		MotherBoard mb(mm,tp, typ,br);



		ptr[curr].setCpu(cpu);
		ptr[curr].setMb(mb);
		ptr[curr].setPm(pm);
		curr++;
	}
}

void Shop::viewList() {
	for (int i = 0; i < cap; i++) {
		cout<<"No of adders of cpu of Computer "<<i+1<<": \n"<<ptr[i].getCpu().getAlu().getNoOfAdders()<<endl;
		cout<<"No of subtractors of cpu of Computer "<<i+1<<": \n"<<ptr[i].getCpu().getAlu().getNoOfSubtractors()<<endl;
		cout<<"No of registers of cpu of Computer "<<i+1<<": \n"<<ptr[i].getCpu().getAlu().getNoOfRegisters()<<endl;
		cout<<"cap of registers of cpu of Computer "<<i+1<<": \n"<<ptr[i].getCpu().getAlu().getsizeOfRegisters()<<endl;
		cout<<"Clock of Computer "<<i+1<<": \n"<<ptr[i].getCpu().getCu().getClock()<<endl;
		cout << "Capacity of Physical Memory of Computer " << i + 1 << ": \n"
				<< ptr[i].getPm().getCapacity() << endl;
		cout<<"Total Ports of Computer "<<i+1<<": \n"<<ptr[i].getMb().getPcap()<<endl;
		for (int j=0 ; j<ptr[i].getMb().getPcap() ; j++) {
			cout<<"Type of Port "<<j+1<<" of Computer "<<i+1<<": \n"<<ptr[i].getMb().getPorts()[j].getType()<<endl;
			cout<<"Baud_rate of Port "<<j+1<<" of Computer "<<i+1<<": \n"<<ptr[i].getMb().getPorts()[j].getBaudRate()<<endl;
		}
		cout<<"Capacity of main memory of Computer "<<i+1<<": \n"<<ptr[i].getMb().getMm().getCapacity()<<endl;
		cout<<"Technology type of main memory of Computer "<<i+1<<": \n"<<ptr[i].getMb().getMm().getTechnologyType()<<endl;

	}
}

Shop::~Shop() {
}

