/*
 * ControlUnit.cpp
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#include "ControlUnit.h"

ControlUnit::ControlUnit() {
	// TODO Auto-generated constructor stub
clock=0.0;
}

ControlUnit::ControlUnit(double clk){
	clock=clk;
}
ControlUnit::~ControlUnit() {
	// TODO Auto-generated destructor stub
}


double ControlUnit::getClock() const {
	return clock;
}

void ControlUnit::setClock(double clock) {
	this->clock = clock;
}
