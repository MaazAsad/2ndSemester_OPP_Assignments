/*
 * Computer.cpp
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#include "Computer.h"

Computer::Computer() {
	// TODO Auto-generated constructor stub
		 pm=new PhysicalMemory;
		 mb=new MotherBoard;
		 cpu=new CPU;
}
Computer::Computer( CPU c_p_u, PhysicalMemory p_m,MotherBoard m_b){
	 	 	 pm=new PhysicalMemory;
	 	 	 pm=&p_m;
			 mb=new MotherBoard;
			 mb=&m_b;
			 cpu=new CPU;
			 cpu=&c_p_u;
}

Computer::~Computer() {
	// TODO Auto-generated destructor stub
}

 CPU Computer::getCpu() const {
	return cpu[0];
}

void Computer::setCpu( CPU cpu) {
	(*this).cpu[0] = cpu;
}

 MotherBoard Computer::getMb() const {
	return mb[0];
}

void Computer::setMb( MotherBoard mb) {
	(*this).mb[0] = mb;

}

 PhysicalMemory Computer::getPm() const {
	return pm[0];
}

void Computer::setPm( PhysicalMemory pm) {
	(*this).pm[0] = pm;
}
