/*
 * CPU.h
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#ifndef CPU_H_
#define CPU_H_
#include"ControlUnit.h"
#include"ALU.h"
#include<iostream>
using namespace std;
#include<string>
class CPU {
	ALU alu;
	ControlUnit cu;
public:
	CPU();
	CPU(int,int,int,int,double);
	virtual ~CPU();

	 ALU getAlu() const ;
	void setAlu(const ALU alu);
	 ControlUnit getCu() const;
	void setCu(const ControlUnit& cu);
};

#endif /* CPU_H_ */
