/*
 * ALU.cpp
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#include "ALU.h"

	ALU::ALU(){
	NoOfAdders=0;
	NoOfSubtractor=0;
	NoOfRegisters=0;
	sizeOfRegisters=0;
	}
	ALU::ALU(int a,int b,int c,int d){
		NoOfAdders=a;
		NoOfSubtractor=b;
		NoOfRegisters=c;
		sizeOfRegisters=d;
	}

ALU::~ALU() {
	// TODO Auto-generated destructor stub
}


int ALU::getNoOfAdders() const {
	return NoOfAdders;
}

void ALU::setNoOfAdders(int noOfAdders) {
	NoOfAdders = noOfAdders;
}

int ALU::getNoOfRegisters() const {
	return NoOfRegisters;
}

void ALU::setNoOfRegisters(int noOfRegisters) {
	NoOfRegisters = noOfRegisters;
}

int ALU::getNoOfSubtractors() const {
	return NoOfSubtractor;
}

void ALU::setNoOfSubtractors(int noOfSubtractor) {
	NoOfSubtractor = noOfSubtractor;
}

int ALU::getsizeOfRegisters() const {
	return sizeOfRegisters;
}

void ALU::setsizeOfRegisters(int sizeOfRegisters) {
	this->sizeOfRegisters = sizeOfRegisters;
}
