/*
 * MotherBoard.cpp
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#include "MotherBoard.h"

MotherBoard::MotherBoard() {
	// TODO Auto-generated constructor stub
	mm=new MainMemory;
	//: A MainMemory
	p_cap=0;
	ports=new Port[p_cap];//: ports array
}
MotherBoard::MotherBoard( MainMemory m,int p_c, string * typ, int * br){
	mm=new MainMemory(m);
	//: A MainMemory
	ports=new Port[p_c];//: ports array
	p_cap=p_c;
	for(int i=0;i<p_cap;i++)
{
		ports[i].setType(typ[i]);
		ports[i].setBaudRate(br[i]);
		}
}
MotherBoard::~MotherBoard() {
	// TODO Auto-generated destructor stub
}
MainMemory MotherBoard::getMm() const {
		return mm[0];
	}

	void MotherBoard::setMm( MainMemory*& mm) {
		this->mm = mm;
	}

 Port* MotherBoard::getPorts() const {
		return ports;
	}

	void MotherBoard::setPorts(int c,const string *& typ,const int *& br) {
	int j=0;
		for(int i=p_cap;i<(c+p_cap);i++)
	{
			ports[i].setType(typ[j]);
			ports[i].setBaudRate(br[j]);
j++;
	}
	}
int MotherBoard::getPcap(){
	return p_cap;
}
