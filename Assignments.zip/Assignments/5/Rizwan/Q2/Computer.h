/*
 * Computer.h
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#ifndef COMPUTER_H_
#define COMPUTER_H_
#include"CPU.h"
#include"MotherBoard.h"
#include"PhysicalMemory.h"
class Computer {
	PhysicalMemory *pm;//: A
	MotherBoard *mb;//: A
	 CPU *cpu;//: A
public:

	Computer();
	Computer(	 CPU, PhysicalMemory,MotherBoard);
	virtual ~Computer();

	 CPU getCpu() const ;
	void setCpu( CPU cpu) ;
	 MotherBoard getMb() const ;
	void setMb( MotherBoard mb);
	PhysicalMemory getPm() const ;
	void setPm(PhysicalMemory pm);
};

#endif /* COMPUTER_H_ */
