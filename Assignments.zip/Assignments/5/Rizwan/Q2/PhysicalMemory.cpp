/*
 * PhysicalMemeory.cpp
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#include "PhysicalMemory.h"

PhysicalMemory::PhysicalMemory() {
	// TODO Auto-generated constructor stub
capacity=0;
}
PhysicalMemory::PhysicalMemory(int pm){
	capacity=pm;
}
PhysicalMemory::~PhysicalMemory() {
	// TODO Auto-generated destructor stub
}

int PhysicalMemory::getCapacity() const {
		return capacity;
	}

void PhysicalMemory::setCapacity(int capacity) {
		this->capacity = capacity;
	}
