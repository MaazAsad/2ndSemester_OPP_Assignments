/*
 * CPU.cpp
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#include "CPU.h"

CPU::CPU() {
	// TODO Auto-generated constructor stub

}

CPU::~CPU() {
	// TODO Auto-generated destructor stub
}
CPU::CPU(int a,int b,int c,int d,double e):alu(a,b,c,d),cu(e){

}

ALU CPU::getAlu() const {
	return alu;
}

void CPU::setAlu(const ALU alu) {
	this->alu = alu;
}

ControlUnit CPU::getCu() const {
	return cu;
}

void CPU::setCu(const ControlUnit& cu) {
	this->cu = cu;
}
