/*
 * Port.h
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#ifndef PORT_H_
#define PORT_H_
#include<iostream>
using namespace std;
#include<string>

class Port {
	string type;//: a string (Possible values : VGI Port,I/O Port,USB Port,HDMI Port etc)
	int baud_rate;//: an int
public:
	Port();
	Port(string,int);
	virtual ~Port();
	int getBaudRate() const;
	void setBaudRate(int baudRate) ;
	const string& getType() const;

	void setType(const string& type);
};

#endif /* PORT_H_ */
