/*
 * PhysicalMemeory.h
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#ifndef PHYSICALMEMORY_H_
#define PHYSICALMEMORY_H_

class PhysicalMemory {
	int capacity;//: an int
public:
	PhysicalMemory();
	PhysicalMemory(int);
	virtual ~PhysicalMemory();

	int getCapacity() const;
	void setCapacity(int capacity);
};

#endif /* PHYSICALMEMEORY_H_ */
