/*
 * ControlUnit.h
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#ifndef CONTROLUNIT_H_
#define CONTROLUNIT_H_
#include<iostream>
using namespace std;
#include<string>
class ControlUnit {
	double clock;
public:
	ControlUnit();
	ControlUnit(double);

	virtual ~ControlUnit();

	double getClock() const;
	void setClock(double clock);
};

#endif /* CONTROLUNIT_H_ */
