/*
 * MotherBoard.h
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#ifndef MOTHERBOARD_H_
#define MOTHERBOARD_H_
#include<iostream>
using namespace std;
#include<string>
#include"MainMemory.h"
#include"Port.h"

class MotherBoard {
	MainMemory *mm;//: A MainMemory
	Port *ports;//: ports array
	int p_cap;
public:

	MotherBoard();
	MotherBoard( MainMemory,int ,string * typ, int * br);
	virtual ~MotherBoard();
int getPcap();
	 MainMemory getMm() const ;
	void setMm( MainMemory*& mm);
	 Port* getPorts() const;
	void setPorts(int c,const string *& typ,const int *& br);
};

#endif /* MOTHERBOARD_H_ */
