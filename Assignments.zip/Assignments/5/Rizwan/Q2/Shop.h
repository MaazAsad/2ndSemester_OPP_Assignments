/*
 * Shop.h
 *
 *  Created on: Apr 25, 2019
 *      Author: sameet_asadullah
 */

#ifndef SHOP_H_
#define SHOP_H_

#include"Computer.h"

class Shop {
	Computer* ptr;
	int cap, curr;

public:
	Shop();
	Shop (int s);
	void manufactureComputer();
	void viewList();
	virtual ~Shop();
};

#endif /* SHOP_H_ */
