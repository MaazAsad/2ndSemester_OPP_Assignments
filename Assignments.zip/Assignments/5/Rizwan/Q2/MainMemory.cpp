/*
 * MainMemory.cpp
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#include "MainMemory.h"

MainMemory::MainMemory() {
	// TODO Auto-generated constructor stub
	capacity=0;//: an int
	technologyType="";//: a string (Possible values :Semiconductor, Silicon);
}
MainMemory::MainMemory(int a,string b){
	capacity=a;//: an int
		technologyType=b;//: a string (Possible values :Semiconductor, Silicon);
}

MainMemory::~MainMemory() {
	// TODO Auto-generated destructor stub
}


int MainMemory::getCapacity() const {
	return capacity;
}

void MainMemory::setCapacity(int capacity) {
	this->capacity = capacity;
}

string MainMemory::getTechnologyType() const {
	return technologyType;
}

void MainMemory::setTechnologyType(const string technologyType) {
	this->technologyType = technologyType;
}
