/*
 * ALU.h
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#ifndef ALU_H_
#define ALU_H_
#include<iostream>
using namespace std;
#include<string>
class ALU {
	int NoOfAdders;
	int NoOfSubtractor;
	int NoOfRegisters;
	int sizeOfRegisters;
public:
	ALU();
	ALU(int,int,int,int);
	virtual ~ALU();

	int getNoOfAdders() const;
	void setNoOfAdders(int noOfAdders);
	int getNoOfRegisters() const ;
	void setNoOfRegisters(int noOfRegisters);
	int getNoOfSubtractors() const;
	void setNoOfSubtractors(int noOfSubtractor);
	int getsizeOfRegisters() const;
	void setsizeOfRegisters(int sizeOfRegisters);
};

#endif /* ALU_H_ */
