/*
 * Port.cpp
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#include "Port.h"

Port::Port() {

	type="";//: a string (Possible values : VGI Port,I/O Port,USB Port,HDMI Port etc)
	baud_rate=0;//: an int
	// TODO Auto-generated constructor stub

}
Port::Port(string a,int b){
	type=a;//: a string (Possible values : VGI Port,I/O Port,USB Port,HDMI Port etc)
	baud_rate=b;//: an int
}
Port::~Port() {
	// TODO Auto-generated destructor stub
}



int Port::getBaudRate() const {
	return baud_rate;
}

void Port::setBaudRate(int baudRate) {
	baud_rate = baudRate;
}

const string& Port::getType() const {
	return type;
}

void Port::setType(const string& type) {
	this->type = type;
}

