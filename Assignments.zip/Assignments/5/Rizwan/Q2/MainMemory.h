/*
 * MainMemory.h
 *
 *  Created on: Apr 18, 2019
 *      Author: rizwa
 */

#ifndef MAINMEMORY_H_
#define MAINMEMORY_H_
#include<iostream>
using namespace std;
#include<string>

class MainMemory {
	int capacity;//: an int
	string technologyType;//: a string (Possible values :Semiconductor, Silicon);
public:
	MainMemory();
	MainMemory(int,string);
	virtual ~MainMemory();

	int getCapacity() const;
	void setCapacity(int capacity);
	 string getTechnologyType() const ;
	void setTechnologyType(const string technologyType);
};

#endif /* MAINMEMORY_H_ */
