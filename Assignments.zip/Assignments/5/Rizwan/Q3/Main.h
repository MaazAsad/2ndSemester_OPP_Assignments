/*
 * Main.h
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */
#include"Sandwiches.h"
#include"Fried.h"
#include"Pizza.h"
#include"Nuggets.h"
#include"Fries.h"
#include"Burger.h"
#ifndef MAIN_H_
#define MAIN_H_
#include"List.h"

class Main:public List {
	Sandwiches S;
	Pizza P;
	Fried *F;
public:
	Main();
	void Create_item();
	virtual ~Main();
};

#endif /* MAIN_H_ */
