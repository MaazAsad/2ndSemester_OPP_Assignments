/*
 * Burger.h
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#ifndef BURGER_H_
#define BURGER_H_
#include"Fried.h"
class Burger:public Fried {
	string patties;
public:
	Burger(string,string,string);
	virtual ~Burger();

	string getPatties() const;
	 void setSaucel(const string& saucel);
	 void setType(const string& type);


	void setPatties(const string& patties) ;
};

#endif /* BURGER_H_ */
