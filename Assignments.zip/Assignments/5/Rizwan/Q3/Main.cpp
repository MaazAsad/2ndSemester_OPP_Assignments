/*
 * Main.cpp
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#include "Main.h"

void Main::Create_item(){
	cout<<"Welome to our main menu:\n";
	cout<<"What would you like to have:\n";
	cout<<"We offer \n1) Sandwiches: Enter 1 for it\n2) Pizza: Enter 2 for it\n3) Fried Item : Enter 3 for it\n";
	int item;
	cin>>item;
	if(item==1){
		string fill;
			cout<<"You can choose any of these fillings\n1) Smoked Chicken: Enter Smoked\n2) BBQ Chicken: Enter BBQ\n3) Chicken Jalapeno: Enter Jalapeno\n4) Vegetable: Enter Vegetable\n";
			cin>>fill;
		string type;
			cout<<"You can choose any of these type\n1) Grilled:Enter Grilled\n2) Plain:Enter Plain\n";
			cin>>type;
			S.setType(type);
			S.setFillings(fill);
	}
	else if(item==2){
		string crust;
			cout<<"You can choose any of these Crust Options\n1) Fresh Pan: Enter Fpan\n2) Stuffed: Enter Stuffed\n3) Hand Tossed: Enter Tossed\n";
			cin>>crust;;
		string top;
			cout<<"You can choose any of these topping options\n1) Pepperoni:Enter pp\n2) Mushrooms:Enter Mush\n3) Extra cheese :Enter E_chese\n4) Black olives: Enter Olives";
			cin>>top;
		int size;
			cout<<"You can choose any of theseSize\n1) Small:Enter 6\n2) Medium:Enter 9\n3) Large: Enter 11\n4) Extra Large: Enter 13";
			cin>>size;
			P.setCrust(crust);
			P.setToping(top);
			P.setSize(size);

			/*
			 * (small, medium, large,
extra-large) with three different crust options (Fresh pan, Stuffed and Hand-tossed) and many
topping options (Pepperoni, Mushrooms, Onions, Extra cheese and Black olives).
The Fried items sub-category include Nuggets, Fries and Burgers. Each Fried Item
			 *
			 *
			 *
			 */
	}
	else if(item==3){
		int fi;
		cout<<"We offer 3 Fried items\n1)Nuggets :Enter 1\n2)Fries :Enter 2\n3)Burgers :Enter 3\n";
		cin>>fi;
		if(fi==1){
			//(Chicken Nuggets, Tempura Nuggets and Crispy Chicken Nuggets) in three different shapes
			//(circle, star and heart) with dipping Sauces (Sweet and Sour, Honey Mustard, Sweet Chili and
			//Hot Mustard)
			string type;
			cout<<"You can CHoose any type of the nuggets\n1) Chicken Nuggets: Enter CN\n2) Tempura Nuggets: Enter TN\n Crispy Chicken Nuggets: Enter CCN";
			cin>>type;
			string shape;
			cout<<"You can choose any of the given Shape\n1) Circle: Enter cir\n2) Star: Enter Star\n3) Heart: Enter Heart\n";
			cin>>shape;
			string sauce;
			cout<<"You can CHoose Any of the Given Sauces\n1) Sweet: Enter sweet\n2) Sour: Enter sour\n3) Honey Mustrard: Enter Honey\n4) Sweet Chill: Enter Chill\n5) Hot Mustarad: Enter HM";
			cin>>sauce;
			F=new Nuggets(sauce,type,shape);
		}
		else if(fi==2){

						string type;
						cout<<"You can CHoose any type of the nuggets\n1) Currly: Enter C\n2) Plain: Enter p\n";
						cin>>type;
						string servings;
						cout<<"You can choose any of the given Shape\n1) Small: Enter s\n2) Regular: Enter R\n3) Jamboo: Enter j\n";
						cin>>servings;
						string sauce;
						cout<<"You can CHoose Any of the Given Sauces\n1) Garlic-Mayo: Enter GM\n2) Chocolate: Enter Ch\n3) Cheddar Cheese: Enter CC\n";
						cin>>sauce;
						F=new Fries(sauce,type,servings);
//, Chocolate and
		}
		else if(fi==3){
			string type;
			cout<<"You can CHoose any type of the nuggets\n1) sesame seed: Enter sss\n2) Plain: Enter p\n";
			cin>>type;
			string patties;//Beef, Crispy Chicken,
			//Grilled Chicken and fish
			cout<<"You can choose any of the given Shape\n1) Beef: Enter beef\n2) Crispy Chicken: Enter cc\n3) Grilled Chicken: Enter gc\n4) Fish: Enter fish\n";
			cin>>patties;
			string sauce;
			cout<<"You can CHoose Any of the Given Sauces\n1) Jalapeno cheese sauce: Enter JCS\n2) Classic burger sauce: Enter CBS\n3) cheese mayo: Enter CM \n4) Truffle mayo: ENter TM";
			cin>>sauce;
			F=new Burger(sauce,type,patties);
		}
	}


}
