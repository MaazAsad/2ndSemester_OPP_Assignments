/*
 * Beverges.cpp
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#include "Beverges.h"

Beverges::Beverges() {
	// TODO Auto-generated constructor stub
ptr=NULL;
}

Beverges::~Beverges() {
	// TODO Auto-generated destructor stub
}
void Beverges::create(){
		cout<<"Welcome to the Beverges\n";
		int ch;
		cout<<"What do you want\nA carbonated Drink:Enter 1\nA Juice:Enter 2\n";
		cin>>ch;
			if(ch==1){
				//name,sugarfree,size,temp
				string name;
				char s;
				int t;
				bool sugar;
				cout<<"You can enter name of any of the given drink Sprite, 7up, Pepsi, Coke, Red Bull and Fanta\n";
				cin>>name;
				cout<<"Dou you want the desired drink with sugar\n 1 as yes 0 as no\n";
				cin>>sugar;
				cout<<"Enter size as a charachter as S for small,L for Large R for regular\n";
				cin>>s;
				cout<<"do youu want it to be chiiled or normal for chilled enter a value below 17 and for normal enter 21";
				cin>>t;
			ptr=new Carbonated(name,sugar);
			ptr->setTemp(t);
			ptr->setSize(s);

			}
			else if(ch==2){
				bool pack;
							char s;
							int t;
							bool su;
							bool f;
							cout<<"Do you want a packed Juice 1 for yes 0 for no\n";
							cin>>pack;
							cout<<"Dou you want it seasonal 1 for yes 0 for no";
							cin>>su;
							cout<<"Do you want it to be fresh";
							cin>>f;
							cout<<"Enter size as a charachter as S for small,L for Large R for regular\n";
							cin>>s;
							cout<<"do youu want it to be chiiled or normal for chilled enter a value below 17 and for normal enter 21";
							cin>>t;
				ptr=new FreshJuice(pack,f,su);
				ptr->setSize(s);
				ptr->setTemp(t);
				//pack,fresh,seasonal,temp,size
			}

}
