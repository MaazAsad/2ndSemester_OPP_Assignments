/*
 * Drink.h
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#ifndef DRINK_H_
#define DRINK_H_
#include<iostream>
using namespace std;
#include<string>
class Drink {
	char size;
	int temp;//below 20=chill, 20+ =room
public:
	Drink(char,int);
	Drink();
	virtual ~Drink();

	char getSize() const;
	void setSize(char size);
	int getTemp() const;

	void setTemp(int temp) ;
};

#endif /* DRINK_H_ */
