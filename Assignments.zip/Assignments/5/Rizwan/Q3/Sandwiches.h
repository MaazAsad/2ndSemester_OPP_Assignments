/*
 * Sandwiches.h
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#ifndef SANDWICHES_H_
#define SANDWICHES_H_
#include<iostream>
using namespace std;
#include<string>
class Sandwiches{
	string fillings,type;
public:
	Sandwiches();
	Sandwiches(string,string);
	virtual ~Sandwiches();

	string getFillings() const ;
	void setFillings(const string& fillings) ;
	string getType() ;
	void setType(const string& type);
};

#endif /* SANDWICHES_H_ */
