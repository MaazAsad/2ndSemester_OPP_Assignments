/*
 * Carbonated.cpp
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#include "Carbonated.h"

Carbonated::Carbonated(string n,bool sgf):name(n),sgf(sgf) {
	// TODO Auto-generated constructor stub

}
Carbonated::Carbonated():name(""),sgf(-1){

}

Carbonated::~Carbonated() {
	// TODO Auto-generated destructor stub
}


string Carbonated::getName() const {
	return name;
}

void Carbonated::setName(string n) {
	this->name = n;
}

bool Carbonated::isSgf() const {
	return sgf;
}

void Carbonated::setSgf(bool sgf) {
	this->sgf = sgf;
}
