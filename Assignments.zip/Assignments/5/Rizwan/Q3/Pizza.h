/*
 * Pizza.h
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#ifndef PIZZA_H_
#define PIZZA_H_

#include<iostream>
using namespace std;
#include<string>
class Pizza {
	int size;
	string crust,toping;
public:
	Pizza(string,string,int);
	Pizza();
	virtual ~Pizza();

	 string getCrust() const ;
	void setCrust(const string& crust);
	int getSize() const ;
	void setSize(int size) ;
	string getToping() const;
	void setToping(const string& toping);
};

#endif /* PIZZA_H_ */
