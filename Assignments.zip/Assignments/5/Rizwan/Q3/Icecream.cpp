/*
 * Icecream.cpp
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#include "Icecream.h"

Icecream::Icecream(string s,float f):top(s),pps(f) {
	// TODO Auto-generated constructor stub

}

Icecream::~Icecream() {
	// TODO Auto-generated destructor stub
}

float Icecream::getPps() const {
		return pps;
	}

	void Icecream::setPps(float pps) {
		this->pps = pps;
	}

	 string Icecream::getTop() const {
		return top;
	}

	void Icecream::setTop(const string& top) {
		this->top = top;
	}

