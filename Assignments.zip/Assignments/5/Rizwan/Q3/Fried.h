/*
 * Fried.h
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#ifndef FRIED_H_
#define FRIED_H_
#include<iostream>
using namespace std;
#include<string>
class Fried{
protected:
	string type,saucel;
public:
	Fried(string,string);

	virtual ~Fried();

	string getSaucel() const ;

	virtual void setSaucel(const string& saucel)=0;

	string getType() const;

	virtual void setType(const string& type)=0;
};

#endif /* FRIED_H_ */
