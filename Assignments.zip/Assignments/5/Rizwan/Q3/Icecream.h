/*
 * Icecream.h
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#ifndef ICECREAM_H_
#define ICECREAM_H_
#include"Dessert.h"
class Icecream:public Dessert {
	string top;
	float pps;
public:
	Icecream(string,float);
	virtual ~Icecream();

	float getPps() const ;
	void setPps(float pps);
	string getTop() const ;
	void setTop(const string& top) ;
};

#endif /* ICECREAM_H_ */
