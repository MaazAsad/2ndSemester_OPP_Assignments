/*
 * Burger.cpp
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#include "Burger.h"

Burger::Burger(string s,string t,string p):Fried(s,t),patties(p) {
	// TODO Auto-generated constructor stub

}

Burger::~Burger() {
	// TODO Auto-generated destructor stub
}
void Burger::setSaucel(const string& saucel){
(*this).saucel=saucel;
}
void Burger::setType(const string& type){
	(*this).type=type;
}

string Burger::getPatties() const {
		return patties;
	}

void Burger::setPatties(const string& patties) {
		this->patties = patties;
	}
