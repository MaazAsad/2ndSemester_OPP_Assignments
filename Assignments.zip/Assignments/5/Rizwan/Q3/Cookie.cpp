/*
 * Cookie.cpp
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#include "Cookie.h"

Cookie::Cookie(string s,float ppg,string sw,bool su):flavor(s),ppg(ppg),shape(sw),sugarfree(su) {
	// TODO Auto-generated constructor stub

}

Cookie::~Cookie() {
	// TODO Auto-generated destructor stub
}


Cookie::Cookie(){

}

string Cookie::getFlavor() const {
	return flavor;
}

void Cookie::setFlavor(const string& flavor) {
	this->flavor = flavor;
}

float Cookie::getPpg() const {
	return ppg;
}

void Cookie::setPpg(float ppg) {
	this->ppg = ppg;
}

string Cookie::getShape() const {
	return shape;
}

void Cookie::setShape(const string& shape) {
	this->shape = shape;
}

bool Cookie::isSugarfree() const {
	return sugarfree;
}

void Cookie::setSugarfree(bool sugarfree) {
	this->sugarfree = sugarfree;
}
