/*
 * FreshJuice.cpp
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#include "FreshJuice.h"

FreshJuice::FreshJuice(bool p,bool f,bool s):pack(p),fresh(f),seasonal(s){
	// TODO Auto-generated constructor stub

}

FreshJuice::~FreshJuice() {
	// TODO Auto-generated destructor stub
}

bool FreshJuice::isFresh() const {
	return fresh;
}

void FreshJuice::setFresh(bool fresh) {
	this->fresh = fresh;
}

bool FreshJuice::isPack() const {
	return pack;
}

void FreshJuice::setPack(bool pack) {
	this->pack = pack;
}

bool FreshJuice::isSeasonal() const {
	return seasonal;
}

void FreshJuice::setSeasonal(bool seasonal) {
	this->seasonal = seasonal;
}
