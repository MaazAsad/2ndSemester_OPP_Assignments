/*
 * Beverges.h
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#ifndef BEVERGES_H_
#define BEVERGES_H_
#include<iostream>
using namespace std;
#include<string>
#include"Drink.h"
#include"Carbonated.h"
#include"FreshJuice.h"
class Beverges {
Drink *ptr;
public:
	Beverges();
	void create();
	virtual ~Beverges();


};

#endif /* BEVERGES_H_ */
