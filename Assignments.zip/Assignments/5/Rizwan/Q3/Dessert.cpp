/*
 * Dessert.cpp
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#include "Dessert.h"

Dessert::Dessert() {
	// TODO Auto-generated constructor stub

}

Dessert::~Dessert() {
	// TODO Auto-generated destructor stub
}

void Dessert::creatDes(){
	cout<<"Welcome to desserts\n";

}

Cookie Dessert::getCk() const {
	return ck;
}

void Dessert::setCk(const Cookie& ck) {
	this->ck = ck;
}

 Icecream Dessert::getIce() const {
	return ice;
}

void setIce(const Icecream& ice) {
	this->ice = ice;
}
