/*
 * List.cpp
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#include "List.h"

List::List() {
	// TODO Auto-generated constructor stub

}

List::~List() {
	// TODO Auto-generated destructor stub
}

