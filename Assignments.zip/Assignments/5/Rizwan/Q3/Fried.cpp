/*
 * Fried.cpp
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#include "Fried.h"

Fried::Fried(string s,string t){
	saucel=s;
	type=t;
	// TODO Auto-generated constructor stub
}

Fried::~Fried() {
	// TODO Auto-generated destructor stub
}

string Fried::getSaucel() const {
	return saucel;
}

string Fried::getType() const {
	return type;
}
