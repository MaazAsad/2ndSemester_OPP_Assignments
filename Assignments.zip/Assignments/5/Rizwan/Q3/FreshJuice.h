/*
 * FreshJuice.h
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#ifndef FRESHJUICE_H_
#define FRESHJUICE_H_
#include"Drink.h"
class FreshJuice:public Drink {
	bool pack;
	bool fresh;
	bool seasonal;
public:
	FreshJuice(bool,bool,bool);
	virtual ~FreshJuice();

	bool isFresh() const ;

	void setFresh(bool fresh) ;

	bool isPack() const ;
	void setPack(bool pack);

	bool isSeasonal() const ;

	void setSeasonal(bool seasonal);
};

#endif /* FRESHJUICE_H_ */
