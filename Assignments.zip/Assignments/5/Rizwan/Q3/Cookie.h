/*
 * Cookie.h
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#ifndef COOKIE_H_
#define COOKIE_H_
#include"Dessert.h"
class Cookie:public Dessert {
string flavor;
float ppg;
string shape;
bool sugarfree;
public:
Cookie();
	Cookie(string,float,string,bool);
	virtual ~Cookie();

	string getFlavor() const ;

	void setFlavor(const string& flavor);

	float getPpg() const;

	void setPpg(float ppg) ;

	 string getShape() const;
	void setShape(const string& shape);
	bool isSugarfree() const ;

	void setSugarfree(bool sugarfree) ;
};

#endif /* COOKIE_H_ */
