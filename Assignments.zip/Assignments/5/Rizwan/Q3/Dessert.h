/*
 * Dessert.h
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#include"Icecream.h"
#include"Cookie.h"


#ifndef DESSERT_H_
#define DESSERT_H_
#include<iostream>
using namespace std;
#include<string>

class Dessert {
	Icecream ice;
	Cookie ck;
public:
	Dessert();
	void creatDes();
	virtual ~Dessert();

	 Cookie getCk() const ;

	void setCk(const Cookie& ck);

	 Icecream getIce() const ;
	void setIce(const Icecream& ice) ;
};

#endif /* DESSERT_H_ */
