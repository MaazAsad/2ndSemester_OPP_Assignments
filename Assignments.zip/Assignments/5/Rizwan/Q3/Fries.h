/*
 * Fries.h
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#ifndef FRIES_H_
#define FRIES_H_
#include"Fried.h"
class Fries:public Fried {
	string servings;
public:
	Fries(string,string,string);
	virtual ~Fries();
	void setSaucel(const string& saucel);
	void setType(const string& type);

string getServings() const;
	void setServings(const string& servings) ;
};

#endif /* FRIES_H_ */
