/*
 * Fries.cpp
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#include "Fries.h"

Fries::Fries(string saucel,string type1,string serving):Fried(saucel,type1),servings(serving){

}
Fries::~Fries(){

}
void Fries::setSaucel(const string& saucel){
(*this).saucel=saucel;
}
void Fries::setType(const string& type){
	(*this).type=type;
}

string Fries::getServings() const {
		return servings;
	}
void Fries::setServings(const string& servings) {
		this->servings = servings;
	}
