/*
 * Nuggets.cpp
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#include "Nuggets.h"

Nuggets::Nuggets(string saucel,string type1,string shape):Fried(saucel,type1),shape(shape) {

	// TODO Auto-generated constructor stub

}

Nuggets::~Nuggets() {
	// TODO Auto-generated destructor stub
}



void Nuggets::setSaucel(const string& saucel){
(*this).saucel=saucel;
}
void Nuggets::setType(const string& type){
	(*this).type=type;
}

string Nuggets::getShape() const {
	return shape;
}

void Nuggets::setShape(const string& shape) {
	this->shape = shape;
}
