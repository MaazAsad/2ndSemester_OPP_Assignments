/*
 * Drink.cpp
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#include "Drink.h"
Drink::Drink(){

}
Drink::Drink(char s,int t):size(s),temp(t){
	// TODO Auto-generated constructor stub

}

Drink::~Drink() {
	// TODO Auto-generated destructor stub
}

char Drink::getSize() const {
		return size;
	}

	void Drink::setSize(char size) {
		this->size = size;
	}

	int Drink::getTemp() const {
		return temp;
	}

	void Drink::setTemp(int temp) {
		this->temp = temp;
	}
