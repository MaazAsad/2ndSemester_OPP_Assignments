/*
 * Pizza.cpp
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#include "Pizza.h"

Pizza::Pizza(string crust,string topping,int size):crust(crust),toping(topping),size(size) {
	// TODO Auto-generated constructor stub

}

Pizza::~Pizza() {
	// TODO Auto-generated destructor stub
}
Pizza::Pizza() {
	// TODO Auto-generated destructor stub
}
string Pizza::getCrust() const {
		return crust;
	}

	void Pizza::setCrust(const string& crust) {
		this->crust = crust;
	}

	int Pizza::getSize() const {
		return size;
	}

	void Pizza::setSize(int size) {
		this->size = size;
	}

	string Pizza::getToping() const {
		return toping;
	}

	void Pizza::setToping(const string& toping) {
		this->toping = toping;
	}
