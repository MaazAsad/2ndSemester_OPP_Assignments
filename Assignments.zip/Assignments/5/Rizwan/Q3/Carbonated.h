/*
 * Carbonated.h
 *
 *  Created on: Apr 25, 2019
 *      Author: rozi
 */

#ifndef CARBONATED_H_
#define CARBONATED_H_
#include "Drink.h"
class Carbonated:public Drink {
	string name;
	bool sgf;
public:
	Carbonated(string,bool);
	Carbonated();
	virtual ~Carbonated();

	string getName() const;
	void setName(string n);
	bool isSgf() const ;
	void setSgf(bool sgf) ;
};

#endif /* CARBONATED_H_ */
