/*
 * Nuggets.h
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#ifndef NUGGETS_H_
#define NUGGETS_H_
#include"Fried.h"
class Nuggets:public Fried {

	string shape;
public:
	Nuggets(string,string,string);
	virtual ~Nuggets();
 void setSaucel(const string& saucel);
 void setType(const string& type);

	string getShape() const ;

	void setShape(const string& shape) ;
};

#endif /* NUGGETS_H_ */
