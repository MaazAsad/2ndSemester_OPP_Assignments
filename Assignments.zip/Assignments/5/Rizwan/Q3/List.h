/*
 * List.h
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#ifndef LIST_H_
#define LIST_H_
#include<iostream>
using namespace std;
#include<cmath>
#include<string>

class List {

	string name,Id;
	double price;

public:
	List();
	virtual ~List();
};

#endif /* LIST_H_ */
