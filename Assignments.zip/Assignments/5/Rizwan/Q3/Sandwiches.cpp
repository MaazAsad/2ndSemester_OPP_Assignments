/*
 * Sandwiches.cpp
 *
 *  Created on: Apr 24, 2019
 *      Author: rozi
 */

#include "Sandwiches.h"

Sandwiches::Sandwiches(string f,string t):fillings(f),type(t) {
	// TODO Auto-generated constructor stub

}
Sandwiches::Sandwiches(){

}
Sandwiches::~Sandwiches() {
	// TODO Auto-generated destructor stub
}



string Sandwiches::getFillings() const {
	return fillings;
}

void Sandwiches::setFillings(const string& fillings) {
	this->fillings = fillings;
}

string Sandwiches::getType()  {
	return type;
}

void Sandwiches::setType(const string& type) {
	this->type = type;
}
