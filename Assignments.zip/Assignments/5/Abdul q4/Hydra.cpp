/*
 * Hydra.cpp
 *
 *  Created on: 21 Apr 2019
 *      Author: abdulrehman
 */

#include "Hydra.h"

Hydra::Hydra(string n, int l, int h, int f, int nl, int pd, int p) :
		Creature(n, l, h, f, p), neckLength(nl), poisonDose(pd) {
}
void Hydra::InjectPoison(Creature& c) {
	if (c.alive() == 1 && this->alive() == 1) {
		if (distance(c.position, this->position) <= this->neckLength) {
			c.Weak((this->AttackPoints() + this->poisonDose));
			if (c.alive() == false && alive() == true) {
				this->setLevel((level + 1));
			}
		}
	}
}
Hydra::~Hydra() {
}
