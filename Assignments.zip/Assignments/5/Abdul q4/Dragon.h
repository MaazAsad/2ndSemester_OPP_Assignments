/*
 * Dragon.h
 *
 *  Created on: 21 Apr 2019
 *      Author: abdulrehman
 */

#ifndef DRAGON_H_
#define DRAGON_H_
#include "Creature.h"
#include<string>
#include<iostream>
using namespace std;
class Dragon: public Creature {
	int flameRange;
public:
	Dragon(string n, int l, int h, int f, int fr, int p = 0);
	void Fly(int pos);
	void BlowFlame(Creature& c);
	~Dragon();
};

#endif /* DRAGON_H_ */

