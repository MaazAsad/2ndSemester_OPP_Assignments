/*
 * Creature.h
 *
 *  Created on: 20 Apr 2019
 *      Author: abdulrehman
 */

#ifndef CREATURE_H_
#define CREATURE_H_
#include<iostream>
#include<string>
using namespace std;
class Creature {
protected:
	string name;
	int level;
	int points;
	int force;
public:
	int position;
	Creature(string n, int l, int h, int f, int p = 0);
	bool alive();
	int AttackPoints();
	void Move(int x);
	void setLevel(int x);
	int getLevel() const;
	void GoodBye();
	void Weak(int x);
	void display();
	int distance(int x, int y);
	~Creature();
};

#endif /* CREATURE_H_ */
