/*
 * Dragon.cpp
 *
 *  Created on: 21 Apr 2019
 *      Author: abdulrehman
 */

#include "Dragon.h"

Dragon::Dragon(string n, int l, int h, int f, int fr, int p) :
		Creature(n, l, h, f, p), flameRange(fr) {
}
void Dragon::Fly(int pos) {
	position = pos;
}
void Dragon::BlowFlame(Creature& c) {
	if (c.alive() == 1 && this->alive() == 1) {
		if (distance(c.position, this->position) <= this->flameRange) {
			c.Weak(this->AttackPoints());
			this->Weak((this->distance(c.position, this->position)));
			if (c.alive() == 0 && this->alive() == 1) {
				this->setLevel((level + 1));
			}
		}
		this->Weak((this->distance(c.position, this->position)));
	}
}
Dragon::~Dragon() {
}
