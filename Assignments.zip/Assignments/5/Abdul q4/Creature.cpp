/*
 * Creature.cpp
 *
 *  Created on: 20 Apr 2019
 *      Author: abdulrehman
 */

#include "Creature.h"

Creature::Creature(string n, int l, int h, int f, int p) :
		name(n), level(l), points(h), force(f), position(p) {
}
bool Creature::alive() {
	if (points > 0) {
		return true;
	}
	return false;
}
int Creature::AttackPoints() {
	if (points > 0) {
		return (level * force);
	}
	return 0;
}
void Creature::Move(int x) {
	position += x;
}
void Creature::GoodBye() {
	string str = "";
	str += name;
	str += " is no more!";
	cout << str;
}
void Creature::setLevel(int x) {
	level = x;
}
int Creature::getLevel() const {
	return level;
}
void Creature::Weak(int x) {
	points = points - x;
	if (points <= 0) {
		points = 0;
		GoodBye();
	}
}
void Creature::display() {
	string str = "";
	str += name;
	str += " is the name of the creature, ";
	str += to_string(level);
	str += " is its level, ";
	str += to_string(points);
	str += " is its number of health points, ";
	str += to_string(force);
	str += " is its force, ";
	str += to_string(AttackPoints());
	str += " is its number of attack points and ";
	str += to_string(position);
	str += " is its position.";
	cout << str;
}
int Creature::distance(int x, int y) {
	return (abs(x - y));
}
Creature::~Creature() {
}
