/*
 * Hydra.h
 *
 *  Created on: 21 Apr 2019
 *      Author: abdulrehman
 */

#ifndef HYDRA_H_
#define HYDRA_H_
#include "Creature.h"
#include<iostream>
#include<string>
using namespace std;
class Hydra: public Creature {
private:
	int neckLength;
	int poisonDose;
public:
	Hydra(string n, int l, int h, int f, int nl, int pd, int p = 0);
	void InjectPoison(Creature& c);
	~Hydra();
};

#endif /* HYDRA_H_ */
