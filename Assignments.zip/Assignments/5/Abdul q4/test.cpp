
// #include "dragons.cpp"
#include "Dragon.cpp"
#include "Hydra.cpp"
#include "Creature.cpp"


#include <gtest/gtest.h>

//----------------------------------------------------------------------------
//------------------------Class Creature--------------------------------------
//----------------------------------------------------------------------------

//-------------------Function alive() TEST 1---------------- (Marks=1)
TEST(Class_Creature, alive_true)
{
	Creature c1("Dom", 1, 2, 3, 4);//c1(name, level, points, force, position)
	ASSERT_TRUE(c1.alive());//should return true as points>0
}

//-------------------Function alive() TEST 2---------------- (Marks=1)
TEST(Class_Creature, alive_false)
{
	Creature c1("Dom", 1, 0, 3, 4);
	ASSERT_FALSE(c1.alive());//should return false as points<0
}

//-------------------Function AttackPoints() TEST 1---------------- (Marks=1)
TEST(Class_Creature, AttackPoints_if_alive)
{
	Creature c1("Dom", 1, 2, 3, 4); //c1(name, level, points, force, position)
	ASSERT_EQ(3,c1.AttackPoints());	//since creature's points are >0 so it's alive; as a result c1.Attackpoints() should return level*force value which is 3
}

//-------------------Function AttackPoints() TEST 2---------------- (Marks=1)
TEST(Class_Creature, AttackPoints_if_NOT_alive)
{
	Creature c1("Dom", 1, 0, 3, 4); //c1(name, level, points, force, position)
	ASSERT_EQ(0,c1.AttackPoints());	//since creature is not alive (i.e points<0 so ; as a result c1.Attackpoints() should return 0

}

//-------------------Function Move() TEST 1---------------- (Marks=1)
TEST(Class_Creature, Move)
{
	Creature c1("Dom", 1, 0, 3, 4); //c1(name, level, points, force, position)
	c1.Move(3);			//should add 3 to the current value of position i.e position+=3
	ASSERT_EQ(7,c1.position);
}

//-------------------Function Weak() TEST 1---------------- (Marks=1)
TEST(Class_Creature, Weak_true)
{
	Creature c1("Dom", 2, 6, 8, 7); //c1(name, level, points, force, position)
	c1.Weak(3);	//deduct 3 from points(which is 6 in this case)
	ASSERT_TRUE(c1.alive());//should return true as points>0

}

//-------------------Function Weak() TEST 1---------------- (Marks=1)
TEST(Class_Creature, Weak_false)
{
	Creature c1("Dom", 2, 6, 8, 7); //c1(name, level, points, force, position)
	c1.Weak(7);	//deduct 7 from points(which is 6 in this case)
	ASSERT_FALSE(c1.alive());//should return false as points<0

}

//----------------------------------------------------------------------------
//------------------------Class Dragon----------------------------------------
//----------------------------------------------------------------------------

//--------------Function Fly() TEST 1---------------------- (Marks=1)
TEST(Class_Dragon, Fly)
{
	Dragon dragon("Dragon red", 2, 10, 3, 20);//dragon(name,level,points,force,flamerange,position);since position is not passed, so it is considerd 0 by default (See Creature.h)

	int pos=3;

	dragon.Fly(pos);
	ASSERT_EQ(dragon.position,3); //since position was assigned 0 by default, now it is assigned value 3
}


//--------------Function BlowFlame() TEST 1---------------------- (Marks=1)
TEST(Class_Dragon, BlowFlame)
{
	Dragon dragon("Dragon red", 2, 10, 3, 20); //dragon(name,level,points,force,flamerange,position) // position gets default value 0 here
	Hydra hydra("Hydra evil", 2, 10, 1, 10, 1, 42); //Hydra(name,level,points,force,neckLength,poisonDose,position)

	dragon.BlowFlame(hydra);
	//check if hydra and dragon are alive? also check their positions and flamranges
	//call function weak; calculate attackpoints; if both are still alive then increment the level by 1
	ASSERT_FALSE(dragon.alive()); //should return false,as dragon is not alive

}


//----------------------------------------------------------------------------
//------------------------Class Hydra-----------------------------------------
//----------------------------------------------------------------------------
//--------------Function InjectPoison() TEST 1---------------------- (Marks=1)
TEST(Class_Dragon, InjectPoison)
{
	Dragon dragon("Dragon red", 2, 10, 3, 20); //dragon(name,level,points,force,flamerange,position) // position gets default value 0 here
	Hydra hydra("Hydra evil", 2, 10, 1, 10, 1, 42); //Hydra(name,level,points,force,neckLength,poisonDose,position)

	hydra.InjectPoison(dragon);
	ASSERT_TRUE(hydra.alive());
}



//----------------------------------------------------------------------------
//------------------------Class dragons.cpp-----------------------------------
//----------------------------------------------------------------------------
//--------------Function Fight()   TEST 1---------------------- (Marks=1)
// TEST(Class_dragonsCPP, Fight)
// {
// 	Dragon dragon("Dragon red", 2, 10, 3, 20); //dragon(name,level,points,force,flamerange,position) // position gets default value 0 here
// 	Hydra hydra("Hydra evil", 2, 10, 1, 10, 1, 42); //Hydra(name,level,points,force,neckLength,poisonDose,position)
//
// 	Fight(dragon, hydra);
// 		//Fight funcion calls injectPoison and BlowFlame
//
// 		//So, After the Fight:
// 		//Hydra Evil is no more!
// 		//Dragon red, level: 2, health_status: 7, force: 3, Attacking Points: 6, position: 0
// 		//Hydra evil, level: 2, health_status: 0, force: 1, Attacking Points: 0, position: 42]=
//
// 		ASSERT_TRUE(hydra.alive());
//
// }


int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
