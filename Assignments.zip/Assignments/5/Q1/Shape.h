
#include <iostream>
#include <string>
using namespace std;
#ifndef SHAPE_H__
#define SHAPE_H__

class Shape {
protected:
	string _color;
public:
	Shape();
	Shape(const string& color);//
	string getColor() const; //
	void setColor(const string& color);//
	virtual string toString();//
	//
	virtual ~Shape();//
};

#endif
