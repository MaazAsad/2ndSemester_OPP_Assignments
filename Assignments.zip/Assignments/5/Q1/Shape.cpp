
#include "Shape.h"

Shape::Shape():_color("/0"){}

Shape::Shape(const string& color):_color(color){}
string Shape::getColor() const{ return this->_color ;}
void Shape::setColor(const string& color){
	this->_color=color;
}
string Shape::toString(){
	string tem;
	tem+=this->_color;
	return tem;
}
Shape::~Shape() {}
