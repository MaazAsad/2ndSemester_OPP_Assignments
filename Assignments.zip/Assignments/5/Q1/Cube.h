#include "ThreeDShape.h"
#ifndef CUBE_H_
#define CUBE_H_

class Cube:public ThreeDShape{
private:
	double _len;
public:

	Cube();
	Cube(const string& _color, double _x, double _y, double _z, double _side);
	virtual double volume(); //l ^ 3
	virtual string toString();//details
	virtual ~Cube();
};
#endif
