/*
 * ThreeDPoint.cpp
 *
 *  Created on: Apr 21, 2019
 *      Author: maria
 */

#include "ThreeDPoint.h"

ThreeDPoint::ThreeDPoint():TwoDPoint(0,0), z(0){
	// TODO Auto-generated constructor stub

}
ThreeDPoint::ThreeDPoint(double x, double y,double z): TwoDPoint(x,y), z(z){

}
double ThreeDPoint::getZ()const { return z; }
void ThreeDPoint::setZ(double z){
	this->z=z;
}
ThreeDPoint::~ThreeDPoint() {
	// TODO Auto-generated destructor stub
}

