/*
 * TwoDShape.h
 *
 *  Created on: Apr 21, 2019
 *      Author: maria
 */
#include "Shape.h"
#include "TwoDPoint.h"
#ifndef TWODSHAPE_H_
#define TWODSHAPE_H_

class TwoDShape :public Shape{
protected:
	TwoDPoint position;

public:
	TwoDShape() ;//Default constructor
	TwoDShape(const string& color , double x, double y); //Parameterized constructor that
	//invokes the base Shape constructor to set color then sets its own coordinates
	//instance value.
	virtual string toString();
	TwoDPoint getPosition();
	void setPosition(double x,double y);
	virtual double area(); //member function that computes and returns the object's area. It must be overridden in each derived class.
	virtual double perimeter(); //member function that computes and returns the object's perimeter. It must be overridden in each derived class.
	virtual ~TwoDShape();
};

#endif /* TWODSHAPE_H_ */
