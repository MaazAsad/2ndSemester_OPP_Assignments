/*
 * Square.cpp
 *
 *  Created on: Apr 21, 2019
 *      Author: maria
 */

#include "Square.h"

Square::Square():_side(0){}
Square::Square(const string& color, double x, double y , double len):TwoDShape(color,x,y) ,_side(len){}
double Square::area(){return _side * _side;}

double Square::perimeter (){return this->_side * 4;}
string Square::toString(){
	string _h;
	_h+=Shape::toString() +" Square"+ TwoDShape::toString();
	string _temp,_temp1,_temp2;
	_temp=to_string(this->_side);
	_temp1=to_string(this->perimeter());
	_temp2=to_string(this->area());
	char *_te = new char[10];
	char *_te1 =new char[10];
	char *_te2 = new char[10];
	int _i=0 ;
	for(;_temp[_i]!='\0';_i++){
		if(_temp[_i]!='0'){

			_te[_i]=_temp[_i];
		}
	}
	_te[_i]='\0';
	_i=0;
	for(;_temp1[_i]!='\0';_i++){
		if(_temp1[_i]!='0'){
			_te1[_i]=_temp1[_i];
		}
	}
	_te1[_i]='\0';
	_i=0;
	for(;_temp2[_i]!='\0';_i++){
		if(_temp2[_i]!='0'){
			//cout<<"hello";
			_te2[_i]=_temp2[_i];
		}
	}
	_te2[_i]='\0';
	_h+=" Side:";
	_h+=_te;
	_h+=" Perimeter:";
	_h+=_te1;
	_h+=" Area:";
	_h+=_te2;

	return _h;
}
Square::~Square() {}
