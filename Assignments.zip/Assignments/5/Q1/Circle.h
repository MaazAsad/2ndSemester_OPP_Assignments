#include "TwoDShape.h"
#ifndef CIRCLE_H_
#define CIRCLE_H_

class Circle:public TwoDShape{
protected:
	double _radius;
public:
	Circle(const string &color, double x, double y, double radius);//;
	virtual double area();// pi * r^2
	virtual double perimeter();// 2 * pi * r
	virtual  string toString();// details
	virtual ~Circle();
};
#endif
