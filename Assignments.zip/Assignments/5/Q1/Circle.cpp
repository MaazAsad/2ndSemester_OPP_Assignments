#include "Circle.h"

Circle::Circle(const string& color, double x, double y , double radius):TwoDShape(color,x,y) ,_radius(radius){}
double Circle::area(){
	return 3.14 * _radius * _radius ;
}
double Circle::perimeter(){
	return 2 * 3.14 * _radius;
}
string Circle::toString(){
	string _h;
	_h+=Shape::toString() +" Circle"+ TwoDShape::toString();
	string _temp,_temp1,_temp2;
	_temp=to_string(_radius);
	_temp1=to_string(this->perimeter());
	_temp2=to_string(this->area());
	char *_te = new char[10];
	char *_te1 =new char[10];
	char *_te2 = new char[10];
	int _i=0 ;
	for(;_temp[_i]!='\0';_i++){
		if(_temp[_i]!='0'){

			_te[_i]=_temp[_i];

		}

	}
	_te[_i]='\0';
	_i=0;
	for(;_temp1[_i]!='\0';_i++){
			if(_temp1[_i]!='0'){
				_te1[_i]=_temp1[_i];

			}

		}
	_te1[_i]='\0';
	_i=0;
	for(;_temp2[_i]!='\0';_i++){
			if(_temp2[_i]!='0'){
				//cout<<"hello";
				_te2[_i]=_temp2[_i];

			}

		}
	_te2[_i]='\0';
	_h+=" Radius:";
	_h+=_te;
	_h+=" Perimeter:";
	_h+=_te1;
	_h+=" Area:";
	_h+=_te2;

	return _h;
}
Circle::~Circle(){}
