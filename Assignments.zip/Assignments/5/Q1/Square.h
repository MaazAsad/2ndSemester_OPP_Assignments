#include "TwoDShape.h"
#ifndef SQUARE_H_
#define SQUARE_H_

class Square :public TwoDShape {
protected:
	double _side;
public:
	Square();
	Square(const string& color, double x, double y , double len);
	virtual double area();//l*l

	virtual double perimeter ();//4*l
	virtual string toString();
	virtual ~Square();
};

#endif /* SQUARE_H_ */
