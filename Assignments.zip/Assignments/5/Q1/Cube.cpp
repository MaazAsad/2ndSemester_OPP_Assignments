
#include <iostream>
#include <math.h>
#include "Cube.h"

Cube::Cube():_len(0){}

Cube::Cube(const string& _color, double _x, double _y, double _z, double _side) : ThreeDShape(_color,_x,_y,_z), _len(_side){

}

double Cube::volume(){
	return _len * _len * _len;
}

string Cube::toString(){
	string _h;
	_h+=Shape::toString() +" Cube"+ ThreeDShape::toString();
	string _temp,_temp1,_temp2;
	_temp=to_string(_len);
	double _in, _ar;
	_ar=modf(this->volume(),&_in);
	_ar = _in + roundf(_ar * 100.0)/100.0;
	_temp1=to_string(_ar);
	//cout<<ar<<endl<<temp1;
	char *_te = new char[10];
	char *_te1 =new char[10];
	int _i=0 ;
	for(;_temp[_i]!='\0';_i++){
		if(_temp[_i]!='0'){
			_te[_i]=_temp[_i];

		}
	}
	_te[_i]='\0';
	_i=0;
	for(;_i<=4;_i++){
		if(_temp1[_i]!='.'){
			_te1[_i]=_temp1[_i];
		}
		if(_temp[_i]=='.'){
			for(int j=_i;_temp1[j]!='\0';j++){
				if(_temp1[j]!='0'){
					_te1[j]=_temp1[j];
				}
			}
		}
	}
	_te1[_i]='\0';
	_i=0;
	_h+=" Side:";
	_h+=_te;
	_h+=" Volume:";
	_h+=_te1;

	return _h;
}//

Cube::~Cube(){}//
