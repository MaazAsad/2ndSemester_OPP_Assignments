/*
 * Tetrahedron.h
 *
 *  Created on: Apr 21, 2019
 *      Author: maria
 */
#include "ThreeDShape.h"
#ifndef TETRAHEDRON_H_
#define TETRAHEDRON_H_

class Tetrahedron : public ThreeDShape {
private:
	double lengthOfEdge;
public:
	Tetrahedron();
	Tetrahedron(const string& color, double x, double y, double z, double radius);
			virtual double volume();

		virtual string toString();
	virtual ~Tetrahedron();
};

#endif /* TETRAHEDRON_H_ */
