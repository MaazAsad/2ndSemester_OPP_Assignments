/*
 * Triangle.cpp
 *
 *  Created on: Apr 21, 2019
 *      Author: maria
 */
#include <iostream>
#include <math.h>
#include "Triangle.h"

Triangle::Triangle() :side1(0), side2 (0),side3(0){
	// TODO Auto-generated constructor stub

}
Triangle::Triangle(const string& color, double x, double y , double side1, double side2, double  side3) :TwoDShape(color,x,y) ,side1(side1), side2(side2)
,side3(side3){

}
double Triangle::area(){
	 double s = (side1 + side2 + side3) /2;

	 return sqrt(s*(s-side1)*(s-side2)*(s-side3));
}
double Triangle::perimeter (){
	return this->side1 + this->side2 + this->side3;
}
string Triangle::toString(){
	string h;
	h+=Shape::toString() +" Triangle"+ TwoDShape::toString();
			string temp,temp1,temp2,temp3,temp4;
			double in, ar;
			//ar=modf(this->area(),&in);
			//ar = in + roundf(ar * 10.0)/10.0;
			//cout<<ar<<endl;
			temp=to_string(this->side1);
			temp3=to_string(this->side2);
			temp4=to_string(this->side3);
			temp1=to_string(this->perimeter());
			temp2=to_string(this->area());
			char *te = new char[10];
			char *te1 =new char[10];
			char *te2 = new char[10];
			char *te3 = new char[10];
			char *te4 = new char[10];
			int i=0 ;
			for(;temp[i]!='\0';i++){
				if(temp[i]!='0'){
					te[i]=temp[i];
					te3[i]=temp3[i];
					te4[i]=temp4[i];

				}

			}
			te[i]='\0', te3[i]='\0', te4[i]='\0';;
			i=0;
			for(;temp1[i]!='\0';i++){
					if(temp1[i]!='0'){
						te1[i]=temp1[i];

					}

				}
			te1[i]='\0';
			i=0;
			for(;temp2[i]!='\0';i++){
					if(temp2[i]!='0'){
						te2[i]=temp2[i];

					}

				}
			//cout<<temp<<endl<<temp3<<endl<<temp4<<endl;
			te2[i]='\0';
			h+=" Side1:";
			h+=te;
			h+=" Side2:";
			h+=te3;
			h+=" Side3:";
			h+=te4;
			h+=" Perimeter:";
			h+=te1;
			h+=" Area:";
			h+=te2;
	return h;
}

Triangle::~Triangle() {
	// TODO Auto-generated destructor stub
}

