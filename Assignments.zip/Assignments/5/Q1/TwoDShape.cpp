/*
 * TwoDShape.cpp
 *
 *  Created on: Apr 21, 2019
 *      Author: maria
 */

#include "TwoDShape.h"

TwoDShape::TwoDShape(): Shape("\0") {
	this->position.setX(0);
	this->position.setY(0);
	// TODO Auto-generated constructor stub

}
TwoDShape::TwoDShape(const string& color , double x, double y) :Shape(color) {
	this->position.setX(x);
	this->position.setY(y);
}
TwoDPoint TwoDShape::getPosition(){ return this->position; }
void TwoDShape::setPosition(double x,double y){
	this->position.setX(x);
	this->position.setY(y);
}
double TwoDShape::area(){
	return this->position.getX() * this->position.getY();
}
double TwoDShape::perimeter(){
	return 2* (this->position.getX() + this->position.getY());
}

string TwoDShape::toString(){
	string h;
	string temp,temp1;
		temp=to_string(this->position.getX());
		temp1=to_string(this->position.getY());
		char *te = new char[10];
		char *tee = new char [10];
		int i=0;
		for(;temp[i]!='\0';i++){
			if(temp[i]!='0'){
				te[i]=temp[i];
				tee[i]=temp1[i];
			}

		}
		te[i]='\0';
		tee[i]='\0';
	h+=" Position:(";
	h+=te;
	h+=",";
	h+=tee;
	h+=")";
	return h;
}
TwoDShape::~TwoDShape() {
	// TODO Auto-generated destructor stub
}

