/*
 * ThreeDShape.cpp
 *
 *  Created on: Apr 21, 2019
 *      Author: maria
 */

#include "ThreeDShape.h"

ThreeDShape::ThreeDShape() :Shape("\0") {
	this->position.setX(0);
	this->position.setY(0);
	this->position.setZ(0);
	// TODO Auto-generated constructor stub

}
ThreeDShape::ThreeDShape(const string& color , double x, double y,double z) :Shape(color){
	this->position.setX(x);
	this->position.setY(y);
	this->position.setZ(z);
}
ThreeDPoint ThreeDShape::getPosition(){ return this->position ;}
void ThreeDShape::setPosition(double x,double y,double z){
	this->position.setX(x);
	this->position.setY(y);
	this->position.setZ(z);
}
double ThreeDShape::volume(){
	return position.getX() * position.getY() * position.getZ();
}
 string ThreeDShape::toString(){
	 string h;
	 string temp,temp1,temp2;
	 		temp=to_string(this->position.getX());
	 		temp1=to_string(this->position.getY());
	 		temp2=to_string(this->position.getZ());
	 		char *te = new char[10];
	 		char *tee = new char [10];
	 		char *teee = new char[10];
	 		int i=0;
	 		for(;temp[i]!='\0';i++){
	 			if(temp[i]!='0'){
	 				te[i]=temp[i];
	 				tee[i]=temp1[i];
	 				teee[i]=temp2[i];

	 			}

	 		}
	 		te[i]='\0';
	 		tee[i]='\0';
	 	h+=" Position:(";
	 	h+=te;
	 	h+=",";
	 	h+=tee;
	 	h+=",";
	 	h+=teee;
	 	h+=")";
	 return h;
 }
ThreeDShape::~ThreeDShape() {
	// TODO Auto-generated destructor stub
}

