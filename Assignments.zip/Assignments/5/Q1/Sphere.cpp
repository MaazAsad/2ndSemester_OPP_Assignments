
#include <iostream>
#include <math.h>
#include "Sphere.h"

Sphere::Sphere(): rad(0){}
Sphere::Sphere(const string& _color, double _x, double y, double _z, double _radius) : ThreeDShape(_color,_x,y,_z), rad(_radius){

}
double Sphere::volume(){
	return 4/3.0 * 3.14 * (this->rad * this->rad * this->rad);
}
string Sphere::toString(){
	string _h;
	_h+= Shape::toString() + " Sphere" + ThreeDShape::toString();
	string _temp,_temp1,_temp2;
	_temp=to_string(this->rad);
	double _in, _ar;
	_ar=modf(this->volume(),&_in);
	_ar = _in + roundf(_ar * 10.0)/10.0;
	_temp1=to_string(_ar);
	//cout<<ar<<endl<<temp1;
	char *_te = new char[10];
	char *_te1 =new char[10];
	int _i=0 ;
	for(;_temp[_i]!='\0';_i++){
		if(_temp[_i]!='0'){
			_te[_i]=_temp[_i];
		}

	}
	_te[_i]='\0';
	_i=0;
	for(;_temp[_i-1]!='0';_i++){
		if(_temp1[_i]!='.'){
			_te1[_i]=_temp1[_i];
		}
		if(_temp[_i]=='.'){
			for(int j=_i;_temp1[j]!='\0';j++){
				if(_temp1[j]!='0'){
					_te1[j]=_temp1[j];

				}
			}
		}
	}
	_te1[_i]='\0';
	_i=0;
	_h+=" Radius:";
	_h+=_te;
	_h+=" Volume:";
	_h+=_te1;
	return _h;
}
Sphere::~Sphere(){}
