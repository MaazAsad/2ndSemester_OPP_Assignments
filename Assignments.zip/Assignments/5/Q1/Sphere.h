
#include "ThreeDShape.h"
#ifndef SPHERE_H_
#define SPHERE_H_

class Sphere :public ThreeDShape{
private:
	double rad;
public:
	Sphere();
	Sphere(const string& _color, double _x, double y, double _z, double _radius);
	virtual double volume();
	virtual string toString();
	virtual ~Sphere();
};

#endif
