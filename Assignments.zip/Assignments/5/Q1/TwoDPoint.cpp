/*
 * TwoDPoint.cpp
 *
 *  Created on: Apr 20, 2019
 *      Author: maria
 */

#include "TwoDPoint.h"

TwoDPoint::TwoDPoint() {
	this->x=0;
	this->y=0;
	// TODO Auto-generated constructor stub

}

TwoDPoint::TwoDPoint(double x, double y) {
	this->x=x;
	this->y=y;
}
double TwoDPoint::getX() const { return this->x; }
void TwoDPoint::setX(double x){
	this->x=x;
}
double TwoDPoint::getY()const{ return this->y;}
void TwoDPoint::setY(double y){
	this->y=y;
}


TwoDPoint::~TwoDPoint() {
	// TODO Auto-generated destructor stub
}

