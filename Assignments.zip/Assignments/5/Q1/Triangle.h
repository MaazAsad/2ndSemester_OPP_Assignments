/*
 * Triangle.h
 *
 *  Created on: Apr 21, 2019
 *      Author: maria
 */
#include "TwoDShape.h"
#ifndef TRIANGLE_H_
#define TRIANGLE_H_

class Triangle : public TwoDShape{
private:
	double side1, side2,side3;
public:
	Triangle();


		Triangle(const string& color, double x, double y , double side1, double, double );
		virtual double area();

		virtual double perimeter ();//this overriding member function computes and returns the
		virtual string toString();
	virtual ~Triangle();
};

#endif /* TRIANGLE_H_ */
