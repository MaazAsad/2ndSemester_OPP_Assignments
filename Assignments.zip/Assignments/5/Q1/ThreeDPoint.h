/*
 * ThreeDPoint.h
 *
 *  Created on: Apr 21, 2019
 *      Author: maria
 */
#include "TwoDPoint.h"
#ifndef THREEDPOINT_H_
#define THREEDPOINT_H_

class ThreeDPoint : public TwoDPoint {
protected:
	double z;
public:
	ThreeDPoint() ;//Default constructor
	ThreeDPoint(double,double, double); //Parameterized constructor that invokes the base 2DPoint class to set x,y coordinates values then sets its z dimension.
	double getZ()const ;// a const member function returning the Z coordinate value.
	void setZ(double); //a member function setting the Z coordinate value.
	virtual ~ThreeDPoint();
};

#endif /* THREEDPOINT_H_ */
