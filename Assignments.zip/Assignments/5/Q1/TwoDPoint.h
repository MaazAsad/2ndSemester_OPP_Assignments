/*
 * TwoDPoint.h
 *
 *  Created on: Apr 20, 2019
 *      Author: maria
 */

#ifndef TWODPOINT_H_
#define TWODPOINT_H_

class TwoDPoint {
protected:
	double x;
	double y;


public:
	TwoDPoint(); //Default constructor
	TwoDPoint(double, double) ;//Parameterized constructor
	double getX() const ;//a const member function returning the x coordinate value
	void setX(double); //a member function setting the x coordinate value
	double getY()const; // a const member function returning the y coordinate value.
	void setY(double) ;
	virtual ~TwoDPoint();
};

#endif /* TWODPOINT_H_ */
