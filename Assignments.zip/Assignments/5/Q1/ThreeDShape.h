/*
 * ThreeDShape.h
 *
 *  Created on: Apr 21, 2019
 *      Author: maria
 */
#include "Shape.h"
#include "ThreeDPoint.h"
#ifndef THREEDSHAPE_H_
#define THREEDSHAPE_H_

class ThreeDShape : public Shape{
protected:
	ThreeDPoint position;
public:
	ThreeDShape();
	ThreeDShape(const string& color , double x, double y,double z);
	ThreeDPoint getPosition();
	virtual string toString();
	void setPosition(double x,double y, double z);
	virtual double volume();
	virtual ~ThreeDShape();
};

#endif /* THREEDSHAPE_H_ */
