/*
 * Tetrahedron.cpp
 *
 *  Created on: Apr 21, 2019
 *      Author: maria
 */
#include <iostream>
#include <math.h>
#include "Tetrahedron.h"

Tetrahedron::Tetrahedron():lengthOfEdge(0){}
Tetrahedron::Tetrahedron(const string& color, double x, double y, double z, double l):ThreeDShape(color,x,y,z), lengthOfEdge(l){

}
double Tetrahedron::volume(){
	double temp= pow((this->lengthOfEdge),3.0);
	double temp2 = sqrt(2.0) * 6.0;
	return temp/temp2;

}
string Tetrahedron::toString(){
	string h;
	h+=Shape::toString() +" Tetrahedron"+ ThreeDShape::toString();
	string temp,temp1,temp2;
	temp=to_string(this->lengthOfEdge);
	double ar,in;
	ar=modf(this->volume(),&in);
	ar = in + roundf(ar * 100000.0)/100000.0;

	temp1=to_string(ar);

	char *te = new char[10];
	char *te1 =new char[10];
	int i=0 ;
	for(;temp[i]!='\0';i++){
		if(temp[i]!='0'){
			te[i]=temp[i];

		}

	}
	te[i]='\0';
	i=0;
	for(;temp[i]!='\0';i++){
		if(temp1[i]!='0'){
			te1[i]=temp1[i];
		}

	}
	te1[i]='\0';
	i=0;
	h+=" LengthOfEdge:";
	h+=te;
	h+=" Volume:";
	h+=te1;

	return h;

}

Tetrahedron::~Tetrahedron() {
	// TODO Auto-generated destructor stub
}
