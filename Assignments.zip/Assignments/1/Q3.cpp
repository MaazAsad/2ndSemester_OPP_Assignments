#include<iostream>
using namespace std;

int** magicSquare(int size){
    int **mySquare = new int*[size];
    int squareNum = 1;
    //int startr=0, startc=size/2+1;

    for(int i=0; i<size; i++){
        mySquare[i] = new int[size];
        for(int j = 0; j<size; j++){
            mySquare[i][j] = 0;
        }
    }

    for(int i=1 ,r=0 ,c=size/2 ; i<=(size*size);){

        if(mySquare[r][c] == 0){
            mySquare[r][c] = i;
            i++;
            r--;
            c++;

        }
        else{
            r+=2;
            c--;
        }

        if(r<0){
            r = size-1;
        }
        if(r == size){
            r =0;
        }
        if(r>size){
            r-=size;
        }

        if(c<0){
            c = size-1;
        }
        if(c==size){
            c=0;
        }


    }

    return mySquare;



}
// int main(){
//
//     int **x;
//
//     x = magicSquare(3);
//
//     for(int i=0; i<5; i++){
//         for(int j=0; j<5; j++){
//             cout << x[i][j] << " ";
//         }
//         cout << endl;
//     }
//
//     return 0;
// }
