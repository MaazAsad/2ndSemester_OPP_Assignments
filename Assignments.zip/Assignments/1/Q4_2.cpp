#include<iostream>
using namespace std;

void countWordsBasedOnLength(char *string, int *&array, int &size){
    int count =0,tempcount=0;
    int a=0;

    //size of array
    for(int i=0; string[i]; i++,tempcount++){
        if(string[i] == ' ' || string[i] =='\n'){
            if(tempcount > count){
                count = tempcount;
            }
            tempcount = -1;
        }
    }
    size=count+1;

    array = new int[size];

    //counting spaces;
    count = 0;
    for(int i=0; string[i]; i++){
        if(string[i] == '\n')
            continue;
        if(string[i] == ' '){
            count++;
        }
    }


    array[0] = count;

    //counting words

    count =0;
    for(int i=0;; i++){
        count++;
        if(string[i] == '\n'){
            a++;
            }
        if( (string[i] == ' ' && (string[i+1] != ' ' || string[i] != '\n') ) || string[i]=='\0'){
            array[count-1]+=1;
            count =0;
        }

        if(string[i] == '\0'){
            break;
        }

    }

        // cout << size<<endl;
        // for(int i=0;i<size;i++){
        //     cout << array[i] << endl;
        // }


}


// int main(){
//     char* s=(char*)"This is a test String \n New Line";
//     int* arr;
//     int size;
//
//     countWordsBasedOnLength(s,arr,size);
//     cout << size<<endl;
//     for(int i=0;i<size;i++){
//         cout << arr[i] << endl;
//     }
//
//     cout << endl;
//     return 0;
// }
