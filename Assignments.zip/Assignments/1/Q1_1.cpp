#include<iostream>
int Strlen(char* s1)
{
    int x=0;
    while(*s1){
        x++;
        s1++;
    }
    return x+1;
}
//
// int main(){
//     char a[50]= "Maazasad\0";
//
//     std::cout << Strlen(a) << std::endl;
// }
