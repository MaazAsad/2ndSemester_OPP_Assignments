#include<iostream>
using namespace std;

int StrFind(char *s1, char*s2){
    int countLen = 0,checklen=0;
    while(*(s2+countLen)){
        countLen++;
    }


    for(int i=0; s1[i] != '\0'; i++){
        checklen =0;
        for(int j=0; s1[i+j] != '\0' || j<countLen ; j++){

            if(s1[i+j] == s2[j]){
                checklen++;
                }
            }
        if(checklen == countLen){
            return i;
            }
        }

    return -1;

}


// int main(){
//     char a[50] = "hahahyolo NIggs\0";
//     char b[50] = "yolo\0";
//
//     cout << StrFind(a,b)<<endl;
//
//     return 0;
// }
