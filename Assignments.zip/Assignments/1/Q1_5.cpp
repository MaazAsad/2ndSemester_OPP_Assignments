#include<iostream>
using namespace std;

char * StrnCat(char* s1, const char*s2, size_t n){
    int counts1 = 0;
    while(*(s1+counts1)){
        counts1++;
    }
    char* tempstr = new char[counts1 + n];

    for(int i=0; i<counts1; i++){
        tempstr[i] = s1[i];
    }
    for(int i=counts1, j=0; i<counts1+n; i++,j++){
        tempstr[i] = s2[j];
    }
    s1 = tempstr;
    //delete []tempstr;

    return s1;

}


// int main(){
//     char* a;
//     a =new char[50];
//     a= "yolo niggs";
//     char b[50] = "he is a random dude";
//
//     a= StrnCat(a,b,5);
//     std::cout << a << std::endl;
//
//     return 0;
// }
