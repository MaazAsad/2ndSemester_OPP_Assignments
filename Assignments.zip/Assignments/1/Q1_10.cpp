#include<iostream>
using namespace std;

char *SubStr(char *s1, int pos, int len){

    char *mySubStr = new char[len];

    for(int i=0; s1[pos+i]!='\0' && i<len; i++){
        mySubStr[i] = s1[pos+i];
    }

    return mySubStr;
}

// int main(){
//     char a[50] = "hahahyolo NIggs\0";
//     char*b;
//     b= SubStr(a,4,7);
//     cout << b<<endl;
//
//     return 0;
// }
