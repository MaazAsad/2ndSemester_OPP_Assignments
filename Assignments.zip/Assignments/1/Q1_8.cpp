#include<iostream>
using namespace std;

char **StrTok(char *s1, const char s2){
    int count=0;
    for(int i=0; s1[i] != '\0'; i++){
        if(s1[i] == s2){
            count ++;
        }
    }
    char ** strTokens;
    strTokens = new char*[count];

    for(int i=0, j=0, charcount =0,startP =0; ; i++,charcount++){

        if(s1[i] == s2 || s1[i] == '\0' ){

            strTokens[j] = new char[charcount];

            for(int l=0,k=startP; k<i;l++,k++){
                strTokens[j][l] = s1[k];
            }

            charcount =0;
            startP = i+1;
            j++;
        }

        if(s1[i] == '\0')
            break;
    }

    return strTokens;
}

// int main(){
//     char a[50] = "yolo NIggs\0";
//
//     char ** x= StrTok(a,' ');
//
//     for(int i=0;i<2; i++){
//         cout << x[i]<<endl;
//     }
//     return 0;
// }
