#include<iostream>
using namespace std;

char letters[] = {'A', 'B', 'C', 'D', 'E','F','G','H','I','J','K','L','M','N','O',
                  'P','Q','R','S','T','U','V','W','X','Y','Z','0','1','2','3','4',
                  '5','6','7','8','9','.',',','?','\'','!','/','(',')','&'};

char code[][11] = {".-\0","-...\0","-.-.\0","-..\0",".\0","..-.\0","--.\0","....\0","..\0",".---\0","-.-\0",
                 ".-..\0","--\0","-.\0","---\0",".--.\0", "--.-\0",".-.\0","...\0","-\0","..-\0","...-\0",
                 ".--\0","-..-\0","-.--\0","--..\0","-----\0",".----\0","..--\0","...--\0","....-\0",
                 ".....\0","-....\0","--...\0","---..\0","----.\0",".-.-.-\0","--..--\0","..--..\0",
                 ".----.\0","-.-.--\0","-..-.\0","-.--.\0","-.--.-\0",".-...\0"};

int strlen(char *s){
    int x;
    for(x=0;s[x]!='\0';x++);
    return x;
}

char* addslash(char *s){
    char *temp;
    int prevlen,newlen;
    prevlen = strlen(s);
    temp = new char[prevlen];
    for(int k=0; s[k]!='\0';k++){
        temp[k] = s[k];
    }
    delete s;
    //find new lendth of code
    newlen = prevlen+ 2;
    s = new char[newlen]{'\0'};
    //copy temp back
    for(int k=0; temp[k]!='\0';k++){
        s[k] = temp[k];
    }
    delete temp;
    s[newlen-2] = '/';
    s[newlen-1] = '\0';
    return s;
}

char* addspace(char *s){
    char *temp;
    int prevlen,newlen;
    prevlen = strlen(s);
    temp = new char[prevlen];
    for(int k=0; s[k]!='\0';k++){
        temp[k] = s[k];
    }
    delete s;
    //find new lendth of code
    newlen = prevlen+ 2;
    s = new char[newlen]{'\0'};
    //copy temp back
    for(int k=0; temp[k]!='\0';k++){
        s[k] = temp[k];
    }
    delete temp;
    s[newlen-2] = ' ';
    s[newlen-1] = '\0';
    return s;
}

char* convertToMorseCode(char* s){
    char *mycode = new char; *mycode= '\0';
    //cout << "yo" << endl;
    char *temp;
    int len,prevlen,newlen;
    bool a = true;

    for(int i=0; s[i]!='\0';i++){
        a=true;
        if(s[i+1] == ' '){
            a = false;
        }
        else if(s[i] == ' '){
            mycode = addslash(mycode);
            a=false;
        }
        for(int j=0; j<45; j++){

            if(s[i] == letters[j]){
                //cout << s[i] << ' ' << letters[j] <<endl;
                //copy current code into temp
                prevlen = strlen(mycode);
                temp = new char[prevlen];
                for(int k=0; mycode[k]!='\0';k++){
                    temp[k] = mycode[k];
                }
                delete mycode;

                //find new lendth of code
                len = strlen(code[j]);
                newlen = prevlen + len+2;
                mycode = new char[newlen];

                //copy temp back
                for(int k=0; temp[k]!='\0';k++){
                    mycode[k] = temp[k];
                }
                delete temp;
                //add new code and space;
                for(int k=prevlen,l=0;code[j][l]!='\0';k++,l++){
                    mycode[k] = code[j][l];
                }
                mycode[newlen-2] = '\0';
            }
        }
        if(a){
            mycode = addspace(mycode);
        }
    }
    mycode[newlen-2] = '/';
    mycode[newlen-1] = '\0';
    return mycode;
}


char* convertToString(char*s){
    char *mystring; mystring = new char;
    char *temp;
    int len=0 ,prevlen=1,newlen;
    int count =0;
    bool a=false,b=false;
    int j;

    for(int i=0; s[i] !='\0'; i++){

        for(j=i;;j++){
            if(s[j] == ' ' || s[j] == '/'){
                break;
            }
        }
        if(s[j] == ' '){
            for(int k=0; k<45; k++){

                if(strlen(code[k]) == j-i){
                    a=true;
                }

                for(int l=0,m=i;code[k][l]!='\0'; l++,m++){
                    if(code[k][l] == s[m]){
                        b = true;
                    }
                    else{
                        b= false;
                        break;
                    }
                }

                if(a && b){
                    cout << letters[k] << endl;
                    len++;
                    temp = new char[len];

                    for(int l=0; l<len && len>1; l++){
                        temp[l] = mystring[l];

                    }

                    delete mystring;
                    temp[len] = letters[k];
                    mystring = new char[len];
                    for(int l=0; l<len && len>1; l++){
                        mystring[l] = temp[l];

                    }

                    delete temp;
                    break;

                }

            }
        }


    i=j+1;
    }
    return mystring;
}

// int main(){
//
//     char* t2=(char*)"- .... .. .../.. .../.-/- . ... -/... - .-. .. -. --. -.-.--/";
//     char* act2=(char*)"THIS IS A TEST STRING!";
//     char* r2=convertToString(t2);
//
//     cout << r2 << endl;
//
//
//     return 0;
// }
