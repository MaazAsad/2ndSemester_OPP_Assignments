#include<iostream>

char* Strcpy(char *s1, const char* s2){
    int count = 0;
    while(*(s2+count)){
        count++;
    }

    //char temp[count];
    s1 = new char[count];
    for(int i=0; i<count; i++){
        s1[i] = s2[i];
    }
    //s1 = temp;
    return s1;
}
// 
// int main(){
//     char* a;
//     char b[10] = "Asad";
//
//     a= Strcpy(a,b);
//     std::cout << a << std::endl;
//
//
//     return 0;
// }
