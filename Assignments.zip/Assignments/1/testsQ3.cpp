
#include "Q3.cpp"
#include <gtest/gtest.h>

//-------------------Question No 3-----------------
TEST(Question3, First) {
   
int *p1=magicSquare(3);
ASSERT_EQ(1,p1[0][1]);
ASSERT_EQ(8,p1[0][0]);
ASSERT_EQ(5,p1[1][1]);
ASSERT_EQ(2,p1[2][2]);


}
//-------------------Question No 3-----------------
TEST(Question3, Second){
int *p2=magicSquare(5);

ASSERT_EQ(1,p2[0][2]);
ASSERT_EQ(13,p2[2][2]);
ASSERT_EQ(5,p2[1][1]);
ASSERT_EQ(9,p2[4][4]);

}


int main(int argc, char **argv) {

    testing::InitGoogleTest(&argc, argv);

    return RUN_ALL_TESTS();
}
