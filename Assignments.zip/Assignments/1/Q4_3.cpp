#include<iostream>

void countingUniqueWords(char* string, char **&uwords, int *&arr, int &size){



}
