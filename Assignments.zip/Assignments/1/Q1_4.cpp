#include<iostream>
using namespace std;

char* StrCat(char *s1, const char *s2){
    int counts1 = 0, counts2 = 0;
    while(*(s1+counts1)){
        counts1++;
    }

    while(*(s2+counts2)){
        counts2++;
    }

    char* temp = new char[counts1+counts2];

    for(int i=0; i<counts1; i++){
        temp[i] = s1[i];
    }

    for(int i=0, j=counts1; i<counts2; i++,j++){
        temp[j] = s2[i];
    }
    s1 = temp;
    //delete temp;
    return s1;

}

// int main(){
//     char* a;
//     a =new char[50];
//     a= "yolo niggs ";
//     char b[50] = "he is a random dude";
//
//     a= StrCat(a,b);
//     std::cout << a << std::endl;
//
//     return 0;
// }
