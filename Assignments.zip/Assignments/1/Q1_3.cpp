#include<iostream>
using namespace std;



char* Strncpy(char *s1, const char *s2, size_t n){
    s1 = new char[n];
    for(int i=0; i<n; i++){
        s1[i] = s2[i];
    }

    return s1;

}

// int main(){
//     char* a;
//     char b[50] = "he is a random dude";
//
//     a= Strncpy(a,b,7);
//     std::cout << a << std::endl;
//
//     return 0;
// }
