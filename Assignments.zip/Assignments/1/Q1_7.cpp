#include<iostream>
using namespace std;

int StrnCmp(const char *s1, const char *s2, size_t n){
    for(int i=0; i<n; i++){
        if(s1[i] == s2[i]){
            continue;
        }
        if(s1[i]>s2[i]){
            return 1;
        }
        if(s1[i]<s2[i]){
            return -1;
        }
    }

    return 0;
}
// 
// int main(){
//     char a[50] = "yolo NIggs\0";
//
//     char b[50] = "yol3 NIggs\0";
//
//     int x= StrnCmp(a,b,5);
//     std::cout << x << std::endl;
//
//     return 0;
// }
