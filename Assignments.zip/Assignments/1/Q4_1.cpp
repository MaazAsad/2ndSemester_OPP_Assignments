#include<iostream>
using namespace std;
void countLetters(char *string, int *&array, int &size){
    int letterCount = 0;
    int n=0;
    bool charcheck = false;
    char letters[128] = {'\0'};

    for(int i=0,j=0; string[i] != '\0'; i++){
        charcheck = false;
        for(int k=0; k<letterCount; k++){
            if(string[i]==letters[k]){
                charcheck = true;
                break;
            }
        }

        if(!charcheck){
            letters[j] =  string[i];
            j++;
            letterCount++;
        }
    }
    //cout << letterCount << endl;
    array = new int[letterCount];
    size = letterCount;

    for(int i=0; letters[i];i++){
        n=0;
        for (int j = 0; string[j]; j++) {
            if(letters[i] == string[j]){
                n++;
            }
        }
        array[i] = n;
    }


}


// int main(){
//     char* s=(char*)"Hello World";
//     int* arr;
//     int size;
//     countLetters(s,arr,size);
//
//     for(int i=0; i<size; i++){
//         cout << arr[i]<<endl;
//     }
//
//     cout << endl;
//     return 0;
// }
