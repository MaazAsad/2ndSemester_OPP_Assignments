#include<iostream>
using namespace std;

class Employee{
	char* name;
	double salary;

public:
	Employee(){
		name=  NULL;
		salary =0;
	}
	Employee(char* name, double salary){
		this->name = name;
		this->salary = salary;
	}
	char* getName(){
		return name;
	}
	double getSalary(){
		return salary;
	}

};
