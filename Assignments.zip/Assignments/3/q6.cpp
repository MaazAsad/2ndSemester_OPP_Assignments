#include<iostream>
using namespace std;

class Address{
    int HouseNumber,street,AppartmentNumber, PostalCode;
    char * city;
    char * state;
public:

    Address(int HNo, int street, int app, char* city, char* state, int postal){
        HouseNumber = HNo;
        this->street = street;
        AppartmentNumber = app;
        this->city = city;
        this->state = state;
         PostalCode = postal;
    }

    Address(int HNo, int street, char* city, char* state, int postal){
        AppartmentNumber = -1;
        HouseNumber = HNo;
        this->street = street;
        this->city = city;
        this->state = state;
        PostalCode = postal;
    }

    void setHno(int Hno){HouseNumber = Hno;}
    void setStreet(int st){street = st;}
    void setAppartmentNo(int a){AppartmentNumber = a;}
    void setPostalCode(int p){PostalCode = p;}
    void setCity(char *c){city =c;}
    void setState(char* c){state = c;}

    int getHno(){return HouseNumber;}
    int getStreet(){return street; }
    int getAppartmentNo(){return AppartmentNumber;}
    int getPostalCode(){return PostalCode;};
    char* getCity(){return city;}
    char* getState(){return state;}

    void print(){
        if(AppartmentNumber ==-1){
            cout << HouseNumber <<' ' << street <<endl
                 << city << ' ' << state << ' '<<PostalCode<<endl;
        }
        else{
            cout << AppartmentNumber <<' ' << street <<endl
                 << city << ' ' << state << ' '<<PostalCode<<endl;
        }

    }

    bool compareTO(Address x){
        if(this->PostalCode > x.getPostalCode()){
            return false;
        }
        return true;
    }


};
