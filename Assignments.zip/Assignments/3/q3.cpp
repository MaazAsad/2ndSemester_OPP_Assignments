#include<iostream>

#define PI 3.14
using namespace std;

class Circle{
    float radius;
public:
    Circle(){
        this->radius = 0.0;
    }
    Circle(float radius){
        this->radius = radius;
    }

    float getArea(){
        return PI * radius * radius;
    }

    float getCircumference(){
        return 2.0 * PI * radius;
    }

};
