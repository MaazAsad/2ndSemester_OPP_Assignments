#include<iostream>
using namespace std;

class Rectangle{
    float length,width;
public:
    Rectangle(float a,float b){
        length =a;
        width = b;
    }
    Rectangle(){
        length = width=0;
    }
    void setLength(float length){this->length = length;}
    void setWidth(float width){this->width = width;}
    float perimeter(){return 2*(length*width);}
    float area(){return length * width;}
    void show(){cout << length << ' ' << width << endl;}
    int sameArea(Rectangle r2){
        if(this->area() == r2.area())
            return 1;
        else
            return 0;
    }
};
