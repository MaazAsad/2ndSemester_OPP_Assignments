#include<iostream>
using namespace std;

class Student{
    char* RollNumber;
    char* Name;
    char* Courses_Name[5];
    char * Degree;
    char* DOB;
    int batch,Courses_Code[5];
    float CGPA;
    char Courses_Grades[5];

public:
    Student(){
        RollNumber = Name = Degree = DOB = NULL;
        for(int i=0;i<5;i++){
            Courses_Name[i]= NULL;
        }
        batch=0;
        for(int i=0;i<5;i++){
            Courses_Code[i] = 0;
        }
        CGPA =0;
        for(int i=0;i<5;i++){
            Courses_Grades[i] = '\0' ;
        }
    }

    Student(char* roll, char* name, char* cName[], char* degree, char*dob,
            int batch, int cCode[], float gpa,char cGrade[]){

        RollNumber = roll;
        Name = name;
        DOB=dob;
        for(int i=0;i<5;i++){
            Courses_Name[i] = cName[i];
        }
        Degree = degree;
        this->batch = batch;
        for(int i=0;i<5;i++){
            Courses_Code[i] = cCode[i];
        }
        CGPA = gpa;
        for(int i=0;i<5;i++){
            Courses_Grades[i] = cGrade[i];
        }


    }

    void setRollNumber(char* x){RollNumber = x;}
    void setName(char* x){Name =x;}
    void setDOB(char* x){DOB = x;}
    void setCouseName(char* x[]) {
        for(int i=0;i<5;i++){
            Courses_Name[i] = x[i];
        }
    }
    void setDegree(char *x){Degree = x;}
    void setBatch(int x){batch =x;}
    void setCourseCode(int x[]){
        for(int i=0;i<5;i++){
            Courses_Code[i] = x[i];
        }
    }
    void setCGPA(float x){CGPA =x;}
    void setCourseGrade(char x[]){
        for(int i=0;i<5;i++){
            Courses_Grades[i] = x[i];
        }
    }

    char *getName(){
        return Name;
    }

    char* getDOB(){
        return DOB;
    }
    float getCGPA(){
        return CGPA;
    }

    char* getDegree(){
        return Degree;
    }
    int getBatch(){
        return batch;
    }

    char* getRoll(){
        return RollNumber;
    }

    void setValues(){
      //char* RollNumber;
      //char* Name;
      char* Courses_Name[5];
      //char * Degree;
      //char* DOB;
      //int batch,
      Courses_Code[5];
      //float CGPA;
      char Courses_Grades[5];

      char roll[10],name[50],CGrades[5],degree[25],dob[10];
      char *CName[5];
      float gpa;
      int b,ccode[5];
      for(int i=0;i<5;i++){
          CName[i][30];
      }


      cout << "Enter Name: ";
      cin.getline(name,50);
      cout << "Enter Date of Birth: ";
      cin.getline(dob,10);
      cout << "Enter Batch no: ";
      cin >> b;
      cout << "Enter Roll Number: ";
      cin.getline(roll,50);
      cout << "Enter Degree name:";
      cin.getline(degree,25);
      cout << "Enter CGPA: ";
      cin >> gpa;

      for(int i=0;i<5;i++){

          cout << "Enter Course Code: ";
          cin >> ccode[i];
          cout << "Enter Course Grade: ";
          cin >> CGrades[i];
      }
      for(int i=0;i<5;i++){
          cout<<"Enter Your Course Name:";
          cin.getline(CName[i],30);
      }

      setRollNumber(roll);
      setName(name);
      setBatch(b);
      setCouseName(CName);
      setDegree(degree);
      setDOB(dob);
      setCourseCode(ccode);
      setCGPA(gpa);
      setCourseGrade(CGrades);

    }

    void display(){
        cout << "Name: " << Name <<endl
             << "Date of Birth" << DOB<<endl
             << "Roll Number: " << RollNumber<<endl
             << "Batch:" << batch
             << "Degree: " << Degree<<endl;

        cout << "Course Name         Course Code         Grade"<<endl;
        for(int i=0;i<5;i++){
            cout << Courses_Name[i] << "     " << Courses_Code[i] << "     " << Courses_Grades[i] << endl;
        }

        cout << "CGPA: "<< CGPA << endl;

    }


};

void studentDemo(){
    Student s;

    s.setRollNumber("I180474");
    s.setBatch(18);
    s.setCGPA(3.4);
    s.setName("Maaz");
    s.setDegree("BSCS");
    s.setDOB("24DEC");
    s.setValues();
    cout<<s.getName()<<endl;
    cout<<s.getDOB()<<endl;
    cout<<s.getCGPA()<<endl;
    cout<<s.getDegree()<<endl;
    cout<<s.getBatch()<<endl;
    cout<<s.getRoll()<<endl;
    s.display();
}
