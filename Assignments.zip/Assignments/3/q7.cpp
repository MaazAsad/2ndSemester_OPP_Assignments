#include<iostream>
using namespace std;

class Account{
    float balance;

public:
    Account(){
        balance =0;
    }
    Account(float x){
        if(x>0){
            balance = x;
        }
        else
            balance =0;
    }
    void deposit(float n){
        if(n>0)
            balance += n;
    }
    bool withdraw(float n){
        if(balance >n && n>0){
            balance -=n;
            return true;
        }
        balance -=5;
        return false;
    }
    float inquire(){return balance;}
};
