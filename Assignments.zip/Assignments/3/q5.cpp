#include<iostream>
using namespace std;

class Employee2{
    char* name;
    float HourlyWage,WorkedHours,ExtraHours;
public:
    Employee2(){
        name =NULL;
        HourlyWage = WorkedHours = ExtraHours=0;
    }
    Employee2(char*n, float _hourlyWage,float _WorkedHours,float _ExtraHours){
        name = n;
        HourlyWage = _hourlyWage;
        if(_WorkedHours >=0 && _WorkedHours <=40){
            WorkedHours = _WorkedHours;
        }
        else if(_WorkedHours>40){
            WorkedHours = 40;
        }
        ExtraHours = _ExtraHours;
    }
    void setName(char *n){
        name =n;
    }

	void hourlyWage(float wage){
        HourlyWage = wage;
    }
	void setWorkedHours(float worked){
        if(worked >=0 && worked <=40){
            WorkedHours = worked;
        }
        else if(worked>40){
            WorkedHours = 40;
            ExtraHours = worked-40;
        }
    }
	void setExtraHours(float over){
        ExtraHours = over;
    }

    float wageCalculator(){
        return (HourlyWage*WorkedHours) + (HourlyWage*1.5 * ExtraHours);
    }
};
