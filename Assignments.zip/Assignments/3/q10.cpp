#include<iostream>
using namespace std;

class Array{
    int *a;
    int size,currentsize;
    bool sorted;
    bool is_empty;
public:
  Array(){
    size =1;
    currentsize =-1;
    a= new int[size];
    sorted = false;
    is_empty = false;
  }
  Array(int siz){
    size =siz;
    currentsize =-1;
    a = new int[size];
    sorted = false;
    is_empty = false;
  }
  Array(int *arr, int siz){
    a = new int[siz];
    size =siz;
    currentsize =-1;
    for(int i=0; i<size; i++){
      a[i] = arr[i];
      ++currentsize;
    }
    sorted = false;
    is_empty = false;
  }
  Array(const Array &b){
    this->size=b.length();
    currentsize = b.getcurrent();
    a = new int[this->size];
    for(int i=0; i<this->size; i++){
      a[i] = b.getAt(i);
    }
    sorted = false;
    is_empty = false;
  }


  int getcurrent() const {return currentsize;}

  int getAt(int i) const{
    if(i>=0 && i < this->size){
      return a[i];
    }
    else{
      cout << "invalid Index" <<endl;
      return -1;
    }
  }

  void setAt(int i, int val){

    if(i>=0 && i < this->size){
         ++currentsize;
      a[i] = val;
    }
    else{
      cout << "invalid Index" <<endl;
    }
  }

  Array subArr(int pos,int size){
    if(pos < this->size){
      if(size<= (currentsize)){
        Array x(size);
        for(int i=0;i<size;i++){
          x.push_back( a[pos+i]);
        }
        return x;
      }


      else if(size> (this->size-currentsize)){
          cout << "Invalid size" << endl;
          return 0;
      }
  }


    else{
      cout << "Invalid position" << endl;
      return 0;
    }
  }

  Array subArr(int pos){
    if(pos < this->size){
      Array x(size-pos+1);
        for(int i=0;i<size;i++){
          x.push_back(a[pos+i]);
    }
    return x;
    }

    else{
      cout << "Invalid position" << endl;
      return 0;
    }
  }

  int* subArrPointer(int pos){
    if(pos < this->size){
      if(size<= (currentsize)){
        int *x = new int[size+1];
        for(int i=0;i<size;i++){
          x[i] = a[pos+i];
        }

        return x;
      }

      else if(size> (this->size-currentsize)){
          cout << "Invalid size" << endl;
          return 0;
      }
    }

    else{
      cout << "Invalid position" << endl;
      return 0;
    }
  }

  int* subArrPointer(int pos,int size){
    if(pos < this->size){
      int* x = new int[size-pos];
        for(int i=0;i<size;i++){
          x[i] = a[pos+i];
    }
    return x;
    }
    else{
      cout << "Invalid position" << endl;
      return 0;
    }
  }

  void push_back(int num){
      ++currentsize;
      if(currentsize < size){
          sorted = false;
          a[currentsize] =num;
      }
      else{
          //cout << "Array is full"<<endl;
          --currentsize;
      }

  }

  int pop_back(){
      int num = a[currentsize];
      --currentsize;
      return num;
  }

  int insert(int idx, int val){
      ++currentsize;
      if(currentsize < size){
          int temp = a[idx];
          int temp2;
          a[idx]= val;
          for(int i= idx+1; i<currentsize; i++){
              temp2 = a[i];
              a[i] = temp;
              temp = temp2;
          }

          return 1;
      }
      else{
          --currentsize;
          return -1;
      }
  }

  int erase(int idx, int val){
      if(a[idx] == val){
          for(int i=idx; i<currentsize;i++){
              a[i] = a[i+1];
          }
          --currentsize;
          return 1;
      }
      else
        return -1;
  }



  int length() const{
      return size;
  }

  void clear(){
      for(int i=0; i<size; i++){
          a[i] =0;
      }
      is_empty = true;
  }

  int value(int idx){
      if(idx <= currentsize){
          return a[idx];
      }
      cout << "Invalid idx" << endl;
      return -1;
  }

  void assign(int idx, int val){
      if(idx <= currentsize){
          sorted = false;
          a[idx] = val;
      }
      else{}
        cout << "Invalid idx" << endl;
    }


    void copy(const Array & arr){
        if(size == arr.length()){
            for(int i=0; i<size ; i++){
                a[i] = arr.getAt(i);
            }
        }
        else{
        cout << "Invlaid size" << endl;
        }
    }

    void copy(const int * arr, int siz ){
        if(size == siz){
            for(int i=0; i<size ; i++){
                a[i] = arr[i];
            }
        }
        cout << "Invlaid size" << endl;
    }

    void display(){
        for(int i=0; i<=currentsize; i++){
            cout << a[i] << endl;
        }
    }

    bool isEmpty(){

        if(currentsize == -1 || is_empty){
            return true;
        }
        for(int i=0; i<currentsize; i++){
            if(a[i] !=0)
                return false;
        }
        return false;
    }

    Array find(int val){
        int count=0;
        for(int i=0 ;i<=currentsize; ++i){
            if(a[i]== val)
                    ++count;
        }

        Array idxes(count);
        for(int i=0 ;i<=currentsize; ++i){
            if(a[i]== val)
                    idxes.push_back(i);
        }

        return idxes;
    }

    bool equal(const Array &arr){
        if(currentsize == arr.getcurrent()){
            int count =0;
            for(int i=0; i<=currentsize;i++){
                if(a[i] == arr.getAt(i)){
                    ++count;
                }
            }

            if(count == size)
                return true;
        }

        return false;
    }


    int sort(){
        if(!sorted){
            int temp;
            for(int i=0; i<currentsize; i++){
                if(a[i]>a[i+1]){
                    temp = a[i];
                    a[i] = a[i+1];
                    a[i+1] = temp;
                }
            }
        sorted = true;
        }

        return sorted;
    }

    void reverse(){
        int temp;
        for(int i=0, j=i+1; i<currentsize/2; i++,j++){
            temp = a[i];
            a[i] = a[currentsize - j];
            a[currentsize-j] = temp;
        }
    }

    ~Array(){
        delete []a;
    }
};
