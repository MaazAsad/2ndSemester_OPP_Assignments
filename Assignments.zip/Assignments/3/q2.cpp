#include<iostream>
using namespace std;

class Car{
    float fuel_efficency, _tank;
public:
    Car(){
        fuel_efficency = 10;
        _tank =0;
    }
    Car(float Effi){
        fuel_efficency = Effi;
        _tank =0;
    }
    Car(float Effi,float f){
        fuel_efficency = Effi;
        _tank =f;
    }
    float getFuelLevel(){
        return _tank;
    }
    void tank(float fuel_added){
        _tank+= fuel_added;
    }

    void drive(float distance){
        _tank -= distance/fuel_efficency;
    }
};
