#include<iostream>
using namespace std;


class FlightInfo{
    int FlightNumber;
    char* Destination;
    float Distance,Fuel;
public:
    FlightInfo(int no, char* Dest, float distance){
        FlightNumber = no;
        Destination = Dest;
        Distance = distance;
        if(Distance<=1000 &&Distance>0){
            Fuel = 500;
        }
        else if(Distance >1000 && Distance <=2000){
            Fuel = 1100;
        }
        else if(Distance>2000){
            Fuel = 2200;
        }
    }

    void calFuel(){
        if(Distance<=1000 &&Distance>0){
            Fuel = 500;
        }
        else if(Distance >1000 && Distance <=2000){
            Fuel = 1100;
        }
        else if(Distance>2000){
            Fuel = 2200;
        }
    }

    void showInfo(){
        cout << FlightNumber << ' ' <<
                Destination << ' ' <<
                Distance << ' ' <<
                Fuel << endl;
    }

    float getFuel(){
        return Fuel;
    }
};
