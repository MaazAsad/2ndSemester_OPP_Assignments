#include "Bigint.h"
#include <string>
BigInt::BigInt(int val = 0){

}
BigInt::BigInt(const string& text){

}
BigInt::BigInt(const BigInt& copy){

} // copy constructor

// Binary Operators
// Arithmetic Operators
BigInt BigInt::operator+(const BigInt& val) const{
    return *this;
}
BigInt BigInt::operator+(int val) const{
    return *this;
}
BigInt BigInt::operator-(const BigInt& val) const{
    return *this;
}
BigInt BigInt::operator-(int val) const{
    return *this;
}
BigInt BigInt::operator*(const BigInt& val) const{
    return *this;
}
// Compound Assignment Operators
BigInt BigInt::operator+=(const BigInt& rhs){
    return *this;
}
BigInt BigInt::operator-=(const BigInt& rhs){
    return *this;
}
BigInt BigInt::operator*=(const BigInt& rhs){
    return *this;
}
// Logical Operators
bool BigInt::operator==(const BigInt& val) const{
    return false;
}
bool BigInt::operator!=(const BigInt& val) const{
    return false;
}
bool BigInt::operator<(const BigInt& val) const{
    return false;
}
bool BigInt::operator<=(const BigInt& val) const{
    return false;
}
bool BigInt::operator>(const BigInt& val) const{
    return false;
}
bool BigInt::operator>=(const BigInt& val) const{
    return false;
}

// Unary Operators
BigInt& BigInt::operator++(){
    return *this;
}  // Pre-increment Operator
BigInt BigInt::operator++(int){
    return *this;
}  // Post-increment Operator
BigInt& BigInt::operator--(){
    return *this;
}  // Pre-decrement Operator
BigInt BigInt::operator--( int x){
    return *this;
} // Post-decrement Operator

//Conversion Operator
BigInt::operator string(){
    string x;
    return x;
}    // return value of the BigInt as string
BigInt::~BigInt(){

} // destructor

ostream& operator<<(ostream& output, const BigInt& val){
    return output;
} // outputs the BigInt
istream& operator>>(istream& input, BigInt& val{
    return input;
}; // inputs the BigInt
