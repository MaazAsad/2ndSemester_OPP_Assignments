/*
 * Polynomial.cpp
 *
 *  Created on: Apr 6, 2019
 *      Author: abc
 */

#include "Polynomial.h"

Polynomial::Polynomial()
{
	max = 0;
	arr = new int[0];
	arr[0] = 0;
}

Polynomial::Polynomial(int n)
{
	max = n;
	arr = new int[n];
	for(int i = 0; i <= max; i++)
	{
		arr[i] = 0;
	}
}

Polynomial::Polynomial(const Polynomial &abc)
{
	max = abc.max;
	arr = new int[max];
	for(int i = 0; i <= max; i++)
	{
		arr[i] = abc.arr[i];
	}
}
// Binary Operators
// Assignment Operator

Polynomial Polynomial::operator=(const Polynomial& rhs)
{
	if(max == rhs.max)
	{
		for(int i = 0; i <= max; i++)
		{
			arr[i] = rhs.arr[i];
		}
	}
	else
	{
		delete []arr;
		max = rhs.max;
		arr = new int[max];
		for(int i = 0; i <= max; i++)
		{
			arr[i] = rhs.arr[i];
		}
	}
	return *this;
}

// Arithmetic Operators

Polynomial Polynomial::operator+(const Polynomial &abc)
{
	Polynomial a(*this);
	if(max >= abc.max)
	{
		for(int i = 0; i <= abc.max; i++)
		{
			a.arr[i] += abc.arr[i];
		}
	}
	else
	{
		if(max < abc.max)
		{
			for(int i = 0; i <= max; i++)
			{
				a.arr[i] += abc.arr[i];
			}
		}
	}
	return a;
}

Polynomial Polynomial::operator-(const Polynomial &abc)
{
	Polynomial a(*this);
	if(max >= abc.max)
	{
		for(int i = 0; i <= abc.max; i++)
		{
			a.arr[i] -= abc.arr[i];
		}
	}
	else
	{
		if(max < abc.max)
		{
			for(int i = 0; i <= max; i++)
			{
				a.arr[i] -= abc.arr[i];
			}
		}
	}
	return a;
}

// Compound Assignment Operators
void Polynomial::operator+=(const Polynomial&abc)
{
	*this = *this + abc;
}

void Polynomial::operator-=(const Polynomial&abc)
{
	*this = *this - abc;
}

// Logical Operator
bool Polynomial::operator==(const Polynomial &abc)
{
	if(max != abc.max)
	{
		if(max > abc.max)
		{
			for(int i = abc.max + 1; i <= max; i++)
			{
				if(arr[i] != 0)
					return false;
			}
		}
		if(max < abc.max)
		{
			for(int i = max + 1; i <= abc.max; i++)
			{
				if(abc.arr[i] != 0)
					return false;
			}
		}
	}
	for(int i = 0; i <= max; i++)
	{
		if(arr[i] != abc.arr[i])
			return false;
	}
	return true;
}
// Conversion Operator
Polynomial::operator string() const
{
	string a;
	bool flag = 0;
	for(int i = max; i >= 0; i--)
	{
		if(arr[i] == 0)
		{

		}
		else if(i == max)
		{
			if(arr[i] != 1 && i != 0)
				a += to_string(arr[i]);
			if(i == 0)
				a += to_string(arr[i]);
			if(i > 1)
			{
				a += "x^";
				a += to_string(i);
			}
			else if(i == 1)
				a += "x";
		}
		else if(arr[i] < 0 && i != max)
		{
			a += " - ";
			arr[i] *= -1;
			a += to_string(arr[i]);
			if(i > 1)
			{
				a += "x^";
				a += to_string(i);
			}
			else if(i == 1)
				a += "x";
		}
		else if(arr[i] > 0)
		{
			if(i != max)
			{
				a += " + ";
				if(arr[i] != 1)
					a += to_string(arr[i]);
				else if(i == 0)
					a += to_string(arr[i]);
				if(i > 1)
				{
					a += "x^";
					a += to_string(i);
				}
				else if(i == 1)
					a += "x";
			}
		}
		if(arr[i] != 0)
			flag = 1;
	}
	if(flag == 0)
		a += to_string(0);
	return a;
}
Polynomial::~Polynomial()
{
	delete[]arr;
	max = 0;
}

int Polynomial::getMax()
{
	return max;
}

int Polynomial::getValue(int index)
{
	return arr[index];
}

void Polynomial::setMax(int m)
{
	if(m > 0 && m < max)
		max = m;
}

void Polynomial::setValue(int n, int index)
{
	arr[index] = n;
}

ostream& operator<<(ostream& output, const Polynomial&abc)
{
	output<<string(abc);
	return output;
}

istream& operator>>(istream& input, Polynomial&abc)
{
	int a;
	/*cout<<"Enter the highest degree of polynomial: ";
	cin>>a;
	abc.setMax(a);
	cout<<abc.getMax()<<endl;*/
	cout<<"Enter values starting from greatest degree of x: ";
	for(int i = abc.getMax()+1; i >= 0; i--)
	{
		input>>a;
		abc.setValue(a,i);
		//cout<<abc.getValue(i)<<endl;
	}
	return input;
}
