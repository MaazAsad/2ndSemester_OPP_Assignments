/*
 * Rational.cpp
 *
 *  Created on: Apr 6, 2019
 *      Author: abc
 */

#include "Rational.h"

Rational::Rational()
{
	num = 0;
	denum = 1;
}

Rational::Rational(int n,int d)
{
	num = n;
	if(d != 0)
		denum = d;
	else
		denum = 1;
	int gd = gcd(num,denum);
	num /= gd;
	denum /= gd;
}

Rational::Rational(const Rational &copy)
{
	num = copy.num;
	denum = copy.denum;
	int gd = gcd(num,denum);
	num /= gd;
	denum /= gd;
}

int Rational::gcd(int a, int b)const
{
	if(a == 0 || b == 0)
		return 1;
	if(a < 0)
		a *= -1;
	if(b < 0)
		b *= -1;
	if(a != 0 || b != 0)
	{
		if(a > b)
		{
			if(a%b == 0)
			{
				return b;
			}
			else
				gcd(a,b-1);
		}
		if(a < b)
		{
			if(b%a == 0)
			{
				return a;
			}
			else
				gcd(a-1,b);
		}
		if(a == b)
			return a;
	}
	return 1;
}


// Binary Operators

// Assignment Operator
Rational Rational::operator=(const Rational &x)
{
	num = x.num;
	denum = x.denum;
	return *this;
}

// Arithmetic Operators
Rational Rational::operator+(const Rational &x) const
{
	int gd;
	Rational a(*this);
	a.num = (a.num*x.denum)+(x.num*a.denum);
	a.denum *= x.denum;
	gd = gcd(a.num,a.denum);
	a.num /= gd;
	a.denum /= gd;
	if(a.num < 0 && a.denum < 0)
	{
		a.num *= -1;
		a.denum *= -1;
	}
	return a;
}
Rational Rational::operator-(const Rational &x) const
{
	int gd;
	Rational a(*this);
	a.num = (a.num*x.denum)-(x.num*a.denum);
	a.denum *= x.denum;
	gd = gcd(a.num,a.denum);
	a.num /= gd;
	a.denum /= gd;
	if(a.num < 0 && a.denum < 0)
	{
		a.num *= -1;
		a.denum *= -1;
	}
	return a;
}
Rational Rational::operator*(const Rational &x) const
{
	int gd;
	Rational a(*this);
	a.num *= x.num;
	a.denum *= x.denum;
	gd = gcd(a.num,a.denum);
	a.num /= gd;
	a.denum /= gd;
	if(a.num < 0 && a.denum < 0)
	{
		a.num *= -1;
		a.denum *= -1;
	}
	return a;
}
Rational Rational::operator/(const Rational &x) const
{
	int gd;
	Rational a(*this);
	a.num *= x.denum;
	a.denum *= x.num;
	gd = gcd(a.num,a.denum);
	a.num /= gd;
	a.denum /= gd;
	if(a.num < 0 && a.denum < 0)
	{
		a.num *= -1;
		a.denum *= -1;
	}
	return a;
}

// Compound Arithmetic Operators
Rational Rational::operator += (const Rational &x)
{
	*this = *this + x;
	return *this;
}
Rational Rational::operator -= (const Rational &x)
{
	*this = *this - x;
	return *this;
}
Rational Rational::operator *= (const Rational &x)
{
	*this = (*this) * x;
	return *this;
}
Rational Rational::operator /= (const Rational &x)
{
	*this = (*this) / x;
	return *this;
}

// Logical Operators
bool Rational::operator == (const Rational & other) const
{
	if(num == other.num && denum == other.denum)
		return true;
	return false;
}

bool Rational::operator < (const Rational & other) const
{
	if(num == other.num && denum == other.denum)
		return false;
	float a,b;
	float c,d;
	c = num;
	d = other.num;
	a = c/denum;
	b = d/other.denum;
	if(a < b)
	{
		return true;
	}
	return false;
}

bool Rational::operator > (const Rational & other) const
{
	if(num == other.num && denum == other.denum)
		return false;
	float a,b;
	float c,d;
	c = num;
	d = other.num;
	a = c/denum;
	b = d/other.denum;
	if(a > b)
	{
		return true;
	}
	return false;
}

bool Rational::operator <= (const Rational & other) const
{
	if(num == other.num && denum == other.denum)
		return true;
	float a,b;
	float c,d;
	c = num;
	d = other.num;
	a = c/denum;
	b = d/other.denum;
	if(a > b)
	{
		return true;
	}
	return false;
}


bool Rational::operator >= (const Rational & other) const
{
	if(num == other.num && denum == other.denum)
		return true;
	float a,b;
	float c,d;
	c = num;
	d = other.num;
	a = c/denum;
	b = d/other.denum;
	if(a > b)
	{
		return true;
	}
	return false;
}


int Rational::getNum()const
{
	return num;
}

int Rational::getDenum()const
{
	return denum;
}

void Rational::setNum(int n)
{
	num = n;
}

void Rational::setDenum(int d)
{
	if(d != 0)
		denum = 0;
}
// Unary Operator
// Conversion Operator
Rational::operator string() const
{
	string a;
	if(denum == 1)
	{
		a += to_string(num);
	}
	else if(num == 0)
	{
		a += to_string(num);
	}
	else
	{
		a += to_string(num);
		a += "/";
		a += to_string(denum);
	}
	return a;
}
Rational::~Rational()
{

}


// Operator Overloading as Non-Member Functions
// Stream Insertion and Extraction Operators
ostream& operator<<(ostream& output, const Rational &abc)
{
	output<<abc.getNum()<<"/"<<abc.getDenum();
	return output;
}

istream& operator>>(istream& input, Rational&abc)
{
	int a;
	cout<<"Enter numerator: ";
	input>>a;
	abc.setNum(a);
	cout<<"Enter denominator: ";
	input>>a;
	abc.setDenum(a);
	return input;
}

// int main()
// {
// 	Rational a(2,4);
// 	Rational b(1,2);
// 	b = b-a;
// 	cout<<string(a)<<endl;
// 	cout<<string(b)<<endl;
// 	Rational c(1,1);
// 	//b += a;
// 	//c += b;
// 	cout<<string(b)<<endl;
// 	return 0;
// }
