/*
 * Polynomial.h
 *
 *  Created on: Apr 6, 2019
 *      Author: abc
 */

#ifndef POLYNOMIAL_H_
#define POLYNOMIAL_H_

#include<iostream>
#include <string>
using namespace std;

class Polynomial
{
	int *arr;
	int max;

public:
//include all the necessary checks before performing the operations in the functions
Polynomial(); // a default constructor
Polynomial(int); // a parameterized constructor, received the highest degree of polynomial
Polynomial(const Polynomial &); // a copy constructor
int getValue(int);
void setValue(int n, int index);
void setMax(int m);
int getMax();
// Binary Operators
// Assignment Operator
Polynomial operator=(const Polynomial& rhs); //assigns (copies) the rhs Polynomial to "this" Polynomial
// Arithmetic Operators
Polynomial operator+(const Polynomial &); // adds two Polynomials and returns the result
Polynomial operator-(const Polynomial &); // subtracts two Polynomials and returns the result
// Compound Assignment Operators
void operator+=(const Polynomial&); // adds two Polynomials
void operator-=(const Polynomial&); // subtracts two Polynomials
// Logical Operator
bool operator==(const Polynomial &); // compares and returns true if equal

// Conversion Operator
operator string() const; // returns the value of the Polynomial as a string like 4x^3 + 3x + 2
~Polynomial(); // destructor
};

ostream& operator<<(ostream& output, const Polynomial&); // outputs the Polynomial
istream& operator>>(istream& input, Polynomial&); // inputs the Polynomial


#endif /* POLYNOMIAL_H_ */
