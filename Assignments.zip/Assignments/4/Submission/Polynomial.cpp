#include"Polynomial.h"
#include<string>
using namespace std;
Polynomial::Polynomial(){
    degree = 0;
    coef = new int[1];
    coef[0] = 0;
} // a default constructor
Polynomial::Polynomial(int x){
    degree = x;
    coef = new int[degree+1];
    for(int i=0; i<degree; i++){
        coef[i] = 0;
    }
} // a parameterized constructor, received the highest degree of polynomial
Polynomial::Polynomial(const Polynomial &x){
    degree = x.degree;
    coef = new int[degree+1];
    for(int i=0; i<degree; i++){
        coef[i] = x.coef[i];
    }
} // a copy constructor

void Polynomial::setDegree(int x){
    degree  = x;
}
void Polynomial::setCoefficients(int *x){
    for(int i=0; i<degree; i++){
        coef[i]= x[i];
    }
}


// Binary Operators
// Assignment Operator
Polynomial Polynomial::operator=(const Polynomial& rhs){
    if(degree == rhs.degree){
        for(int i=0; i<degree; i++){
            coef[i] = rhs.coef[i];
        }
    }
    else{
        delete []coef;
        degree = rhs.degree;
        coef = new int[degree+1];
        for(int i=0; i<degree; i++){
            coef[i] = rhs.coef[i];
        }
    }
} //assigns (copies) the rhs Polynomial to "this" Polynomial
// Arithmetic Operators
Polynomial Polynomial::operator+(const Polynomial &rhs){


    if(degree >= rhs.degree){
            Polynomial temp(*this);
        for(int i = 0; i <= rhs.degree; i++){
            temp.coef[i] += rhs.coef[i];
        }
        return temp;
    }
    else{
        if(degree < rhs.degree){
                Polynomial temp(rhs);
            for(int i = 0; i <= degree; i++){
                temp.coef[i] += rhs.coef[i];
            }
            return temp;
        }
    }



} // adds two Polynomials and returns the result
Polynomial Polynomial::operator-(const Polynomial &rhs){
    Polynomial temp(*this);
    if(temp.degree >= rhs.degree){
        for(int i=0; i<temp.degree; i++){
            temp.coef[i]-= rhs.coef[i];
        }
    }
    else{
        if(temp.degree < rhs.degree){
            for(int i=0; i<temp.degree; i++){
                temp.coef[i]-= rhs.coef[i];
            }
        }
        else{
        for(int i=0; i<rhs.degree; i++){
            temp.coef[i]-= rhs.coef[i];
            }
        }
    }

    return temp;
} // subtracts two Polynomials and returns the result
// Compound Assignment Operators
void Polynomial::operator+=(const Polynomial& rhs){
    *this = *this + rhs;
} // adds two Polynomials
void Polynomial::operator-=(const Polynomial& rhs){
    *this = *this - rhs;
} // subtracts two Polynomials
// Logical Operator
bool Polynomial:: operator==(const Polynomial &rhs){
    if(degree == rhs.degree){
        for(int i=0; i<degree; i++){
            if(coef[i] != rhs.coef[i])
                return false;
        }
        return true;
    }

    return false;
} // compares and returns true if equal

// Conversion Operator
Polynomial::operator string() const{
    string temp;
    for(int i=0; i<degree;++i){
        if(i == degree-1){
            temp += to_string(coef[i]);
            break;
        }
        // else if(i == 0 && coef[i] != 1 && coef[i] !=0){
        //     if(coef[i]>0)
        //     temp += to_string(coef[i]);
        //     temp += "x^";
        //     temp += to_string(degree-i);
        //     temp += ' ';
        // }
        // if(i == degree -1){
            if(coef[i] != 1 && coef[i] !=0){
                if(coef[i]>0)
                temp += to_string(coef[i]);

                if( degree -1-i != 1){
                    temp += "x^";
                    temp += to_string(degree-1-i);
                }
                else{
                    temp+="x";
                }
                if (i!=degree-1 && coef[i+1]>0)
                    temp += " + ";
                else if(i!=degree-1 && coef[i+1]<0)
                    temp += " - ";
            }
            else if(coef[i] == 1){
                temp += "x^";
                if( degree -1-i != 1)
                    temp += to_string(degree-1-i);
                if (i!=degree-1 && coef[i+1]>0)
                    temp += " + ";
                else if(i!=degree-1 && coef[i+1]<0)
                    temp += " - ";
            }
            else if(coef[i] == 0){
                continue;
            }
        // }
        // else{

        // }
    }
    return temp;
} // returns the value of the Polynomial as a string like �4x^3 + 3x + 2�

void Polynomial::setAt(int idx,int data){
    coef[idx] = data;
}
Polynomial::~Polynomial(){

} // destructor


ostream& operator<<(ostream& output, const Polynomial&x){
    output << (string)x;
    return output;
} // outputs the Polynomial
istream& operator>>(istream& input, Polynomial&x){
    int degree;
    int temp;
    int *arr;
    cout << "Enter Highest degree: ";
    input >> degree;
    arr = new int [degree+1];
    for(int i=0; i<degree; i++){
        arr[i]=0;
    }
    cout << "Enter coefficents from the highest degree: ";
    for(int i=0; i<=degree; i++){
        input >> arr[i];
        // x.setAt(i,temp);
    }
    x.setDegree(degree+1);
    x.setCoefficients(arr);

    return input;

} // inputs the Polynomial
