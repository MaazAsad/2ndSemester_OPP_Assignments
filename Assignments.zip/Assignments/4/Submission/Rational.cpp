#include"Rational.h"
#include<string>
using namespace std;
void Rational::reducefraction (){
        for (int i = this->denominator * this->numerator; i > 1; i--) {
            if ((this->denominator % i == 0) && (this->numerator% i == 0)) {
                this->denominator /= i;
                this->numerator /= i;
            }

         }
}



Rational::Rational(int n,int d){
    this->numerator = n;
    this->denominator = d;
    reducefraction();
}
Rational::Rational(const Rational &copy){
    this->numerator = copy.numerator;
    this->denominator = copy.denominator;
    reducefraction();
}// copy constructor to initialize the Rational form existing Rational //object

// Binary Operators
// Assignment Operator
void Rational::operator = (const Rational &x){
    this->numerator = x.numerator;
    this->denominator = x.denominator;
}

// Arithmetic Operators
Rational Rational::operator+(const Rational &x) const{
    Rational result( (this->numerator * x.denominator) + (x.numerator * this->denominator), this->denominator * x.denominator ) ;
    return result;
}
Rational Rational::operator-(const Rational &x) const{
    Rational result( (this->numerator * x.denominator) - (x.numerator * this->denominator), this->denominator * x.denominator);
    return result;
}
Rational Rational::operator*(const Rational &x) const{
    Rational result(this->numerator* x.getNumerator(), this->denominator * x.getDenominator());
    return result;
}
Rational Rational::operator/(const Rational &x) const{
    Rational result(this->numerator* x.getDenominator(), this->denominator *x.getNumerator());
    return result;
}
// Compound Arithmetic Operators
void Rational::operator += (const Rational &x){
    int num = this->numerator * x.denominator + this->denominator * x.numerator;
    int denom = this->denominator * x.denominator;
    this->numerator = num;
    this->denominator = denom;
    reducefraction();
}
void Rational::operator -= (const Rational &x){

    int num = this->numerator * x.denominator - this->denominator * x.numerator;
    int denom = this->denominator * x.denominator;
    this->numerator = num;
    this->denominator = denom;
    reducefraction();
}
void Rational::operator *= (const Rational &x){
    int num = this->numerator * x.numerator;
    int denom =  this->denominator * x.denominator;
    this->numerator = num;
    this->denominator = denom;
    reducefraction();
}
void Rational::operator /= (const Rational &x){
    int num = this->numerator * x.denominator;
    int denom =  this->denominator * x.numerator;
    this->numerator = num;
    this->denominator = denom;
    reducefraction();
    //reducefraction();
}
// Logical Operators
bool Rational::operator == (const Rational & other) const{
    if(this->numerator == other.numerator && this->denominator == other.denominator)
        return true;
    return false;
}
bool Rational::operator < (const Rational & other) const{
    float num1 = (float)this->numerator / this->denominator;
    float num2 = (float)other.numerator / other.denominator;

    if (num1< num2)
        return true;
    return false;
    // if(this->denominator > other.denominator && (this->denominator != 1 && other.denominator != 1) )
    //     return true;
    // if(this->denominator == other.denominator && this->numerator < other.numerator)
    //     return true;
    // return false;
}
bool Rational::operator > (const Rational & other) const{
    return (other< *this);
}
bool Rational::operator <= (const Rational & other) const{
    return !(*this>other);
}
bool Rational::operator >= (const Rational & other) const{
    return !(*this<other);
}


Rational::operator string() const{
    std::string temp="";
    if(this->denominator == 1){
        temp +=to_string(this->numerator);
        return temp;
    }
    temp +=to_string(this->numerator);
    temp +="/";
    temp += to_string(this->denominator);
    return temp;
} // returns 2/3 as �2/3�. If the denominator is 1 then only the numerator is returned, i.e. for 2/1 the operator shall return �2�



// Operator Overloading as Non-Member Functions
// Stream Insertion and Extraction Operators
ostream& operator<<(ostream& output, const Rational &x){
    output << (string)x;
    return output;
} 	// outputs the Rational
istream& operator>>(istream& input, Rational&x){
    int n,d;
    cout << "Enter Numerator followed Denominator: ";
    input >> n >> d;
    x.setNumerator(n);
    x.setDenominator(d);
    x.reducefraction();
    return input;

}
