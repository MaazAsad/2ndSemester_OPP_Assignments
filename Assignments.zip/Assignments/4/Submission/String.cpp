#include"String.h"
#include<string>
String::String(){
    mystr = new char;
    *mystr = '\0';
    size =1;
} // default constructor
String::String(const char *str){
    int i=0;
    for(;str[i];++i);
    size = i;
    mystr = new char[size];

    for(i=0; str[i];++i)
        mystr[i] = str[i];
} // initializes the string with constant c-string
String::String(const String &x){
    size = x.size;
    mystr = new char[size];
    for(int i=0;x.mystr[i];++i)
        mystr[i] = x.mystr[i];
} // copy constructor to initialize the string from the existing string
String::String(int x){
    size =x;
    mystr = new char[size];
    for(int i=0; i<x; i++)
        mystr[i]='\0';
} // initializes a string of predefined size

// Binary Operators
// Sub-script Operators
char &String::operator[](int i){
    if(i>=0 && i<size)
        return mystr[i];
    return mystr[size-1];
} // returns the character at index [x]
const char String::operator[](int i) const{
    if(i>=0 && i<size)
        return mystr[i];
    return mystr[size-1];
}// returns the character at index [x]

// Arithmetic Operators
String String::operator+(const String &str) const{
    int newsize = size + str.getsize();
    char* temp = new char[newsize];

    int i;
    for(i=0; i<size; ++i){
        temp[i] = mystr[i];
    }

    for(int j=0;i<newsize; ++i,++j){
        temp[i]= str[j];
    }

    String temp1(temp);
    return temp1;


}; // appends a String at the end of the String
String String::operator+(const char &str) const{
    int newsize = size + 1;
    char* temp = new char[newsize];

    int i;
    for(i=0; i<size; ++i){
        temp[i] = mystr[i];
    }
    temp[i] = str;
    String temp1(temp);
    return temp1;

} // appends a char at the end of the String
String String::operator+(char *&str) const{
    int len;
    for(len =0; str[len]!= '\0'; ++len);
    int newsize = size + len;
    char* temp = new char[newsize];

    int i;
    for(i=0; i<size; ++i){
        temp[i] = mystr[i];
    }
    for(int j=0;i<newsize; ++i,++j){
        temp[i]= str[j];
    }

    String temp1(temp);
    return temp1;
} // appends a String at the end of the String
String String::operator-(const String &substr) const{
    String temp;
    int j=0;
    for(int i=0 ; mystr[j]!='\0';++j){
        if(substr.mystr[j]!= mystr[j]){
            temp = temp + mystr[j];
            ++i;
        }

    }
    return temp;

} //removes the substr from the String
String String::operator-(const string &substr) const{
    String temp;
    int j=0;
    for(int i=0; mystr[j]!='\0';++j){
        if(substr[j]!= mystr[j]){
            temp = temp + mystr[j];++i;
        }
    }

    return temp;
} //removes the substr from the String
// Assignment Operators
String& String::operator=(const String&str){
    if(this != &str){
        this->size = str.getsize();
        delete []mystr;
        mystr = new char[size];
        for(int i=0; i<size;i++)
            mystr[i] = str[i];
        return *this;
    }
    else
        return *this;
    }
 // copies one String to another
String& String::operator=(char* s){
    int len;
    for(len =0; s[len];++len);
    size = len;
    delete []mystr;
    mystr = new char[size];
    for(int i=0; s[i];++i){
        mystr[i] = s[i];
    }
    return *this;
} // copies one c-string to another
String& String::operator=(const string&s){
    int len;
    for(len =0; s[len];++len);
    size = len;
    delete []mystr;
    mystr = new char[size];
    for(int i=0; s[i];++i){
        mystr[i] = s[i];
    }
    return *this;
} // copies one string to another
// Logical Operators
bool String::operator==(const String&str) const{
    if(size == str.getsize()){
        for(int i=0; i<size; i++){
            if(mystr[i]!=str.mystr[i])
                return false;
        }
        return true;
    }
    return false;
} // returns true if two Strings are equal
bool String::operator==(const string&str) const{
    int len;
    for(len =0; str[len];++len);
    if(size == len){
        for(int i=0; i<size; i++){
            if(mystr[i]!=str[i])
                return false;
        }
        return true;
    }
    return false;

} // returns true if the string is equal to the String
bool String::operator==(char *str) const{
    int len;
    for(len =0; str[len];++len);
    if(size == len){
        for(int i=0; i<size; i++){
            if(mystr[i]!=str[i])
                return false;
        }
        return true;
    }
    return false;
} // returns true if the c-string is equal to the String

// Unary Operators
// Boolean Not Operator
bool String::operator!(){
    if(size ==1 && *mystr == '\0')
        return true;
    return false;
} // returns true if the String is empty
// Function-Call Operators
// int String::operator()(char) const; // returns the index of the character being searched
// int String::operator()(const String&) const; // returns the index of the String being searched
// int String::operator()(const string&) const; // returns the index of the string being searched
// int String::operator()(char *) const; // returns the index of the c-string being searched
// Conversion Operator
String::operator int() const{

    return size;
} // returns the length of string
void String::print()const{
    for(int i=0; i<size; ++i){
        std::cout<< mystr[i];
    }
}
void String::set(char *str){
    mystr = str;
}

String::~String(){
    delete []mystr;
} // destructor
ostream& operator<<(ostream& output, const String&x){
    x.print();
    return output;
} // outputs the string
istream& operator>>(istream& input, String&x){
    char *c = new char;
    input >> c;
    x.set(c);
    //cout << c << endl;

    return input;
}
