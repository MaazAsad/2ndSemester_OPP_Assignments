/*
 * Rational.h
 *
 *  Created on: Mar 24, 2019
 *      Author: Hassan
 */

#ifndef RATIONAL_H_
#define RATIONAL_H_
#include <string>
using namespace std;

class Rational {
// think about the private data members
int numerator, denominator;

public:
Rational(int n=0,int d=1);
Rational(const Rational &copy);// copy constructor to initialize the Rational form existing Rational //object

int setNumerator(int x){this->numerator = x;}
int setDenominator(int x){this->denominator =x;}
int getNumerator()const{return numerator;}
int getDenominator()const {return denominator;}
// Binary Operators
// Assignment Operator
void operator = (const Rational &x);
// Arithmetic Operators
Rational operator+(const Rational &x) const;
Rational operator-(const Rational &x) const;
Rational operator*(const Rational &x) const;
Rational operator/(const Rational &x) const;
// Compound Arithmetic Operators
void operator += (const Rational &x);
void operator -= (const Rational &x);
void operator *= (const Rational &x);
void operator /= (const Rational &x);
// Logical Operators
bool operator == (const Rational & other) const;
bool operator < (const Rational & other) const;
bool operator > (const Rational & other) const;
bool operator <= (const Rational & other) const;
bool operator >= (const Rational & other) const;

void reducefraction();



// Unary Operator
// Conversion Operator
operator string() const;//3�. If the denominator is 1 then only the numerator is returned, i.e. for 2/1 the operator shall return �2�

};

// Operator Overloading as Non-Member Functions
// Stream Insertion and Extraction Operators
ostream& operator<<(ostream& output, const Rational &); 	// outputs the Rational
istream& operator>>(istream& input, Rational&); 	// inputs the Rational


#endif /* RATIONAL_H_ */
