#include "ProductionWorker.h"

ProductionWorker::ProductionWorker(int s,double pay,int num,Date d,string n,string a) :Employee(num,d,n,a){
	shift=s;
	_payrate=pay;
}
void ProductionWorker::setShift(int s){
	shift=s;
}
void ProductionWorker::setRate(int p){
	_payrate=p;
}
int ProductionWorker::getRate()const{return _payrate;}
int ProductionWorker::getShift()const{return shift;}

ProductionWorker::~ProductionWorker(){}
