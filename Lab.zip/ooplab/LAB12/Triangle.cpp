/*
 * Triangle.cpp
 *
 *  Created on: Apr 17, 2019
 *      Author: maaz
 */

#include "Triangle.h"


Triangle::Triangle(Vertex a, Vertex b,Vertex c){
	addVertex(a);
	addVertex(b);
	addVertex(c);
}

string Triangle::getSpec(){
	string temp;
	temp += "type=triangle,";
	temp += SegList::getSpec();
	return temp;
}

Triangle::~Triangle(){

}
