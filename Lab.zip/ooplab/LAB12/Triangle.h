/*
 * Triangle.h
 *
 *  Created on: Apr 17, 2019
 *      Author: maaz
 */

#ifndef TRIANGLE_H_
#define TRIANGLE_H_
#include"SegList.h"

class Triangle:public SegList {

public:
	Triangle(Vertex a, Vertex b,Vertex c);

	virtual string getSpec();
	virtual ~Triangle();
};

#endif /* TRIANGLE_H_ */
