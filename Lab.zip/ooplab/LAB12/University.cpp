/*
 * University.cpp
 *
 *  Created on: Apr 9, 2019
 *      Author: maria
 */

#include "University.h"

University::University(string n, int num){
	name=n;;
	numberOfDepartments=num;
	dept=new Department[this->numberOfDepartments];

}
void University::setName(string n){
	this->name=n;
}
string University::getName() const{ return name;}
void University::setnumberOfDepartments(int n){
	this->numberOfDepartments=n;
}
int University::getnumberOfDepartments() const{ return this->numberOfDepartments;}
void University::setDept(const Department &d ){
	this->dept[0]=d;
}
Department University::getDept() const{ return this->dept[0]; }
bool University::addDepartment(Department d){
	for(int i=0;i<this->numberOfDepartments;i++){
			if(this->dept[i].getName()=="\0")
			{
				this->dept[i].setDeptID(d.getDeptID());
				this->dept[i].setName(d.getName());
				this->dept[i].setnoOfProfressors(d.getnoOfProfessors());
				/*for(int j=0;j<this->dept->profList;i++){
					this->dept->profList[j].setDesignation(d.profList[i].getDesignation());
					this->dept->profList[i].setEmployeeID(d.profList[i].getEmployeeID());
					this->dept->profList[i].setName(d.profList[i].getName());
				}*/
				return true;

			}
		}
		return false;
}
bool University::deleteDepartment(string name){
	for(int i=0;i<this->numberOfDepartments;i++){
				if(this->dept[i].getName()==name){
					//	return true;
					for(int j=i;j<this->numberOfDepartments-1;j++){
						this->dept[j].setDeptID(this->dept[j+1].getDeptID());
						this->dept[j].setName(this->dept[j+1].getName());
						this->dept[j].setnoOfProfressors(this->dept[j+1].getnoOfProfessors());


					}

					return true;

				}
			}

			return false;
}
bool University::updateDepartment(int id, string name){
	for(int i=0;i<this->numberOfDepartments;i++){
			if(this->dept[i].getDeptID()==id){
				this->dept[i].setName(name);
				return true;
			}
		}
		return false;
}
void University::display(){
	cout<<"University Name is :"<<this->getName()<<endl;
	cout<<"University Department number is: "<<this->getnumberOfDepartments()<<endl;
	for(int i=0;i<this->numberOfDepartments;i++){
		cout<<"Department ID: "<<this->dept[i].getDeptID()<<endl;
		cout<<"Department name: "<<this->dept[i].getName()<<endl;
		cout<<"Department No of professors is: "<<this->dept[i].getnoOfProfessors()<<endl;
	}

}
University::~University() {
	// TODO Auto-generated destructor stub
}

