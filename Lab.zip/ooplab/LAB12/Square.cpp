/*
 * Square.cpp
 *
 *  Created on: Apr 17, 2019
 *      Author: maaz
 */

#include "Square.h"

Square::Square(Vertex a, Vertex b, Vertex c, Vertex d){
	addVertex(a);
	addVertex(b);
	addVertex(c);
	addVertex(d);
}

string Square::getSpec(){
	string temp;
	temp += "type=square,";
	temp += SegList::getSpec();
	return temp;
}

Square::~Square() {
	// TODO Auto-generated destructor stub
}

