#include "Person.h"

Person::Person(string n,string a):name(n),address(a){}
string Person::getName(){return name;}
string Person::getAddress(){return address;}

Person::~Person() {}
