#ifndef PERSON_H_
#define PERSON_H_
#include <iostream>
#include <string>
class Person {
protected:
	std::string name;
	std::string address;
public:
	//Person();
	Person(std::string n,std::string a);
	std::string getName();
	std::string getAddress();
	virtual ~Person();
};

#endif
