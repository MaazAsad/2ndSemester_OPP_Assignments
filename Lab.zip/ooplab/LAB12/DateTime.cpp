/*
 * DateTime.cpp
 *
 *  Created on: Apr 16, 2019
 *      Author: maaz
 */

#include "DateTime.h"

DateTime::DateTime(int year, int month, int day, int hours, int minutes,int sec):Date(year,month,day),Time(hours,minutes,sec){}

string DateTime::getDT(){
	string temp;
	temp += this->getDate();
	temp += ' ';
	temp += this->getTime();
	return temp;
}
//DateTime::~DateTime() {
//	// TODO Auto-generated destructor stub
//}

