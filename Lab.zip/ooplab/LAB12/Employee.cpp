#include "Employee.h"

Employee::Employee(int num,Date d,string n,string a) :Person(n,a){
	Employee_ID=num;
	_hire_date.setDay(d.getDay());
	_hire_date.setMonth(d.getMonth());
	_hire_date.setYear(d.getYear());
}
void Employee::setID(int n){
	Employee_ID=n;
}
void Employee::setDate(Date d){
	_hire_date=d;
}
int Employee::getID(){ return Employee_ID; }
Date Employee::getDate(){ return _hire_date;}
Employee::~Employee() {
	// TODO Auto-generated destructor stub
}
