/*
 * Date.cpp
 *
 *  Created on: Mar 26, 2019
 *      Author: maaz
 */

#include "Date.h"
#include <string>

Date::Date():mYear(0),mMonth(0),mDay(0){}
Date::Date(int day, int month, int year):mYear(year), mMonth(month), mDay(day){}


Date::Date(const Date &x) {
	mYear = x.getYear();
	mMonth = x.getMonth();
	mDay = x.getDay();

}
void Date::setDay(int a){mDay = a;}
void Date::setMonth(int a){mMonth= a;}
void Date::setYear(int a){mYear = a;}

int Date::getDay()const{
	return mDay;
}
int Date::getMonth()const{return mMonth;}
int Date::getYear()const{return mYear;}

std::string Date::getDate(){
	std::string temp;
	temp+= std::to_string(mDay);
	temp +='/';
	temp += std::to_string(mMonth);
	temp +='/';
	temp += std::to_string(mYear);
	return temp;
}

bool Date::isLeapYear()const{
	if(mYear%4){
		return false;
	}
	return true;
}
