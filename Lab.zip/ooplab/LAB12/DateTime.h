/*
 * DateTime.h
 *
 *  Created on: Apr 16, 2019
 *      Author: maaz
 */

#ifndef DATETIME_H_
#define DATETIME_H_
#include "Date.h"
#include "Time.h"
#include<string>
using namespace std;
class DateTime: public Date, public Time{
public:
	DateTime(int year,int month, int day, int hours, int minutes, int sec);
	string getDT();

//	virtual ~DateTime();
};

#endif /* DATETIME_H_ */
