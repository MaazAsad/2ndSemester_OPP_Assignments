#include "Date.h"
#include "ProductionWorker.h"
#include <iostream>
#include <string>
using namespace std;


#ifndef TEAMLEADER_H_
#define TEAMLEADER_H_

class TeamLeader :public ProductionWorker {
protected:
	double _bonus;
	int _num_train_hours;
	int _train_hours;

public:
	TeamLeader(string n, string a, int num,  Date d, int s,double hrate, double b);
	double getBonus();
	int getNumTHours();
	int getTHours();
	double calculateSalary(Date d);


	virtual ~TeamLeader();
};

#endif /* TEAMLEADER_H_ */
