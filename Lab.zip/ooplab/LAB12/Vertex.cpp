/*
 * Vertex.cpp
 *
 *  Created on: Apr 17, 2019
 *      Author: maaz
 */

#include "Vertex.h"
#include<string>
Vertex::Vertex():x(0), y(0){}
Vertex::Vertex(int x, int y):x(x),y(y){}
void Vertex::setx(int x){this->x = x;}
void Vertex::sety(int y){this->y = y;}
int Vertex::getx()const{return x;}
int Vertex::gety()const{return y;}
std::string Vertex::getSpec(){
	std::string temp;
	temp += "x=";
	temp += std::to_string(x);
	temp += ",";
	temp += "y=";
	temp += std::to_string(y);
	return temp;
}
Vertex::~Vertex() {
//	 TODO Auto-generated destructor stub
}
