/*
 * Date.h
 *
 *  Created on: Mar 26, 2019
 *      Author: maaz
 */

#ifndef DATE_H_
#define DATE_H_

#include<string>
class Date {
protected:
	int mYear,mMonth,mDay;
public:
	Date();
	Date(int day, int month, int year);
	Date(const Date &x);
	void setDay(int a);
	void setMonth(int a);
	void setYear(int a);
	int getDay()const;
	int getMonth()const;
	int getYear()const;
	std::string getDate();
	bool isLeapYear()const;

};

#endif /* DATE_H_ */
