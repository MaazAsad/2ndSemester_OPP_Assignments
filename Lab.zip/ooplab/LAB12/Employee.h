#include "Person.h"
#include "Date.h"
#ifndef EMPLOYEE_H_
#define EMPLOYEE_H_

class Employee : public Person {
protected:
	int Employee_ID;
	Date _hire_date;
public:
	Employee(int id,Date date,string _name,string add_);
	void setID(int n);
	void setDate(Date d);
	int getID();
	Date getDate();
	virtual ~Employee();
};

#endif /* EMPLOYEE_H_ */
