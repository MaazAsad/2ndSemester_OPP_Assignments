/*
 * Square.h
 *
 *  Created on: Apr 17, 2019
 *      Author: maaz
 */

#ifndef SQUARE_H_
#define SQUARE_H_
#include"SegList.h"

class Square: public SegList {
public:
	Square(Vertex a, Vertex b, Vertex c, Vertex d);
	virtual string getSpec();
	virtual ~Square();
};

#endif /* SQUARE_H_ */
