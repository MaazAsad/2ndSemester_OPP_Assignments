/*
 * SegList.cpp
 *
 *  Created on: Apr 17, 2019
 *      Author: maaz
 */

#include "SegList.h"

SegList::SegList():idx (0) {}
void SegList::addVertex(Vertex x){
	if(idx<10){
		arr[idx].setx(x.getx());
		arr[idx].sety(x.gety());
		++idx;
	}// TODO Auto-generated destructor stub
}

string SegList::getSpec(){
	string temp;

	for(int i=0; i< idx; i++){
		temp+= arr[i].getSpec();

		if(i< idx-1){
			temp +=",";
		}

	}

	return temp;
}

SegList::~SegList() {
	// delete []arr;
}
