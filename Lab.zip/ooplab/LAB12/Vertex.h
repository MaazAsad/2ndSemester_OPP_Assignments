/*
 * Vertex.h
 *
 *  Created on: Apr 17, 2019
 *      Author: maaz
 */

#ifndef VERTEX_H_
#define VERTEX_H_
#include<string>
using namespace std;
class Vertex {
protected:
	int x,y;
public:
	Vertex();
	Vertex(int x, int y);
	void setx(int x);
	void sety(int y);
	int getx()const;
	int gety()const;
	virtual string getSpec();
	virtual ~Vertex();
};

#endif /* VERTEX_H_ */
