#include "TeamLeader.h"

TeamLeader::TeamLeader(string n, string a, int num,  Date d, int s,double hrate, double b): ProductionWorker(s, hrate, num,d, a, n){
	_bonus=b;
	_num_train_hours=10;
	_train_hours=8;

}
double TeamLeader::getBonus(){return _bonus;}
int TeamLeader::getNumTHours(){return _num_train_hours;}

int TeamLeader::getTHours(){return _train_hours;}
double TeamLeader::calculateSalary(Date d) {
	double sal;

	sal = d.getDay() * _payrate * 8;
	sal += _bonus;

	return sal;
}

TeamLeader::~TeamLeader(){}
