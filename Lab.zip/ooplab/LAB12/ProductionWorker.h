#include "Employee.h"
#ifndef PRODUCTIONWORKER_H_
#define PRODUCTIONWORKER_H_

class ProductionWorker : public Employee{
protected:
	int shift;
	double _payrate;

public:
	ProductionWorker(int s,double pay,int num,Date d,string n,string a);
	void setShift(int s);
	void setRate(int p);
	int getRate()const;
	int getShift()const;
	virtual ~ProductionWorker();
};

#endif /* PRODUCTIONWORKER_H_ */
