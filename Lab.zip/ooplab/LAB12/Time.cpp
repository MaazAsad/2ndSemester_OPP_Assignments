/*
 * Time.cpp
 *
 *  Created on: Apr 16, 2019
 *      Author: maaz
 */

#include "Time.h"

Time::Time(){
	hours = minutes = seconds = 0;
}
Time::Time(int h,int m, int sec):hours(h),minutes(m), seconds(sec){}
Time::Time(const Time &x){
	hours = x.gethours();
	minutes = x.getminutes();
	seconds = x.getseconds();
}
void Time::sethours(int h){hours = h;}
void Time::setminutes(int h){minutes = h;}
void Time::setseconds(int h){seconds = h;}
int Time::gethours()const{return hours;}
int Time::getminutes()const{return minutes;}
int Time::getseconds()const{return seconds;}
std::string Time::getTime(){
	std::string temp;
	temp+= std::to_string(hours);
	temp +=':';
	temp += std::to_string(minutes);
	temp +=':';
	temp += std::to_string(seconds);
	return temp;
}


