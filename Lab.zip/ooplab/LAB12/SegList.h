/*
 * SegList.h
 *
 *  Created on: Apr 17, 2019
 *      Author: maaz
 */

#ifndef SEGLIST_H_
#define SEGLIST_H_
#include"Vertex.h"
class SegList {
protected:
	Vertex arr[10];
	int idx;
public:
	SegList();
	void addVertex(Vertex x);
	virtual string getSpec();
	virtual ~SegList();
};

#endif /* SEGLIST_H_ */
