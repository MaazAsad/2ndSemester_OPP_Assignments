/*
 * Time.h
 *
 *  Created on: Apr 16, 2019
 *      Author: maaz
 */

#ifndef TIME_H_
#define TIME_H_
#include<string>
class Time {
protected:
	int hours, minutes,seconds;
public:
	Time();
	Time(int h,int m, int sec);
	Time(const Time &x);
	void sethours(int h);
	void setminutes(int h);
	void setseconds(int h);
	int gethours()const;
	int getminutes()const;
	int getseconds()const;
	std::string getTime();

};

#endif /* TIME_H_ */
