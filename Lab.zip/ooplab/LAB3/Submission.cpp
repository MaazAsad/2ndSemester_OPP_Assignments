void LabTask1(int *&p, int s,int seed) {

    p = new int(s);
	for(int i=0; i <s; i++){
		*(p+i) = 0;
	}
	for(int i=0; i<s; i++, seed++){
		*(p+i) = (seed*seed);
	}
}

int LabTask2(int* a[]) {

    int max;
	a = new int*[4];
	for(int i=0; i<4; i++){

		a[i] = new int;
	}


	for(int i=0; i<4; i++)
		a[i][i] = 0;

	for(int i = 0, x = 15; i <4; i++,x +=2 ){
		if(i%2 ==0)
			x += 5;
		a[i][i] = x;
	}
	max = a[0][0];

	for(int i=0; i<4; i++){
		if(a[i][i]>max)
			max = a[i][i];
	}

	return max;

}

void LabTask3(){

	int arr0[6] = { };
	int arr1[6] = { };
	int arr2[6] = { };
	int arr3[6] = { };
	int arr4[6] = { };

	int **p;
	p = new int*[5];
	p[0] = arr0;
	p[1] = arr1;
	p[2] = arr2;
	p[3] = arr3;
	p[4] = arr4;


	for(int i=0, random=5; i <5; i++, random++){
		for(int j=0; j<6; j++){
			if(i%2==0){
				random+=5;

			}
			*(*(p+i)+j) = random;
		}
	}
}

void LabTask3B(int ncols){
    int sum;
	int* arr0 = new int[ncols];
	int* arr1= new int[ncols];
	int* arr2= new int[ncols];
	int* arr3= new int[ncols];
	int* arr4= new int[ncols];

	int **p;
	p = new int*[5];
	p[0] = arr0;
	p[1] = arr1;
	p[2] = arr2;
	p[3] = arr3;
	p[4] = arr4;


	for(int i=0; i <5; i++){
		for(int j=0; j<ncols; j++){

			*(*(p+i)+j) = j;
		}
	}

	for(int i=0; i <5; i++){
		sum =0;
			for(int j=0; j<ncols; j++){

				sum += *(*(p+i)+j);
			}
		cout << sum<<endl;
		}

}

void LabTask3C(int ** &p, int nrows, int ncols){
    p = new int*[nrows];
		p[0] = new int[ncols];
		p[1] = new int[ncols];
		p[2] = new int[ncols];
		p[3] = new int[ncols];
		p[4] = new int[ncols];


		for(int i=0; i <nrows; i++){
			for(int j=0; j<ncols; j++){

				*(*(p+i)+j) = j;
			}
		}
}

void LabTask3D(int **p, int nrows, int ncols){
    for(int i=0; i<nrows; i++){
		delete []p[i];
	}
	delete p;
}

int ** LabTask3E(int nrows, int ncols){
    int **matrixA;
	int **matrixB;
	int **matrixC;

	matrixA = new int*[nrows];
	for(int i=0; i<nrows; i++){
		matrixA[i] = new int[ncols];
	}
	matrixB = new int*[nrows];
	for(int i=0; i<nrows; i++){
		matrixB[i] = new int[ncols];
	}
	matrixC = new int*[nrows];
	for(int i=0; i<nrows; i++){
		matrixC[i] = new int[ncols];
	}

	for(int i=0; i<nrows; i++){
		for(int j=0; j<ncols;j++){
				matrixA[i][j] = j;
				matrixB[i][j] = j;
				matrixC[i][j] = matrixA[i][j] + matrixB[i][j];
			}
		}

	for(int i=0; i<nrows; i++){
			delete []matrixA[i];
			delete []matrixB[i];
		}
		delete matrixA;
		delete matrixB;

	return matrixC;

}

int LabTask4(int **p, int sizeA, int sizeB){
    int sum =0;
for(int i=0; i<sizeA; i++){
    if(i== 0 || i == sizeA-1){
        for(int j =0; j< sizeB; j++){
            sum += p[i][j];
        }
    }
    else{
        sum += (p[i][0]+ p[i][sizeB-1]);
    }
}

return sum;
}

void LabTask5(int **&p, int csize, int nsize){
    int *np;

np = new int[nsize];
for(int i =0; i<csize; i++){
    np[i] = p[0][i];
}
for(int i=csize; i<nsize;i++){
    np[i] = 0;
}
delete []p[0];
p[0] = np;
}

void LabTask6(){
    int* arr;
	int* temparr;
	int tempvar, size=0;
	arr = new int[size];
	*arr=0;
	cout << "Enter Value: ";
	cin >> tempvar;
	while(tempvar != -1){
		size++;

		temparr = new int[size];
		for(int i=0; i<size-1; i++){
			temparr[i] = arr[i];
		}

		temparr[size-1] = tempvar;
		delete []arr;
		arr = new int[size];

		for(int i=0; i<size; i++){
			arr[i] = temparr[i];
		}
		delete []temparr;


		cout << "Enter Value: ";
		cin >> tempvar;
	}
	for(int i=0; i<size; i++){
		cout << arr[i] << endl;
	}
}

void LabTask7(int **p, int *odd){
    #include <stdlib.h>
	#include <time.h>
	srand(time(NULL));
	int nodd=0;
	p = new int*[3];
	for(int i=0; i<3; i++){
		p[i] = new int[5];
	}
	for(int i=0; i<3; i++){

		for(int j=0; j<5; j++){
				p[i][j] = rand()%10;
			}
		}
	for(int i=0; i<3; i++){

		for(int j=0; j<5; j++){
				cout << p[i][j] << " ";
				if(p[i][j] %2){
					nodd++;
				}
			}

	}


	odd = new int[nodd];
	for(int i=0,k=0; i<3; i++){

		for(int j=0; j<5; j++){
				if(p[i][j] %2){
					odd[k] = p[i][j];
					k++;
				}
			}

	}
}

int LabTask8(int***&p, int npages,  int rows, int cols){
    p = new int**[npages];
    for(int i=0; i<npages; i++){
        p[i] = new int*[rows];
        for(int j=0; j<rows; j++){
            p[i][j] = new int[cols];
        }
    }

    return 0;
}

int LabTask9(int***p, int npages,  int rows, int cols){
    for(int accessp=0 ; accessp< npages; accessp++){
    for(int accessr=0; accessr < rows; accessr ++){
        delete []p[accessp][accessr];
    }
    delete []p[accessp];
    }
    delete []p;
    return 0;
}

int ** LabTask10(int nrows, int ncols) {
    #include <stdlib.h>
    #include <time.h>
    srand(time(NULL));
    int ***matrix;
    //create matrices
    matrix = new int**[3];
    for(int i=0; i<3; i++){
        matrix[i] = new int*[nrows];
        for(int j=0; j<nrows; j++){
            matrix[i][j] = new int[ncols];
        }
    }

    //intit matrices
    for(int i=0; i<2; i++){
            for(int j=0; j<nrows; j++){
                for(int k=0; k< ncols; k++){
                    matrix[i][j][k] = (rand()%15)+1;
                }
            }
        }

    //taking sum
    for(int j=0; j<nrows; j++){
        for(int k=0; k< ncols; k++){
            matrix[2][j][k] = matrix[0][j][k]+matrix[1][j][k];
        }
    }


    return matrix[2];
}

int ** LabTask11(int nrows, int ncols) {
    #include <stdlib.h>
	#include <time.h>
	srand(time(NULL));
	int ***matrix;
	int sum;
	//create matrices
	matrix = new int**[3];
	for(int i=0; i<3; i++){
		matrix[i] = new int*[nrows];
		for(int j=0; j<nrows; j++){
			matrix[i][j] = new int[ncols];
		}
	}

	//intit matrices
	for(int i=0; i<2; i++){
			for(int j=0; j<nrows; j++){
				for(int k=0; k< ncols; k++){
					matrix[i][j][k] = (rand()%15)+1;
				}
			}
		}

    for(int i=0; i<nrows; i++){
        for(int j=0; j<ncols; j++){
            sum =0;
            for(int k=0; k<ncols; k++){

                sum += matrix[0][i][k] * matrix[1][k][j];

            }
            matrix[2][i][j] = sum;
        }
    }


	return matrix[2];
}
