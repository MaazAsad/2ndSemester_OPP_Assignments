/*
 * Date.cpp
 *
 *  Created on: Mar 12, 2019
 *      Author: maaz
 */

#include "Date.h"
#include<string>

Date::Date(int year, int month, int day) {
	this->year =year;
	this->month =month;
	this->day =day;

}

int Date::getDay()const{
	return day;
}
int Date::getMonth()const{return month;}
int Date::getYear()const{return year;}

bool Date::isLeapYear()const{
	if(year%4){
		return false;
	}
	return true;
}

std::string Date::toString(){
	char* a = new char[10];
	// int year[4],months[2],day[2];
	// int tempy = this->year,tempm=month,tempd=this->day;
	// int count_d =0, count_m=0;
	//
	// for(int i=0;tempy!=0; i++){
	// 	year[i] = tempy%10;
	// 	tempy/=10;
	// }
	// for(int i=0;tempm!=0; i++){
	// 		months[i] = tempm%10;
	// 		tempm/=10;
	// 		count_m++;
	// 	}
	// for(int i=0;tempd!=0; i++){
	// 		day[i] = tempd%10;
	// 		tempd/=10;
	// 		count_d++;
	// 	}
	//
	//init A
	for(int i=0; i<10;i++){
		a[i] = ' ';
	}
	int i=0;

	// for(int w=3; w>=0; w--){
	// 	a[i]= year[w]+48;
	// 	i++;
	// }
	// a[i]='/';
	// i++;
	//
	// if(count_m == 1){
	// 	a[i] = '0';
	// 	i++;
	// }
	// for(int j=count_m-1; j>=0; j++){
	// 	a[i] = months[j]+48;
	// 	i++;
	// }
	//
	// if(count_d== 1){
	// 		a[i] = '0';
	// 		i++;
	// 	}
	// 	for(int j=count_d-1; j>=0; j++){
	// 		a[i] = day[j]+48;
	// 		i++;
	// 	}
	// a[i]='\0';
	return a;
}
void Date::add(const int &days){
	// int nyear,nmonth,nday;
	// nyear = nmonth =0;
	// nday=days;
	//
	// //cout<<nday<<endl;
	// //this->day=nday;
	//
	// switch(month){
	// case 1:
	// case 3:
	// case 5:
	// case 7:
	// case 8:
	// case 10:
	// case 12:
	// 	if(this->day+nday>31){
	// 		nday-= (31-day);
	// 		this->day=1;
	// 		month +=1;
	// 	}
	// 	break;
	// case 2:
	// 	if(day+nday>28){
	// 		nday-= (28-day);
	// 		this->day=1;
	// 		month +=1;
	// 	}
	// 	break;
	// case 4:
	// case 6:
	// case 9:
	// case 11:
	// 	if(this->day+nday>30){
	// 		nday-= (30-day);
	// 		this->day=1;
	// 		month +=1;
	// 	}
	// 	break;
	// }
	// //
	// // if(month ==13){
	// // 	month=1;
	// // 	year +=1;
	// // }
	// //
	// //
	// // while(nday>31){
	// // 	switch(month){
	// //
	// // 	}
	// // }

}



void add(const int &months,const int &days){

}
void add(Date & date){

}
void subtract(const int &days){

}
void subtract(const int &months,const int &days){

}
void subtract(Date & date){

}
void addWeeks(const int &weeks){

}

int daysTo(const Date & other){
	int a;
	return a;
}
