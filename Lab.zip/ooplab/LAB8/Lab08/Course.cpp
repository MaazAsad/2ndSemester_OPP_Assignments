/*
 * Course.cpp
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#include "Course.h"

Course::Course(){

	CCode=CTitle="\0";
	CHours=0;RepeatCount=1;
	Section='\0';
}

Course::Course(std::string code, std::string title, char sec, int h){
	CCode = code;
	CTitle= title;
	Section = sec;;
	CHours = h;
}

void Course::setCode(std::string code){
	CCode = code;
}
void Course::setTitle(std::string title){
	CTitle= title;
}
void Course::setSection(char sec){
	Section = sec;;
}
void Course::setCHours(int h){
	CHours = h;
}
void Course::incrementRepCount(){
	RepeatCount++;
}
std::string Course::getCode(){return CCode;}
std::string Course::getTitle(){return CTitle;}
char Course::getSection(){return Section;}
int Course::getCHours(){return CHours;}
int Course::getRepCount(){return RepeatCount;}


