/*
 * Complex.cpp
 *
 *  Created on: Mar 12, 2019
 *      Author: maaz
 */

#include "Complex.h"

Complex::Complex(){
	real =0;
	imagin = 0;
}
Complex::Complex(double a, double b){
	real =a;
	imagin = b;
}

Complex::Complex(const Complex & copy){
	real = copy.getReal();
	imagin = copy.getImaginary();
}

void Complex::setReal(double a){
	real = a;
};
double Complex::getReal() const{return real;}
void Complex::setImaginary(double i){
	imagin = i;
}
double Complex::getImaginary() const{return imagin;}

Complex Complex::addComplex( double r){
	Complex temp(real+r,imagin);
	return temp;
}
Complex Complex::addComplex(const Complex &c1){
	Complex temp(real + c1.getReal(), imagin +c1.getImaginary());
	return temp;
}
Complex Complex::subComplex( double r){
	Complex temp(real-r,imagin);
	return temp;
}
Complex Complex::subComplex(const Complex &c1){
	Complex temp(real -c1.getReal(), imagin -c1.getImaginary());
	return temp;
}
Complex Complex::mulComplex( double r){
	Complex temp(real*r,imagin*r);
		return temp;
}
Complex Complex::mulComplex(const Complex &c1){
	Complex Temp(real*c1.getReal()-imagin*c1.getImaginary(), real*c1.getImaginary()+imagin*c1.getReal());
	return Temp;
}
