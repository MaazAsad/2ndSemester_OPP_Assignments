/*
 * Course.h
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#ifndef COURSE_H_
#define COURSE_H_
#include<string>
class Course {
	std::string CCode,CTitle;
	int CHours,RepeatCount=1;
	char Section;
public:
	Course();
	Course(std::string code, std::string title, char sec, int h);
	void setCode(std::string code);
	void setTitle(std::string title);
	void setSection(char sec);
	void setCHours(int h);
	void incrementRepCount();
	std::string getCode();
	std::string getTitle();
	char getSection();
	int getCHours();
	int getRepCount();

};

#endif /* COURSE_H_ */
