/*
 * Point.h
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#ifndef POINT_H_
#define POINT_H_
#include<iostream>
class Point {
	int x_cord,y_cord;
public:
	Point();
	Point(int x1, int y1);
	Point(const Point &copy);
	int getX() const;
	int getY() const;
	void setX(int x1);
	void setY(int y1);
	~Point();
};

#endif /* POINT_H_ */
