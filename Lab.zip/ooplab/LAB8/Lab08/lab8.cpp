#include"Complex.h"
#include"Date.h"
#include<iostream>
using namespace std;
int main(int argc, char **argv) {

	Date x(1,1,1);
	x.add(5);


	return 0;
}
