/*
 * Rectangle.h
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#ifndef RECTANGLE_H_
#define RECTANGLE_H_
#include "Point.h"
#include<iostream>
class Rectangle {
	Point start;
	int _height , _width;
public:
	Rectangle(int x, int y, int width, int height);
	Rectangle(Point p, int width, int height);
	Rectangle(const Rectangle &copy) ;
	void setHeight(int h);
	void setWidth(int w);
	void setX(int x);
	void setY(int x);
	int getHeight()const;
	int getWidth()const;
	int getX()const;
	int getY()const;
	std::string toString();
	bool contains(Point p);
	Rectangle Union(Rectangle & rect);
};

#endif /* RECTANGLE_H_ */
