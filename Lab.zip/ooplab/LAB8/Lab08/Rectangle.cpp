/*
 * Rectangle.cpp
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#include "Rectangle.h"
#include <string>
#include"Point.h"
Rectangle::Rectangle(int x, int y, int width, int height){
	start.setX(x);
	start.setY(y);
	_height = height;
	_width = width;
}
Rectangle::Rectangle(Point p, int width, int height){
	start.setX(p.getX());
	start.setY(p.getY());
	_height = height;
	_width = width;
}
Rectangle::Rectangle(const Rectangle &copy){
	start.setX(copy.getX());
	start.setY(copy.getY());
	_height = getHeight();
	_width = getWidth();
}

void Rectangle::setHeight(int h){_height = h;}
void Rectangle::setWidth(int w){_width = w;}
void Rectangle::setX(int x){start.setX(x);}
void Rectangle::setY(int x){start.setY(x);}


int Rectangle::getHeight()const{return _height;}
int Rectangle::getWidth()const{return _width;}
int Rectangle::getX()const{return start.getX();}
int Rectangle::getY()const{return start.getY();}
std::string Rectangle::toString(){
//Rectangle[x=1, y=2, width=3, height=4]
	std::string a="";
	a+= "Rectangle[x=";
	a+= (char)(start.getX()+48);
	a+= ", y=";
	a+= (char)(start.getY()+48);
	a+= ", width=";
	a+= (char)(_width+48);
	a+= ", height=";
	a+= (char)(_height+48);
	a+="]";

	return a;

}
bool Rectangle::contains(Point p){

	if( (p.getX()-start.getX() >=0 && p.getX()-start.getX() <=_width)
			&&
		(p.getY()-start.getY() >=0 && p.getY()-start.getY() <= _height) )
		return true;

	return false;
}
Rectangle Rectangle::Union(Rectangle & rect){
	Rectangle a(0,0,0,0);

	if(( start.getX() == rect.getX() || start.getY() == rect.getY() )
			&&
	   (this->_height == rect.getHeight() || this->_width == rect.getWidth())  ){


		//first test same y and heights
		if(start.getY() == rect.getY() && this->_height == rect.getHeight()){





		}


	}


	return a;
}
