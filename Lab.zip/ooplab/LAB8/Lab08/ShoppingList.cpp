/*
 * ShoppingList.cpp
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#include "ShoppingList.h"
#include<iostream>
ShoppingList::ShoppingList() {
	nItems =0;
	for(int i=0;i<5;i++){
		items[i].setName(" ");
		items[i].setPrice(0);
		items[i].setQuant(0);
	}
}
bool ShoppingList::AddItem(std::string name, long price, int quantity){
	if(nItems<10){
		items[nItems].setName(name);
		items[nItems].setPrice(price);
		items[nItems].setQuant(quantity);
		nItems++;
		return true;
	}
	return false;
}

void ShoppingList::Print(){
	std::cout << "Name     "<< "Price       " << "Quantity   " << " Total Price" << std::endl;
	for(int i=0; i<nItems; i++){
		items[i].Display();
	}
}

void ShoppingList::TotalCost(){
		long total = 0;
		for(int i=0; i<nItems; i++){
			total += items[i].getTotalPrice();
		}
		std::cout << total <<std::endl;
	}

