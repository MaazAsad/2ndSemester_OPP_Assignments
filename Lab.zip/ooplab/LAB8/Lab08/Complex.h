/*
 * Complex.h
 *
 *  Created on: Mar 12, 2019
 *      Author: maaz
 */

#ifndef COMPLEX_H_
#define COMPLEX_H_

class Complex {
	double real,imagin;
public:
	Complex();
	Complex(double a, double b);
	Complex(const Complex & copy);
	void setReal(double);
	double getReal() const;
	void setImaginary(double);
	double getImaginary() const;
	Complex addComplex( double r);
	Complex addComplex(const Complex &c1);
	Complex subComplex( double r);
	Complex subComplex(const Complex &c1);
	Complex mulComplex( double r);
	Complex mulComplex(const Complex &c1);
};

#endif /* COMPLEX_H_ */
