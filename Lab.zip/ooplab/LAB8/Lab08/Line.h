/*
 * Line.h
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#ifndef LINE_H_
#define LINE_H_
#include"Point.h"
#include<string>
class Line {
	Point _X,_Y;
public:
	Line(const Point &x, const Point &y);
	Line(int x1, int y1, int x2, int y2);
	Line(const Line &copy);
	Point getP1() const;
	Point getP2() const;
	std::string toString();
	double getSlope();
};

#endif /* LINE_H_ */
