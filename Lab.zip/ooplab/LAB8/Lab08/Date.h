/*
 * Date.h
 *
 *  Created on: Mar 12, 2019
 *      Author: maaz
 */

#ifndef DATE_H_
#define DATE_H_
#include<string>

class Date {
	int year,month,day;
public:
	Date(int year, int month, int day);
	int getDay()const;
	int getMonth()const;
	int getYear()const;
	bool isLeapYear()const;
	std::string toString();
	void add(const int &days);
	void add(const int &months,const int &days);
	void add(Date & date);
	void subtract(const int &days);
	void subtract(const int &months,const int &days);
	void subtract(Date & date);
	void addWeeks(const int &weeks);
	int daysTo(const Date & other);

};

#endif /* DATE_H_ */
