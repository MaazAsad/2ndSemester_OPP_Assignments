/*
 * Holiday.h
 *
 *  Created on: Mar 12, 2019
 *      Author: maaz
 */

#ifndef HOLIDAY_H_
#define HOLIDAY_H_
#include<string>
class Holiday {
	std::string name,month;
	int day;
public:

	Holiday();
	Holiday(const std::string &n, int d, const std::string &m);
	bool setName(const std::string &s);
	std::string getName() const;
	bool setDay(int u);
	int getDay() const;
	bool setMonth(const std::string &p);
	std::string getMonth() const;
};

#endif /* HOLIDAY_H_ */
