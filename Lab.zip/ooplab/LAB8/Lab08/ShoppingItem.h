/*
 * ShoppingItem.h
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#ifndef SHOPPINGITEM_H_
#define SHOPPINGITEM_H_
#include<string>
class ShoppingItem {
	std::string Name;
	long bPrice;
	int quantity;
public:
	ShoppingItem(std::string n, long price, int quant);

	void setName(std::string n);
	void setPrice(long x);
	void setQuant(int n);
	std::string getName();
	long getPrice();
	long getTotalPrice();
	int getQuant();
	void Display();

};

#endif /* SHOPPINGITEM_H_ */
