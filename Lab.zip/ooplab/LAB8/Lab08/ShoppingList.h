/*
 * ShoppingList.h
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#ifndef SHOPPINGLIST_H_
#define SHOPPINGLIST_H_
#include"ShoppingItem.h"
#include<iostream>
#include<string>

class ShoppingList {
	int nItems;
	ShoppingItem items[5];
public:
	ShoppingList();
	bool AddItem(std::string name, long price, int quantity);
	void Print();
	void TotalCost();

};

#endif /* SHOPPINGLIST_H_ */
