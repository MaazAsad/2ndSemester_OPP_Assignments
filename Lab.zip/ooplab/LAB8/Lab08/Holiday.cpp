/*
 * Holiday.cpp
 *
 *  Created on: Mar 12, 2019
 *      Author: maaz
 */
#include<string>
#include "Holiday.h"

Holiday::Holiday() {
	name = month = "\0";
	day =0;
}

Holiday::Holiday(const std::string &n, int d, const std::string &m){
	name =n;
	day = d;
	month =m;
}

bool Holiday::setName(const std::string &s){
	int i=0;
	for(;s[i]!='\0';i++);
	if(i<50){
		name =s;
		return true;
	}
	return false;
}

std::string Holiday::getName() const{return name;}

bool Holiday::setDay(int u){
	if(u>0 && u<31){
		day = u;
		return true;
	}
	return false;

}
int Holiday::getDay() const{return day;};
bool Holiday::setMonth(const std::string &p){
	int i=0;
	for(;p[i]!='\0';i++);
	if(i<10){
		month =p;
		return true;
	}
	return false;

}
std::string Holiday::getMonth() const{return month;}

bool inSameMonth (const Holiday &a, const Holiday &b){
	if(a.getMonth() == b.getMonth()){
		return true;
	}
	return false;
}
double avgDate(Holiday arr[], int size){
	double temp=0;
	for(int i=0; i < size;i++){
		temp+=arr[i].getDay();
	}

	return temp/size;
}

