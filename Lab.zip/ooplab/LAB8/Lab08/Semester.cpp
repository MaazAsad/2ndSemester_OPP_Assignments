/*
 * Semester.cpp
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#include "Semester.h"

SemesterRegistration::SemesterRegistration() {
	semesterCode="\0";
	coursecount=0;
	courses = new Course[5];

}
SemesterRegistration::SemesterRegistration(SemesterRegistration &s){
	semesterCode = s.getsemestercode();
	coursecount = s.getCourseCount();
	courses = s.getCourses();

}

SemesterRegistration::SemesterRegistration(std::string sc,int c, Course *courseArr){
	semesterCode =sc;
	coursecount = c;
	courses = courseArr;
}

std::string SemesterRegistration::getsemestercode(){
	return semesterCode;
}
int SemesterRegistration::getCourseCount(){
	return coursecount;
}
Course *SemesterRegistration::getCourses(){
	return courses;
}


int SemesterRegistrationGetCreditHoursCount(SemesterRegistration sr){
	return sr.getCourseCount();
}
bool SemesterRegistrationFindCourseInSemesterRegistration(SemesterRegistration sr,std::string Coursecode ){
	if(sr.getsemestercode() == Coursecode)
		return true;
	return false;
}

















