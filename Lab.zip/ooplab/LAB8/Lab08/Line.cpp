/*
 * Line.cpp
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#include "Line.h"
#include"Point.h"
#include<string>

Line::Line(const Point &x, const Point &y){
	_X.setX(x.getX());
	_X.setY(x.getY());
	_Y.setX(y.getX());
	_Y.setY(y.getY());
}
Line::Line(int x1, int y1, int x2, int y2){
	_X.setX(x1);
	_X.setY(y1);
	_Y.setX(x2);
	_Y.setY(y2);
}
Line::Line(const Line &copy){
	_X.setX(copy.getP1().getX());
	_X.setY(copy.getP1().getY());
	_Y.setX(copy.getP2().getX());
	_Y.setY(copy.getP2().getX());
}
Point Line::getP1() const{
	return _X;
}
Point Line::getP2() const{
	return _Y;
}
std::string Line::toString(){
	//"[(22, 3), (4,7)]"
	std::string a="";
	a+="[(";
	a+= (char)(_X.getX()+48);
	a+= ", ";
	a+= (char)(_X.getY()+48);
	a+="), (";
	a+= (char)(_Y.getX()+48);
	a+= ", ";
	a+= (char)(_Y.getY()+48);
	a+= ")]";
	return a;

}
double Line::getSlope(){
	return ( (_Y.getY() - _X.getY())/(_Y.getX()-_X.getX()) );
}
