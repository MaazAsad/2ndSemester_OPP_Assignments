/*
 * Semester.h
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#ifndef SEMESTER_H_
#define SEMESTER_H_
#include<string>
#include"Course.h"

class SemesterRegistration {
	std::string semesterCode;
	Course *courses;
	int coursecount;
public:
	SemesterRegistration();
	SemesterRegistration(SemesterRegistration & s);
	SemesterRegistration(std::string sc,int c, Course *courseArr);
	std::string getsemestercode();
	int getCourseCount();
	Course* getCourses();
};

#endif /* SEMESTER_H_ */
