/*
 * Point.cpp
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#include "Point.h"
#include<iostream>
Point::Point() {
	x_cord = y_cord = 0;
}
Point::Point(int x1, int y1){
	x_cord = x1;
	y_cord = y1;
}

Point::Point(const Point &copy){
	x_cord = copy.getX();
	y_cord = copy.getY();
}
int Point::getX() const{
	return x_cord;
}
int Point::getY() const{
	return y_cord;
}
void Point::setX(int x1){
	x_cord = x1;
}
void Point::setY(int y1){
	y_cord = y1;
}

Point::~Point() {
	std::cout << "deConstructor called";

}

