/*
 * ShoppingItem.cpp
 *
 *  Created on: Mar 13, 2019
 *      Author: maaz
 */

#include "ShoppingItem.h"
#include<string>
#include<iostream>
ShoppingItem::ShoppingItem(std::string n, long price, int quant) {
	Name = n;
	bPrice = price;
	quantity = quant;

}


void ShoppingItem::Display(){
	std::cout << Name << ' ' << bPrice << ' ' << quantity << ' ' << totalPrice << std::endl;
}

void ShoppingItem::setName(std::string n){Name=n;}
void ShoppingItem::setPrice(long x){bPrice=x;}
void ShoppingItem::setQuant(int n){quantity=n;}

std::string ShoppingItem::getName(){return Name;}
long ShoppingItem::getPrice(){return bPrice;}
long ShoppingItem::getTotalPrice(){return bPrice * quantity;}
int ShoppingItem::getQuant(){return quantity;}
