/*
 * Garage.cpp
 *
 *  Created on: Apr 9, 2019
 *      Author: lab
 */

#include "Garage.h"

	Garage::Garage():name("\0"),index(0),capacity(10),CarList(new Car[capacity])
	{
	}
	Garage::Garage(string n, int i, int c):name(n),index(i),capacity(c),CarList(new Car[capacity])
	{
	}
	bool Garage::IsEmpty()
	{
		if(index == 0)
			return true;
		return false;
	}
	bool Garage::IsFull()
	{
		if(index == capacity)
			return true;
		return false;
	}
	bool Garage::Push(Car c)
	{
		bool a = IsFull();
		if(a == 0)
		{
			CarList[index].setCarModel(c.getCarModel());
			CarList[index].setMake(c.getMake());
			CarList[index].setRegNo(c.getRegNo());
			CarList[index].setYear(c.getYear());
			index++;
			return true;
		}
		return false;
	}
	bool Garage::Find(string reg)
	{
		for(int i = 0; i < index; i++)
		{
			if(CarList[i].getRegNo() == reg)
				return true;
		}
		return false;
	}
	bool Garage::Remove(string reg)
	{
		for(int i = 0; i < index; i++)
		{
			if(CarList[i].getRegNo() == reg)
			{
				for(int j = i; i < index-1; i++)
				{
					CarList[j].setCarModel(CarList[j+1].getCarModel());
					CarList[j].setMake(CarList[j+1].getMake());
					CarList[j].setRegNo(CarList[j+1].getRegNo());
					CarList[j].setYear(CarList[j+1].getYear());
				}
				index--;
				return true;
			}
		}
		return false;
	}
	void Garage::Display()
	{
		for(int i = 0; i < index; i++)
		{
			cout<<"Car Number "<<i+1<<": "<<endl;
			cout<<CarList[i].getCarModel()<<endl;
			cout<<CarList[i].getMake()<<endl;
			cout<<CarList[i].getRegNo()<<endl;
			cout<<CarList[i].getYear()<<endl<<endl;
		}
	}
	//garage::virtual ~Garage();
