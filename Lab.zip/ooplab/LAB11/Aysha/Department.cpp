/*
 * Department.cpp
 *
 *  Created on: Apr 9, 2019
 *      Author: lab
 */

#include "Department.h"


	Department::Department():name(""),noOfProfessors(100),profList(new Professor[noOfProfessors]),deptID(0)
	{
	}
	Department::Department(string n, int num, int id):name(n),noOfProfessors(num),profList(new Professor[noOfProfessors]),deptID(id)
	{
	}
	void Department::setDeptID(int i)
	{
		deptID = i;
	}
	int Department::getDeptID() const
	{
		return deptID;
	}
	void Department::setName(string n)
	{
		name = n;
	}
	string Department::getName() const
	{
		return name;
	}
	void Department::setnoOfProfressors(int n)
	{
		noOfProfessors = n;
	}
	int Department::getnoOfProfessors() const
	{
		return noOfProfessors;
	}
	bool Department::addProfessor(Professor p)
	{
		// Professor *copy = new Professor [100];
		// for(int i = 0; i < noOfProfessors; i++)
		// {
		// 	copy[i].setName(profList[i].getName());
		// 	copy[i].setEmployeeID(profList[i].getEmployeeID());
		// 	copy[i].setDesignation(profList[i].getDesignation());
		// }
		// delete []profList;
		// profList = new Professor [noOfProfessors+1];
		// for(int i = 0; i < noOfProfessors; i++)
		// {
		// 	profList[i].setName(copy[i].getName());
		// 	profList[i].setEmployeeID(copy[i].getEmployeeID());
		// 	profList[i].setDesignation(copy[i].getDesignation());
		// }
		// profList[noOfProfessors].setName(p.getName());
		// profList[noOfProfessors].setEmployeeID(p.getEmployeeID());
		// profList[noOfProfessors].setDesignation(p.getDesignation());
		// noOfProfessors++;
		return true;
	}
	bool Department::deleteProfessor (int id)
	{
		for(int i = 0; i < noOfProfessors; i++)
		{
			if(profList[i].getEmployeeID() == id)
			{
				for(int j = i; j < noOfProfessors-1; j++)
				{
					profList[j].setName(profList[j+1].getName());
					profList[j].setEmployeeID(profList[j+1].getEmployeeID());
					profList[j].setDesignation(profList[j+1].getDesignation());
				}
				noOfProfessors--;
				return true;
			}
		}
		return false;
	}
	bool Department::updateProfessor (int id, string s)
	{
		for(int i = 0; i < noOfProfessors; i++)
		{
			if(profList[i].getEmployeeID() == id)
			{
				profList[i].setDesignation(s);
				return true;
			}
		}
		return false;
	}
	void Department::display()
	{
		for(int i = 0; i < noOfProfessors; i++)
		{
			cout<<"Professor number "<<i+1<<": "<<endl;
			cout<<profList[i].getName()<<endl;
			cout<<profList[i].getEmployeeID()<<endl;
			cout<<profList[i].getDesignation()<<endl<<endl;
		}
	}
	/*Department::~Department()
	{
		delete []profList;
	}*/
