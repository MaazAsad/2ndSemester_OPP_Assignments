/*
 * Garage.h
 *
 *  Created on: Apr 9, 2019
 *      Author: lab
 */

#ifndef GARAGE_H_
#define GARAGE_H_

#include"Car.h"
#include<iostream>
#include<string>
using namespace std;

class Garage
{
private:
	string name;
	int index;
	int capacity;
	Car *CarList;
public:
	Garage();
	Garage(string, int, int);
	bool IsEmpty();
	bool IsFull();
	bool Push(Car c);
	bool Find(string reg);
	bool Remove(string reg);
	void Display();
	//virtual ~Garage();
};

#endif /* GARAGE_H_ */
