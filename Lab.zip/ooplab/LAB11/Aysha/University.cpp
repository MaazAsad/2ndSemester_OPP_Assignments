/*
 * University.cpp
 *
 *  Created on: Apr 9, 2019
 *      Author: sameet_asadullah
 */

#include "University.h"

University::University(string n, int num) :
		name(n), numberOfDepartments(num), dept(new Department[num]) {
}

void University::setName(string n) {
	if (n != "\0") {
		name = n;
	}
}

string University::getName() const {
	return name;
}

void University::setnumberOfDepartments(int n) {
	if (n > 0) {
		numberOfDepartments = n;
	}
}

int University::getnumberOfDepartments() const {
	return numberOfDepartments;
}

void University::setDept(const Department &d) {
	for (int i = 0; i < numberOfDepartments; i++) {
		if (dept[i].getDeptID() == 0) {
			dept[i].setName(d.getName());
			dept[i].setDeptID(d.getDeptID());
			dept[i].setnoOfProfressors(d.getnoOfProfessors());
		}
	}
}

Department University::getDept() const {
	return dept[0];
}

bool University::addDepartment(Department d) {
	for (int i = 0; i < numberOfDepartments; i++) {
		if (dept[i].getDeptID() == 0) {
			dept[i].setName(d.getName());
			dept[i].setDeptID(d.getDeptID());
			dept[i].setnoOfProfressors(d.getnoOfProfessors());
			return true;
		}
	}
	return false;
}

bool University::deleteDepartment(string n) {
	for (int i = 0; i < numberOfDepartments; i++) {
		if (dept[i].getName() == n) {
			dept[i].setName("\0");
			dept[i].setDeptID(0);
			dept[i].setnoOfProfressors(0);
			return true;
		}
	}
	return false;
}

bool University::updateDepartment(int id, string n) {
	for (int i = 0; i < numberOfDepartments; i++) {
		if (dept[i].getDeptID() == id) {
			dept[i].setName(n);
			return true;
		}
	}
	return false;
}

void University::display() {
	int j = 1;
	for (int i = 0; i < numberOfDepartments; i++) {
		cout << endl << "University " << j << ":" << endl << "Name: "
				<< dept[i].getName() << endl << "Number of Departments: "
				<< dept[i].getnoOfProfessors() << endl;
		j++;

	}
}

/*University::~University() {
}*/


