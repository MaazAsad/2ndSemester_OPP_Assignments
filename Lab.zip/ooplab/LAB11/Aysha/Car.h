/*
 * Car.h
 *
 *  Created on: Apr 9, 2019
 *      Author: lab
 */

#ifndef CAR_H_
#define CAR_H_

#include<string>
using namespace std;

class Car
{
private:
	string make;
	string carModel;
	string regNo;
	int year;

public:
	Car();
	Car(string m, string c, string r, int y);
	string getCarModel() const;
	void setCarModel(string carModel);
	string getMake() const;
	void setMake(string make);
	string getRegNo() const;
	void setRegNo(string regNo);
	int getYear() const;
	void setYear(int year);
};


#endif /* CAR_H_ */
