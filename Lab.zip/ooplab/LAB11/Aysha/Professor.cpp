/*
 * Professor.cpp
 *
 *  Created on: Apr 9, 2019
 *      Author: lab
 */

#include "Professor.h"

	Professor::Professor():name(""),Designation(""),employeeID(0)
	{
	}
	Professor::Professor(string n, int id, string d):name(n),Designation(d),employeeID(id)
	{
	}
	void Professor::setName(string n)
	{
		name = n;
	}
	string Professor::getName() const
	{
		return name;
	}
	void Professor::setEmployeeID(int id)
	{
		employeeID = id;
	}
	int Professor::getEmployeeID() const
	{
		return employeeID;
	}
	void Professor::setDesignation(string d)
	{
		Designation = d;
	}
	string Professor::getDesignation() const
	{
		return Designation;
	}

