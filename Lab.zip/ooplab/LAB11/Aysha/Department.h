/*
 * Department.h
 *
 *  Created on: Apr 9, 2019
 *      Author: lab
 */

#ifndef DEPARTMENT_H_
#define DEPARTMENT_H_

#include"Professor.h"
#include<iostream>
using namespace std;

class Department
{
	string name;
	Professor* profList;
	int noOfProfessors;
	int deptID;
public:
	Department();
	Department(string, int, int);
	void setDeptID(int i);
	int getDeptID() const;
	void setName(string n);
	string getName() const;
	void setnoOfProfressors(int n);
	int getnoOfProfessors() const;
	bool addProfessor(Professor p);
	bool deleteProfessor (int id);
	bool updateProfessor (int , string );
	void display();
	//~Department();
};

#endif /* DEPARTMENT_H_ */
