/*
 * University.cpp
 *
 *  Created on: Apr 9, 2019
 *      Author: maaz
 */

#include "University.h"
#include "Professor.h"
#include<iostream>
using namespace std;
University::University(string n, int num):name(n),numberOfDepartments(num),index(0){
	dept = new Department[num];

}
void University::setName(string n){name =n;}
string University::getName() const{return name;}
void University::setnumberOfDepartments(int n){
	numberOfDepartments = n;
}
int University::getnumberOfDepartments() const{return numberOfDepartments;}
void University::setDept(const Department &d ){

}
//Department University::getDept() const;
bool University::addDepartment(Department x){
	bool flag= false;
	if(index < numberOfDepartments-1){
		dept[index].setDeptID(x.getDeptID());
		dept[index].setName(x.getName());
		dept[index].setnoOfProfressors(x.getnoOfProfessors());
		flag = true;
		++index;

	}

	else{
		Department* temp = new Department[numberOfDepartments+1];

		for(int i=0; i<numberOfDepartments; ++i){

			temp[i].setDeptID(dept[i].getDeptID());
			temp[i].setName(dept[i].getName());
			temp[i].setnoOfProfressors(dept[i].getnoOfProfessors());
		}

		temp[numberOfDepartments].setDeptID(x.getDeptID());
		temp[numberOfDepartments].setName(x.getName());
		temp[numberOfDepartments].setnoOfProfressors(x.getnoOfProfessors());

		++numberOfDepartments;
		++index;
		delete []dept;
		dept = new Department[numberOfDepartments];

		for(int  i=0; i<numberOfDepartments; ++i){
			dept[i].setDeptID(temp[i].getDeptID());
			dept[i].setName(temp[i].getName());
			dept[i].setnoOfProfressors(temp[i].getnoOfProfessors());
		}
	}
	// delete []temp;
	return true;
}
bool University::deleteDepartment(string name){

	for(int i=0; i<=index; ++i){
		if(name == dept[i].getName()){
			for(int j=i; j<index;j++){
				dept[j].setName(dept[j+1].getName());
				// dept[j].setnoOfProfressors(dept[j+1].getnoOfProfessors());
				dept[j].setDeptID(dept[j+1].getDeptID());
			}
			--index;
			return true;
		}
	}
	return false;

}
bool University::updateDepartment(int id, string name){
	for(int i=0; i<numberOfDepartments; ++i){
			if(id == dept[i].getDeptID()){
				dept[i].setName(name);
				return true;
			}

		}
		return false;
}
bool University::addProfessor(){
	int id;
	string name,design,dep;
	cout << "Enter Name of Professor: ";
	getline(cin,name);
	cout << "Enter Desingnation: ";
	getline(cin,design);
	cout << "Enter ID: ";
	cin >> id;
	Professor prof(name,id,design);
	cout << "Enter Department: ";
	getline(cin,dep);
	for(int i=0; i<=index; ++i){
		if(dep == dept[i].getName()){
			dept[i].addProfessor(prof);
			return true;
		}
	}
	return false;
}
bool University::deleteProfessor(){
	int id;
	bool x=false;
	cout << "Enter Professor's ID:";
	cin >> id;
	for(int i=0; i<=index;i++){
		x= dept[i].deleteProfessor(id);
		if(x)
			break;
	}
	return x;
}
bool University::updateProfessor(int id,string desig){
	bool x=false;
	for(int i=0; i<numberOfDepartments;++i){
		x = dept[i].updateProfessor(id, desig);
		if(x)
			return x;
	}
	return x;
}
void University::display(){
	cout << name << endl << numberOfDepartments << endl;
	for(int i=0; i<=index; i++){
		dept[i].display();
		cout << endl;
	}
}
