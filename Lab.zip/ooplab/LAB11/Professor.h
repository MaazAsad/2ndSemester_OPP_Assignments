/*
 * Professor.h
 *
 *  Created on: Apr 9, 2019
 *      Author: maaz
 */

#ifndef PROFESSOR_H_
#define PROFESSOR_H_
#include<string>
using namespace std;

class Professor {
	string name;
	int employeeID;
	string Designation;
public:
	Professor();
	Professor(string, int, string);
	void setName(string n);
	string getName() const;
	void setEmployeeID(int id);
	int getEmployeeID() const;
	void setDesignation(string d);
	string getDesignation() const;

	bool updateProfessor ();
};

#endif /* PROFESSOR_H_ */
