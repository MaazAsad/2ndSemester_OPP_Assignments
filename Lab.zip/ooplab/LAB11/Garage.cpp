/*
 * Garage.cpp
 *
 *  Created on: Apr 9, 2019
 *      Author: maaz
 */

#include "Garage.h"
#include<iostream>
using namespace std;
Garage::Garage():name(""),index(0),capacity(0){
	CarList = new Car;

}

Garage::Garage(string name, int i, int c):name(name),index(i),capacity(c){
	CarList = new Car[capacity];
}
bool Garage::IsEmpty(){
	if(!index)
		return true;
	return false;
}
bool Garage::IsFull(){
	if(index == capacity-1)
		return true;
	return false;
}
bool Garage::Push(Car c){
	if(index<capacity-1){

		CarList[index].setCarModel(c.getCarModel());
		CarList[index].setMake(c.getMake());
		CarList[index].setRegNo(c.getRegNo());
		CarList[index].setYear(c.getYear());
		++index;
		return true;
	}
	return false;
}
bool Garage::Find(string reg){
	for(int i=0;i<=index;++i){
		if(CarList[i].getRegNo() == reg)
			return true;
	}
	return false;
}
bool Garage::Remove(string reg){
	for(int i=0;i<=index;++i){
		if(CarList[i].getRegNo() == reg){
			for(int j=i; j<index;++j){
				CarList[j].setCarModel(CarList[j+1].getCarModel());
				CarList[j].setMake(CarList[j+1].getMake());
				CarList[j].setRegNo(CarList[j+1].getRegNo());
				CarList[j].setYear(CarList[j+1].getYear());
			}

			return true;
		}

	}
	return false;
}
void Garage::Display(){

	for(int i =0;i<=index; ++i){
		cout << CarList[i].getCarModel() << endl
			 << CarList[i].getCarModel() << endl
			 << CarList[i].getCarModel() << endl
			 << CarList[i].getCarModel() <<endl;
	}
}


Garage::~Garage() {
	delete []CarList;
}
