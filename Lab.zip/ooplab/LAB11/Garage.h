/*
 * Garage.h
 *
 *  Created on: Apr 9, 2019
 *      Author: maaz
 */

#ifndef GARAGE_H_
#define GARAGE_H_
#include <string>
#include "Car.h"

class Garage {
private:
	string name;
	int index;
	int capacity;
	Car *CarList;
public:
	Garage();
	Garage(string, int, int);
	bool IsEmpty();
	bool IsFull();
	bool Push(Car c);
	bool Find(string reg);
	bool Remove(string reg);
	void Display();
	virtual ~Garage();
};

#endif /* GARAGE_H_ */
