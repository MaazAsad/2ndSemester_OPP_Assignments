/*
 * Point.cpp
 *
 *  Created on: Apr 9, 2019
 *      Author: maaz
 */

#include "Point.h"
Point::Point():X_Coor(0),Y_Coor(0){}
Point::Point(int x, int y):X_Coor(x),Y_Coor(y){}
Point::Point(const Point &p):X_Coor(p.X_Coor),Y_Coor(p.Y_Coor){}
int Point::getX_Coordinate() const{return X_Coor;}
int Point::getY_Coordinate() const{return Y_Coor;}
void Point::setX_Coordinate(int x){X_Coor = x;}
void Point::setY_Coordinate(int y){Y_Coor = y;}
