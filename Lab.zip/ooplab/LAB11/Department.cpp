/*
 * Department.cpp
 *
 *  Created on: Apr 9, 2019
 *      Author: maaz
 */

#include "Department.h"
#include<iostream>
using namespace std;
Department::Department():name(""),noOfProfessors(0),deptID(0),index(0){
	profList = new Professor[noOfProfessors];
}
Department::Department(string name, int npro, int id):name(name), noOfProfessors(npro), deptID(id),index(0){
	profList = new Professor[noOfProfessors];
}
void Department::setDeptID(int i){deptID =i;}
int Department::getDeptID() const{return deptID;}
void Department::setName(string n){name = n;}
string Department::getName() const{return name;}
void Department::setnoOfProfressors(int n){
	noOfProfessors = n;
	if(profList){
		delete []profList;
	}
	profList = new Professor[n];
}
int Department::getnoOfProfessors() const{return noOfProfessors;}

bool Department::addProfessor(Professor p){
	bool x=false;
	if(index < noOfProfessors-1){
		profList[index].setEmployeeID(p.getEmployeeID());
		profList[index].setDesignation(p.getDesignation());
		profList[index].setName(p.getName());
		++index;
		x= true;
	}
	if(!x){
		Professor* temp = new Professor[noOfProfessors+1];
		for(int i=0; i<noOfProfessors;++i){
			temp[i].setDesignation(profList[i].getDesignation());
			temp[i].setEmployeeID(profList[i].getEmployeeID());
			temp[i].setName(profList[i].getName());
		}

		temp[noOfProfessors].setDesignation(p.getDesignation());
		temp[noOfProfessors].setEmployeeID(p.getEmployeeID());
		temp[noOfProfessors].setName(p.getName());

		delete []profList;
		profList = new Professor[noOfProfessors+1];

		for(int i=0; i<noOfProfessors+1;++i){
			profList[i].setDesignation(temp[i].getDesignation());
			profList[i].setEmployeeID(temp[i].getEmployeeID());
			profList[i].setName(temp[i].getName());
		}
		noOfProfessors++;
		delete []temp;
	}
	return true;
}
bool Department::deleteProfessor (int id){
	for(int i=0; i<noOfProfessors; i++){
		if(profList[i].getEmployeeID() == id){
			for(int j=i; j<noOfProfessors-1 ;j++){
				profList[j].setName(profList[j+1].getName());
				profList[j].setEmployeeID(profList[j+1].getEmployeeID());
				profList[j].setDesignation(profList[j+1].getDesignation());
			}
			// --noOfProfessors;
			--index;
			return true;
		}
	}
	return false;
}
bool Department::updateProfessor (int id, string dep){
	for(int i=0; i<noOfProfessors; i++){
		if(id == profList[i].getEmployeeID()){
			profList[i].setDesignation(dep);
			return true;
		}
	}
	return false;

}
void Department::display(){
	cout << "Depratment :" << name<<endl
		 << "Department ID: "<< deptID<<endl
		 << "Number of Professors: " << noOfProfessors<<endl
		 << "List of Professors: "<<endl;
	for(int i =0; i<noOfProfessors; ++i){
		cout << profList[i].getEmployeeID() << endl
			 << profList[i].getName()<<endl
			 << profList[i].getDesignation()<<endl<<endl;
	}
}

Department::~Department() {
	delete []profList;
}
