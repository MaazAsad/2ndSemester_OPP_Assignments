/*
 * Line.cpp
 *
 *  Created on: Apr 9, 2019
 *      Author: maaz
 */

#include "Line.h"
#include <cmath>
#include<iostream>
using namespace std;
Line::Line():p1(4,6),p2(2,4){}
Line::Line(int x1, int y1, int x2, int y2):p1(x1,y1),p2(x2,y2){}
Line::Line(const Point &p1, const Point &p2):p1(p1),p2(p2){}
float Line::findLength(){
	float a,b,len;
	a = p2.getX_Coordinate()- p1.getX_Coordinate();
	a*=a;

	b = p2.getY_Coordinate() - p1.getY_Coordinate();
	b*=b;

	len = sqrt(a+b);
	return len;
}
float Line::findSlope(){
	float slope;
	slope = ( (float)p2.getY_Coordinate()-p1.getY_Coordinate())/(p2.getX_Coordinate()- p1.getX_Coordinate());
	return slope;
}
Point& Line::findMidPoint(){
	int a,b;
	a = p1.getX_Coordinate() + p2.getX_Coordinate();
	a/=2;
	b= p1.getY_Coordinate() + p2.getY_Coordinate();
	b/=2;
	//cout << a << endl << b << endl;
	Point *mid_point;
	mid_point = new Point(a,b);
	// mid_point->setX_Coordinate(a);
	// mid_point->setY_Coordinate(b);

	return *mid_point;
}
