/*
 * Department.h
 *
 *  Created on: Apr 9, 2019
 *      Author: maaz
 */

#ifndef DEPARTMENT_H_
#define DEPARTMENT_H_
#include <string>
#include "Professor.h"
using namespace std;
class Department {
	string name;
	Professor* profList;
	int noOfProfessors;
	int deptID;
	int index;
public:
	Department();
	Department(string, int, int);
	void setDeptID(int );
	int getDeptID() const;
	void setName(string n);
	string getName() const;
	void setnoOfProfressors(int n);
	int getnoOfProfessors() const;
	bool addProfessor(Professor p);
	bool deleteProfessor (int id);
	bool updateProfessor (int , string );
	void display();
	~Department();

};

#endif /* DEPARTMENT_H_ */
