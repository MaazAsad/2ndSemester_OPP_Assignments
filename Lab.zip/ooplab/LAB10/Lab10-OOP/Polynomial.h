/*
 * Polynomial.h
 *
 *  Created on: Apr 2, 2019
 *      Author: maaz
 */

#ifndef POLYNOMIAL_H_
#define POLYNOMIAL_H_

#include<string>
#include<iostream>
#include"Complex.h"
#include<math.h>
using namespace std;


class Polynomial {
	int a,b,c;
public:
	Polynomial(); // a default constructor
	Polynomial(int a,int b,int c); // parameterized constructor
	Polynomial(const Polynomial &other); // copy constructor
	void seta(int aa);
	void setb(int x);
	void setc(double x);
	int geta()const;
	int getb()const;
	int getc()const;
	Polynomial& operator=(const Polynomial &other); //assigns (copies) a Polynomial and Returns the same
	bool operator==(const Polynomial &other); //Compare and return true if equal
	Polynomial operator+(const Polynomial &other); //adds two Polynomial and returns the result
	Polynomial operator-(const Polynomial &other); //subtracts two Polynomial and returns the result
	Polynomial operator*(double d); //Multiplies Polynomial with scaler value and returns the result
	operator string(); //returns the string format of the polynomial
	int evaluate(int x); //evaluate the polynomial
	void roots(Complex &c1,Complex &c2);
};
ostream& operator<<(ostream& input, Polynomial&x){
    input<<(string)x;
    return input;
} //Outputs the Polynomial
istream& operator>>(istream& output, Polynomial&x){
    int a=0,b=0,c=0;
    output >> a >> b >> c;
    x.seta(a);
    x.setb(b);
    x.setc(c);
    return output;
} //Inputs the Polynomial

#endif /* POLYNOMIAL_H_ */
