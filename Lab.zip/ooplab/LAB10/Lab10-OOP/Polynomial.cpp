/*
 * Polynomial.cpp
 *
 *  Created on: Apr 2, 2019
 *      Author: maaz
 */

#include "Polynomial.h"
#include<iostream>
#include<string>
#include<math.h>
Polynomial::Polynomial() {
	a=b=c=0;
}

Polynomial::Polynomial(int a,int b,int c){
	this->a = a;
	this->b=b;
	this->c = c;
} // parameterized constructor
Polynomial::Polynomial(const Polynomial &other){
	this->a= other.a;
	this->b=other.b;
	this->c=other.c;
} // copy constructor

void Polynomial::seta(int aa){a = aa;}
void Polynomial::setb(int x){b=x;}
void Polynomial::setc(double x){c=x;}
int Polynomial::geta()const{return a;}
int Polynomial::getb()const{return b;}
int Polynomial::getc()const{return c;}
Polynomial& Polynomial::operator=(const Polynomial &other){
	this->a= other.a;
	this->b=other.b;
	this->c=other.c;
	return *this;
} //assigns (copies) a Polynomial and Returns the same
bool Polynomial::operator==(const Polynomial &other){
	if(this->a== other.a &&	this->b==other.b &&	this->c==other.c)
		return true;
	return false;
} //Compare and return true if equal
Polynomial Polynomial::operator+(const Polynomial &other){
	Polynomial temp(a+other.a, b+other.b, c+other.c);
	return temp;
} //adds two Polynomial and returns the result
Polynomial Polynomial::operator-(const Polynomial &other){
	Polynomial temp(a-other.a, b-other.b, c-other.c);
	return temp;
} //subtracts two Polynomial and returns the result
Polynomial Polynomial::operator*(double d){
	Polynomial temp(a*d, b*d, c*d);
		return temp;
} //Multiplies Polynomial with scaler value and returns the result
Polynomial::operator string(){
	string temp="";
			if(a!=0){
				if(a<0){
					temp+="-";
					temp+=to_string(a);
						temp += "x^2";
				}
				else{
					temp+=to_string(a);
					temp += "x^2";
				}
			}
			if(b!=0){
				if(b<0){
						temp+=" - ";
						temp+=to_string(b);
						temp += "x";
					}
					else{
						temp+=" + ";
						temp+=to_string(b);
						temp += "x";
					}

			}
			if(c!=0){
				if(c<0){
						temp+=" - ";
						temp+=to_string(c);
					}
					else{
						temp+=" + ";
						temp+=to_string(c);
					}
			}
	    	return temp;

} //returns the string format of the polynomial
int Polynomial::evaluate(int x){
	int result =  a*x*x + b*x + c;
	return result;
} //evaluate the polynomial
void Polynomial::roots(Complex &c1,Complex &c2){
	int real = -b/2*a;
	int deter = b*b- 4*a*c;

	if(deter<0){
		c1.setReal(real);
		c2.setReal(real);
		deter*=-1;
		deter = sqrt(deter);
		deter/=(2*a);
		c1.setImaginary(deter);
		c2.setImaginary(-deter);

	}
	else{
		deter = sqrt(deter);
		c1.setReal(real + deter/2*a);
		c2.setReal(real - deter/2*a);
		c1.setImaginary(0);
		c2.setImaginary(0);
	}

}

