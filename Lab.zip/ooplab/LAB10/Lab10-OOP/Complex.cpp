/*
 * Complex.cpp
 *
 *  Created on: Mar 26, 2019
 *      Author: maaz
 */

#include "Complex.h"

Complex::Complex(double a=0, double b=0){
	real =a;
	imaginary = b;
}

Complex::Complex(const Complex & copy){
	real = copy.getReal();
	imaginary = copy.getImaginary();
}

void Complex::setReal(double a){
	real = a;
};
double Complex::getReal() const{return real;}
void Complex::setImaginary(double i){
	imaginary = i;
}
double Complex::getImaginary() const{return imaginary;}

Complex Complex::operator+(Complex &a){
	Complex temp (real+a.getReal(), imaginary + a.getImaginary());
	return temp;
}
Complex Complex::operator-(Complex &a){
	Complex temp (real-a.getReal(), imaginary - a.getImaginary());
	return temp;
}
Complex Complex::operator-(){
	Complex temp(real*-1, imaginary *-1);
	return temp;
}

Complex Complex::operator*(Complex &a){
	Complex temp(real*a.getReal() - imaginary * a.getImaginary() , real * a.getImaginary() +imaginary * a.getReal());
	return temp;
}

void Complex::operator=(Complex &a){
	real = a.getReal();
	imaginary = a.getImaginary();
}

bool Complex::operator==(const Complex &a){
	if(real == a.getReal() && imaginary == a.getImaginary())
		return true;

	return false;
}

bool Complex::operator!(){
	if(real == 0 && imaginary == 0)
		return true;
	return false;
}

