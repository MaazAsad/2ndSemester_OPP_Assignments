/*
 * Complex.h
 *
 *  Created on: Mar 26, 2019
 *      Author: maaz
 */

#ifndef COMPLEX_H_
#define COMPLEX_H_

class Complex {
	double real,imaginary;
public:
	Complex(double a, double b);
	Complex(const Complex & copy);
	void setReal(double);
	double getReal() const;
	void setImaginary(double);
	double getImaginary() const;
	Complex operator+(Complex &a);
	Complex operator-(Complex &a);
	Complex operator-();
	Complex operator*(Complex &a);
	void operator=(Complex &a);
	bool operator==(const Complex &a);
	bool operator!();


};

#endif /* COMPLEX_H_ */
