#ifndef MATRIX_H
#define MATRIX_H
#include<iostream>
#include<string>
using namespace std;
class Matrix
{
    int row,col;
    int **mat;

public:

Matrix(); // a default constructor

Matrix(int , int ); // a parametrized constructor4

Matrix(const Matrix &); // copy constructor

Matrix& operator=(const Matrix &); //assigns (copies) a Matrix. Returns the same

bool operator==(const Matrix &); //Compares two matrices

Matrix& operator ++(); //pre-increment
Matrix& operator ++(int ignoreMe); //post-increment
Matrix& operator --(); //pre-decrement
Matrix& operator --(int ignoreMe); //post decrement

Matrix operator+(int x); //adds x to Matrix and returns the result

Matrix operator+(const Matrix &); //adds two Matrices and returns the result

Matrix operator-(int x); //subtracts x from Matrix and returns the result

Matrix operator-(const Matrix &); //subtracts two Matrices and returns the result

Matrix operator*(const Matrix &); //multiplies two Matrices

Matrix operator*(int x); //multiplies Matrix with  x

Matrix operator/(int x);// Divide Matrix by x

int operator~(); //Find determinant of Matrix

void setRow(int a){ row=a;}
void setCol(int a){ col=a;}
int getRow()const{return row;}
int getCol()const{return col;}
void printMat()const{
    for(int i=0; i<row; ++i){
        for(int j=0; j<col; ++j){
            cout << mat[i][j] << ' ';
        }
        cout << endl;
    }
}
void setMat(){
    mat = new int*[row];
    for(int i=0; i<row; ++i){
        mat[i] = new int[col];
    }
    for(int i=0; i<row; ++i){
        for(int j=0; j<col; ++j){
            cin >> mat[i][j];
            //cout << mat[i][j] << endl;
        }
    }
}

void setAt(int r, int c, int d){
    mat[r][c] = d;
}
void addAt(int r, int c, int data){
    mat[r][c] += data;
}
operator string(); //returns the string format of the Matrix
~Matrix();

};

ostream& operator<<(ostream& input, const Matrix&x){
    x.printMat();
    return input;
} //Outputs the Polynomial

istream& operator>>(istream& ouput, Matrix&x){
    // int r,c;
    // ouput >> r >> c;
    // x.setRow(r);
    // x.setCol(c);
    x.setMat();
    return ouput;
} //Inputs the Polynomial
#endif
