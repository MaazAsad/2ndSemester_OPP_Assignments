#include"Matrix.h"
#include<iostream>
#include<string>
using namespace std;
Matrix::Matrix(){
    row=col=2;
    mat = new int*[row];
    for(int i=0; i<row; ++i){
        mat[i] = new int[col];
    }
} // a default constructor

Matrix::Matrix(int a, int b){
    row=a;
    col = b;
    mat = new int*[a];
    for(int i=0;i<row;i++){
        mat[i] = new int[col];
    }
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++)
            mat[i][j] = 0;
    }
} // a parametrized constructor4

Matrix::Matrix(const Matrix &x){
    row = x.row;
    col = x.col;
    mat = new int*[row];
    for(int i=0;i<row;i++){
        mat[i] = new int[col];
    }
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            mat[i][j] = x.mat[i][j];
        }
    }

} // copy constructor

Matrix& Matrix::operator=(const Matrix &x){
    row = x.row;
    col = x.col;
    mat = new int*[row];
    for(int i=0;i<row;i++){
        mat[i] = new int[col];
    }
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            mat[i][j] = x.mat[i][j];
        }
    }
    return *this;
} //assigns (copies) a Matrix. Returns the same

bool Matrix::operator==(const Matrix &x){
    if(row != x.row || col !=x.col)
        return false;
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            if(mat[i][j] != x.mat[i][j]){
                return false;
            }
        }
    }
    return true;
} //Compares two matrices

Matrix& Matrix::operator ++(){
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            mat[i][j] += 1;
        }
    }
    return *this;
} //pre-increment
Matrix& Matrix::operator ++(int ignoreMe){
    Matrix new(*this);
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            new.mat[i][j] += 1;
        }
    }
    return new;
} //post-increment
Matrix& Matrix::operator --(){
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            mat[i][j] -= 1;
        }
    }
    return *this;
} //pre-decrement
Matrix& Matrix::operator --(int ignoreMe){
    Matrix new(*this);
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            new.mat[i][j]-= 1;
    }
}
return new;
} //post decrement

Matrix Matrix::operator+(int x){
    Matrix temp(*this);
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            temp.mat[i][j]+= x;
        }
    }
    return temp;
} //adds x to Matrix and returns the result

Matrix Matrix::operator+(const Matrix &x){
    Matrix temp(*this);
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            temp.mat[i][j]+= x.mat[i][j];
        }
    }
    return temp;
} //adds two Matrices and returns the result

Matrix Matrix::operator-(int x){
    Matrix temp(*this);
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            temp.mat[i][j]-= x;
        }
    }
    return temp;
} //subtracts x from Matrix and returns the result

Matrix Matrix::operator-(const Matrix &x){
    Matrix temp(*this);
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            temp.mat[i][j]-= x.mat[i][j];
        }
    }
    return temp;
} //subtracts two Matrices and returns the result

Matrix Matrix::operator*(const Matrix &x){
    Matrix mult(row,col);
    for(int i = 0; i < row; ++i)
        for(int j = 0; j < col; ++j)
        {
            mult.setAt(i,j,0);
        }

    // Multiplying matrix a and b and storing in array mult.
    for(int i = 0; i < row; ++i)
        for(int j = 0; j < x.col; ++j)
            for(int k = 0; k < col; ++k)
            {
                mult.addAt(i,j,mat[i][k] * x.mat[k][j]);
            }

    return mult;
}//multiplies two Matrices

Matrix Matrix::operator*(int x){
    Matrix temp(*this);
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            temp.mat[i][j]*= x;
        }
    }
    return temp;
} //multiplies Matrix with  x

Matrix Matrix::operator/(int x){
    Matrix temp(*this);
    for(int i=0;i<row;i++){
        for(int j=0; j<col; j++){
            temp.mat[i][j]/= x;
        }
    }
    return temp;
}; //Divide Matrix by x

int Matrix::operator~(){
    if(row == 2 && col == 2){
        int deter = mat[0][0] *mat[1][1] - mat[0][1]*mat[1][0];
        return deter;
    }
    return -1;

} //Find determinant of Matrix

Matrix::operator string(){
    string temp="";
    temp+= to_string(row);
    temp += "X";
    temp += to_string(col);

    for(int i=0; i<row; i++){
        temp += '\n';
        for(int j=0,k=0; j<col*2-1; j++){
            if(j%2)
                temp += "-";
            else{
                temp += to_string(mat[i][k]);
                ++k;
            }
        }
    }

    return temp;
} //returns the string format of the Matrix
Matrix::~Matrix(){
    for(int i=0; i<row; i++){
        delete []mat[i];
    }
    delete []mat;
}
