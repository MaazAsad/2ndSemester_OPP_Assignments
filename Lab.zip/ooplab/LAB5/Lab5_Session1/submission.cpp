#include<iostream>
#include<cstring>

using namespace std;

int magicSum(int x,int y)
{
    if(x==0){
		return y;
	}
	return x+(magicSum(x-1,y));
}

void Collatz(int n)
{
    if(n==1){


    	}

    	else if(n%2){
    		cout << 3*n+1 << " ";
    		Collatz(3*n+1);

    	}
    	else{
    		cout << n/2 << " ";
    		Collatz(n/2);
    	}
}

int CountCannonballs(int h)
{
    if(h==0){
    		return 0;
    	}
    	return h*h+(CountCannonballs(h-1));
}

int calculateGcd(int a,int b)
{
    if(a>b){
    		if(b!=0){
    			return calculateGcd(a-b, b);
    		}
    		else{
    			return a;
    		}
    	}
    	else{
    		if(a!=0){
    			return calculateGcd(b-a, a);
    		}
    		else{
    			return b;
    		}
    	}
}

int pow(int a,int b){
	if(b == 0){
		return 1;
	}
	return a*pow(a,b-1);
}

int parseToInteger(char* s,int length)
{
    if(*s!='\0'){
		return ((int)*s-48) *pow(10,length-1) +parseToInteger(s+1, length-1);
	}
	else
		return 0;
}

void printChar(char ch,int t){
    if(t>0){
        cout << ch;
        printChar(ch,t-1);
    }
}

void PrintPattern1(int n)
{
    if(n>0){
    printChar('*', n);
    cout << endl;
    PrintPattern1(n-1);

    printChar('*', n);
    cout << endl;
}
}

void PrintPattern2(int n,int space)
{
    if(n>0){
			printChar(' ',space);
			printChar('*', n);
			cout << endl;
			PrintPattern2(n-2,space+1);
			printChar(' ',space);
			printChar('*', n);
			cout << endl;
		}
}



void PhoneNumberArrayIntialize(PhoneNumber arr[],int s)
{
    for(int i=0; i<s; i++){
        arr[i].areaCode = 111+i;
        arr[i].exchange = 767+i;
        arr[i].number = 1011+i;
    }
}

void PrintPhoneNumber(PhoneNumber p)
{
	cout << '(' << p.areaCode << ')' << ' ' << p.exchange<< '-' <<p.number;

}

void Initialize (string dp, string an, int acountTypeId, string accountTypeName, long balance)
{
    depositorName = dp;
	accountNumber = an;
	accountCat.Id = acountTypeId;
	accountCat.Name = accountTypeName;
	Balance = balance;
}

bool depositAmount(long amountToDeposite){
    if(amountToDeposite >0){
            Balance += amountToDeposite;
            return true;
        }
        else{
            return false;
        }
}

bool withdrawAmount(long amountToWithdraw){
    if(amountToWithdraw > Balance){
				return false;
			}
			else{
				Balance -= amountToWithdraw;
				return true;
			}
}
long getAmount(){
	return Balance;
}
