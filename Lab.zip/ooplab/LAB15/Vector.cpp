/*
 * Vector.cpp
 *
 *  Created on: May 7, 2019
 *      Author: maaz
 */

#include "Vector.h"
template<class T>
Vector<T>::Vector():size_(-1),c_index(0) {
	ptr = new T;
}

template<class T>
Vector<T>::Vector(int size):size_(size),c_index(0){
	ptr= new T[size];
}

template<class T>
Vector<T>::Vector(int size, const T& iv):size_(size),c_index(0){
	ptr = new T[size];
	for(int i=0; i<size; ++i){
		ptr[i] = iv;
		++c_index;
	}
}

template<class T>
Vector<T>::Vector(const Vector<T>& obj):size_(obj.capacity()),c_index(0){
	ptr = new T[size];
	for(int i=0;i<size;++i){
		ptr[i] = obj[i];
		++c_index;
	}
}

template<class T>
Vector<T>::~Vector() {

}

template<class T>
const T& Vector<T>::operator=(const T& obj){

}

template<class T>
T* Vector<T>::begin(){
	return ptr;
}

template<class T>
T* Vector<T>::end(){
	return (ptr+c_index);
}

template<class T>
int Vector<T>::size(){
	return size_;
}


template<class T>
bool Vector<T>::empty(){
	if(c_index == 0)
		return true;
	return false;
}

template<class T>
void Vector<T>::shrink_to_fit(int x);

template<class T>
T& Vector<T>::operator[](int index){
	return ptr[index];
}

template<class T>
T& Vector<T>::front();

template<class T>
T& Vector<T>::back();

template<class T>
void Vector<T>::push_back(const T& value);

template<class T>
void Vector<T>::pop_back(){
	T temp = ptr[size_ -1];
	-- size_;
	return temp;
}

template<class T>
void Vector<T>::swap(Vector<T>& other);

template<class T>
void Vector<T>::clear();

template<class T>
int Vector<T>::capacity()const;




