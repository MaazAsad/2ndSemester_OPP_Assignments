/*
 * Vector.h
 *
 *  Created on: May 7, 2019
 *      Author: maaz
 */

#ifndef VECTOR_H_
#define VECTOR_H_

template<typename T>
class Vector {
private:
	T* ptr;
	int size_;
	int c_index;
public:
	Vector();
	Vector(int size);
	Vector(int size, const T& iv);
	Vector(const Vector<T>& obj);
	~Vector();
	const T& operator=(const T& obj);
	T* begin();
	T* end();
	int size();

	bool empty();
	void shrink_to_fit(int x);
	T& operator[](int index);
	T& front();
	T& back();
	void push_back(const T& value);
	void pop_back();
	void swap(Vector<T>& other);
	void clear();
	int capacity()const;
};

#endif /* VECTOR_H_ */
