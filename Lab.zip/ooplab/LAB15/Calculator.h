/*
 * Calculator.h
 *
 *  Created on: May 7, 2019
 *      Author: maaz
 */

#ifndef CALCULATOR_H_
#define CALCULATOR_H_
#include <iostream>
using namespace std;
template<class T>
class Calculator {
public:

	T add(T x, T y);
	T sub(T x, T y);
	T mul(T x, T y);
	T div(T x, T y);


};
#endif /* CALCULATOR_H_ */
