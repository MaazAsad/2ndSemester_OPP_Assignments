/*
 * Calculator.cpp
 *
 *  Created on: May 7, 2019
 *      Author: maaz
 */

#include "Calculator.h"

template<class T>
T Calculator<T>::add(T x, T y){return x+y;}

template<class T>
T Calculator<T>::sub(T x, T y){return x-y;}

template<class T>
T Calculator<T>::mul(T x, T y){return x*y;}

template<class T>
T Calculator<T>::div(T x, T y){
	if(y == 0)
		cout << "infinity" << endl;
	else
		return x/y;
}

