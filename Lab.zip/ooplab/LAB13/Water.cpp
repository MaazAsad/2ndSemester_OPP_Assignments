/*
 * Water.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#include "Water.h"

Water::Water(): supplier(""){}
Water::Water(string supp, string flav, int a, int b, int c):Drink(flav, a, b, c),supplier(supp){}

Water::Water(string x, Drink xx):Drink(xx),supplier(x){}
void Water::display(){
	cout << "Supplier: "<< supplier<<endl
		 << "Flavour: "<<flavour <<endl
		 << "Temperature: "<< temprature<<endl
		 << "Price: "<< price << endl
		 << "expiry: "<<expiry << endl;
}
Water::~Water() {
	// TODO Auto-generated destructor stub
}

