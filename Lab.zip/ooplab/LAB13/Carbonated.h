/*
 * Carbonated.h
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#ifndef CARBONATED_H_
#define CARBONATED_H_
#include"Water.h"
class Carbonated:public Water{
	string type;

public:
	Carbonated();
	Carbonated(string type, string supplier, string flav, int temp, int price, int exp);
	virtual void display();
	virtual ~Carbonated();
};

#endif /* CARBONATED_H_ */
