/*
 * Person.h
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#ifndef PERSON_H_
#define PERSON_H_
#include <string>
using namespace std;
class Person {
protected:
	string name;
	string address;


public:
	Person();
	Person(string n, string a);
	virtual ~Person();
};

#endif /* PERSON_H_ */
