/*
 * Rectangle.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#include "Rectangle.h"

Rectangle::Rectangle():height(0),width(0){}
Rectangle::Rectangle(string t, int h, int w):Shape(t),height(h),width(w){}
float Rectangle::area (){
	return height*width;
}
void Rectangle::Display(){
	cout << "Type: " << type<<endl
		 << "Width: "<<width << endl
		 << "Height" << height << endl
		 << "Area: "<<this->area()<<endl;
}

Rectangle::~Rectangle(){}

