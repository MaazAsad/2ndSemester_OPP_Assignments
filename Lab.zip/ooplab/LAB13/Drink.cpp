/*
 * Drink.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#include "Drink.h"

Drink::Drink(): flavour(""),temprature(0),price(0),expiry(0){}
Drink::Drink(string flav, int temp, int price, int exp):flavour(flav),temprature(temp), price(price), expiry(exp){}
Drink::Drink(Drink &x){
	this->flavour = x.flavour;
	this->temprature = x.temprature;
	this->price = x.price;
	this->expiry=x.expiry;
}
int Drink::getPrice(){return price;}
int Drink::getTemp(){return temprature;}
int Drink::getExpDate(){return expiry;}
string Drink::getFlavor(){return flavour;}

Drink::~Drink() {
	// TODO Auto-generated destructor stub
}

