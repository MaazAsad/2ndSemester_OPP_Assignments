/*
 * Triangle.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#include "Triangle.h"

Triangle::Triangle():base(0),height(0){}

Triangle::Triangle(string t, int b, int h):Shape(t),base(b),height(h){}
float Triangle::area(){
	return 1/2.0 * base * height;
}
void Triangle::Display(){
	cout << "Type: " << type<<endl
		 << "Base: "<<base << endl
		 << "Height" << height << endl
		 << "Area: "<<this->area()<<endl;
}


Triangle::~Triangle(){}

