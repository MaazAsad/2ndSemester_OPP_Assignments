/*
 * Circle.h
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#ifndef CIRCLE_H_
#define CIRCLE_H_
#include "Shape.h"
#include <iostream>
using namespace std;

class Circle:public Shape{
private:
	float radius;
public:
	Circle();
	Circle(string t, float r);
	float area ();
	virtual void Display();
	virtual ~Circle();
};

#endif /* CIRCLE_H_ */
