/*
 * Drink.h
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#ifndef DRINK_H_
#define DRINK_H_
#include<string>
using namespace std;

class Drink {
protected:
	string flavour;
	int temprature;
	int price;
	int expiry;

public:
	Drink();
	Drink(string, int, int, int);
	Drink(Drink &x);
	int getPrice();
	int getTemp();
	int getExpDate();
	string getFlavor();
	virtual ~Drink();
};

#endif /* DRINK_H_ */
