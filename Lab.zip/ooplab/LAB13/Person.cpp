/*
 * Person.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#include "Person.h"

Person::Person():name(""),address(""){}
Person::Person(string n, string a):name(n),address(a){}
Person::~Person(){}

