/*
 * Faculty.h
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#ifndef FACULTY_H_
#define FACULTY_H_
#include"Employee.h"
#include<iostream>
using namespace std;
class Faculty:public Employee{
private:
	string designation;
	string department;


public:
	Faculty();
	Faculty(string name, string address, int Emp_no, float gross_pay, float house_rent,
	float medical_allow, string designation, string department);
	virtual float calcSalary();
	virtual void print();

	virtual ~Faculty();
};

#endif /* FACULTY_H_ */
