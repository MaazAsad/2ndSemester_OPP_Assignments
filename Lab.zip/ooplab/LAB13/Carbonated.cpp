/*
 * Carbonated.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#include "Carbonated.h"

Carbonated::Carbonated():Water(),type(""){}
Carbonated::Carbonated(string type, string supplier, string flav, int temp, int price, int exp):
		Water(supplier,flav,temp,price,exp),type(type){}
void Carbonated::display(){
	cout << "Type: "<<type<<endl;
	Water::display();
}

Carbonated::~Carbonated() {}

