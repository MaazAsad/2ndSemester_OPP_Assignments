/*
 * Shape.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#include "Shape.h"

Shape::Shape():type(""){}
Shape::Shape(string t):type(t){}

Shape::~Shape() {
	// TODO Auto-generated destructor stub
}

