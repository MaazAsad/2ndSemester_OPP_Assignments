/*
 * Circle.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#include "Circle.h"

Circle::Circle():Shape(),radius(0){}
Circle::Circle(string t, float r):Shape(t),radius(r){}
float Circle::area(){return 3.14 * radius * radius;}
void Circle::Display(){
	cout << "Type: " << type<<endl
		 << "Radius: "<<radius << endl
		 << "Area: "<<this->area()<<endl;
}

Circle::~Circle() {
	// TODO Auto-generated destructor stub
}
