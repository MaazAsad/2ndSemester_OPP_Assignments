/*
 * Rectangle.h
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#ifndef RECTANGLE_H_
#define RECTANGLE_H_
#include "Shape.h"
#include <iostream>
using namespace std;

class Rectangle:public Shape{
private:
	int height;
	int width;
public:
	Rectangle();
	Rectangle(string t, int h, int w);
	float area ();
	virtual void Display();
	virtual ~Rectangle();
};

#endif /* RECTANGLE_H_ */
