/*
 * Shape.h
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#ifndef SHAPE_H_
#define SHAPE_H_
#include<string>
using namespace std;
class Shape {
protected:
	string type;
public:
	Shape();
	Shape(string t);
	virtual float area ()=0;
	virtual ~Shape();
};

#endif /* SHAPE_H_ */
