/*
 * Faculty.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#include "Faculty.h"

Faculty::Faculty():designation(""),department(""){}
Faculty::Faculty(string name, string address, int Emp_no, float gross_pay, float house_rent,
float medical_allow, string designation, string department):
		Employee(name,address,Emp_no,gross_pay,house_rent,medical_allow), designation(designation),department(department)
	{}
float Faculty::calcSalary(){
	return net_pay;
}
void Faculty::print(){
	Employee::print();
	cout << "Designation:"<< designation<<endl
		 << "Department: "<< department << endl;
}

Faculty::~Faculty() {}
