/*
 * Triangle.h
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#ifndef TRIANGLE_H_
#define TRIANGLE_H_
#include "Shape.h"
#include <iostream>
using namespace std;

class Triangle:public Shape{
private:
float base;
float height;

public:
	Triangle();
	Triangle(string t, int b, int h);
	float area ();
	virtual void Display();
	virtual ~Triangle();
};

#endif /* TRIANGLE_H_ */
