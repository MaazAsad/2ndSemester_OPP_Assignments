/*
 * Employee.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#include "Employee.h"

Employee::Employee():Person(),Emp_no(0),gross_pay(0), house_rent(0), medical_allow(0),net_pay(0){}
Employee::Employee(string name, string address, int Emp_no, float gross_pay, float house_rent, float medical_allow)
:Person(name,address), Emp_no(Emp_no), gross_pay(gross_pay), house_rent(house_rent), medical_allow(medical_allow){
	//	gross_pay – ((45/100)*gross_pay – (5/100)*gross_pay)

		net_pay = gross_pay - ( (45/100.0 * gross_pay) - (5/100.0 * gross_pay) );
}
void Employee::print(){
	cout << "Name: "<<name<<endl
		 << "Address: "<<address<<endl
		 << "Gross Pay:" << gross_pay<<endl
		 << "House rent: "<< house_rent << endl
		 << "Medical Allowance: "<< medical_allow<<endl
		 << "Net Pay:" << net_pay << endl;
}
Employee::~Employee() {}
