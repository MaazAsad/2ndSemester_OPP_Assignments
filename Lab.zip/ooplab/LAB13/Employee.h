/*
 * Employee.h
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#ifndef EMPLOYEE_H_
#define EMPLOYEE_H_
#include "Person.h"
#include <iostream>
using namespace std;

class Employee:public Person {
protected:
	int Emp_no;
	float gross_pay;
	float house_rent;
	float medical_allow;
	float net_pay;

public:
	Employee();
	Employee(string name, string address, int Emp_no, float gross_pay, float house_rent, float medical_allow);
	virtual float calcSalary()=0;
	virtual void print();
	virtual ~Employee();
};

#endif /* EMPLOYEE_H_ */
