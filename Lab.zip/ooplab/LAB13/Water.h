/*
 * Water.h
 *
 *  Created on: Apr 23, 2019
 *      Author: maaz
 */

#ifndef WATER_H_
#define WATER_H_
#include "Drink.h"
#include <iostream>
using namespace std;
class Water:public Drink {
protected:
	string supplier;

public:
	Water();
	Water(string, string, int, int, int);
	Water(string, Drink);
	virtual void display();
	virtual ~Water();
};

#endif /* WATER_H_ */
