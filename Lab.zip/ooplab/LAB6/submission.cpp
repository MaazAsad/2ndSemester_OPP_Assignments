//Task1
struct StudentCard{
	char campusCode;
	int batch, ID;
};
void StudentCardArrayIntialize(StudentCard arr[], int s){
    #include<stdlib.h>
	#include<time.h>
	srand(time(NULL));

	int a=rand()%10000;
	int batchcode=2015;
	for(int i=0; i<s; i++){
		while(a<=999){
			a = rand()%10000;
		}
		if (i == s/2)
			batchcode++;
		if (i == s*(3/4))
			batchcode++;
		arr[i].ID = a;
		arr[i].campusCode = 'I';
		arr[i].batch = batchcode;

	}
}
void PrintStudentCard(StudentCard s) {
    cout << '('<<s.campusCode <<') ' << s.batch << '-' << s.ID<<endl;
}


//Task2
struct CustomTime{
	int hours=0, min=0, seconds=0;
};

long timeToSeconds(CustomTime t1) {
    long inSec = t1.hours*3600 + t1.min*60 +t1.seconds;
	return inSec;
}

CustomTime SecondsToTime(long t) {
    int h,m,s;
h = t/3600;
t = t-h*3600;
m = t/60;
t-= m*60;
s = t;

CustomTime temp;
temp.hours = h;
temp.min = m;
temp.seconds = s;

return temp;
}

CustomTime AddTimes(CustomTime t1, CustomTime t2) {
    long temp1 = timeToSeconds(t1);
	long temp2 = timeToSeconds(t2);
	CustomTime temp = SecondsToTime(temp1+temp2);
	return temp;
}

CustomTime* MakeNewTime() {
    CustomTime* MakeNewTime() {
	CustomTime *x = new CustomTime;
	return x;
}

void IntilaizeTime(CustomTime* & p, long totalSec) {
    *p = SecondsToTime(totalSec);
}

CustomTime* MakeArrayOfTimes(int s) {
    CustomTime *x = new CustomTime[s];
	return x;
}
void IntilaizeTimeArray(CustomTime* &p, int hours[], int mins[], int sec[],int s) {
    p = MakeArrayOfTimes(s);
    for(int i=0; i<s; i++){
    	p[i].hours= hours[i];
    	p[i].min = mins[i];
    	p[i].seconds = sec[i];
    }
}

//Task3
struct Fraction{
	int deNom;
	int Nom;

};

void IntializeFraction(Fraction &f, int deNom, int Nom) {
    if(deNom != 0){
		f.Nom = Nom;
		f.deNom = deNom;
	}
}
Fraction AddFractions(Fraction f1, Fraction f2){
    Fraction temp;
	temp.Nom = (f1.Nom * f2.deNom) + (f2.Nom * f1.deNom);
	temp.deNom = f1.deNom * f2.deNom;
    return temp;
}
Fraction MultiplyFractions(Fraction f1, Fraction f2){
    Fraction temp;
	temp.Nom = f1.Nom* f2.Nom;
	temp.deNom =  f1.deNom*f2.deNom;
	return temp;
}
Fraction SubtractFractions(Fraction f1, Fraction f2){
    Fraction temp;
	temp.Nom = (f1.Nom * f2.deNom) - (f2.Nom * f1.deNom);
	temp.deNom = f1.deNom * f2.deNom;
	return temp;
}
Fraction DivideFractions(Fraction f1, Fraction f2){
    Fraction Temp;
if(f1.deNom !=0 && f2.deNom !=0){
    Temp.Nom = f1.Nom * f2.deNom;
    Temp.deNom = f1.deNom * f2.Nom;
}
return Temp;
}

//Task4
struct Studenet{
private:
	int rollNo;
	char* name;
	string city,phone;
public:
	void Initialize() {
	    rollNo = 0;
	    name = new char[45];
	    city = phone = "\0";
	}
	void Destroy(){
	    delete []name;
	}
	bool setRollNo(int r){
			if(r>999){
				rollNo = r;
				return true;
			}
			return false;
		}
	int getRollNo(){return rollNo;}

	bool setName(char* n){
	    int i;
	    for(i=0; n[i] !='\0'; i++);
	    if(i>=4){
	    	name = n;
	    	return true;
	    }
	    else
		   return false;
	}
	char* getName(){return name;}

	bool setCity(string c){
		if((c!="\0")){
			city = c;
			return true;
		}
		return false;
	}
	string getCity(){
		return city;
	}
	bool setPhone(string c){
		if((c!="\0")){
			phone= c;
			return true;
		}
		return false;
	}
	string getPhone(){
		return phone;
	}
};

void SetStudentArray(Student arr[], int size, char* names[], string cities[], string phones[]){
	for(int i=0; i<size; i++){
		arr[i].setName(names[i]);
		arr[i].setPhone(phones[i]);
		arr[i].setRollNo(1000+i);
		arr[i].setCity(cities[i]);
	}
}

void GetStudentArray(Student arr[], int size) {
	for(int i=0; i<size;i++){
		cout << arr[i].getName() << endl
			 << arr[i].getRollNo() << endl
			 << arr[i].getPhone() << endl
			 << arr[i].getCity() << endl<<endl;
	}
}

//Task5
struct Employee {
private:
	int empNo;
	long basicPay, houseRent, medicalAllow, conveyanceAllow,netpay;
public:
	void setBasicPay(long bp){
		if(bp> 0){
			basicPay = bp;
		}
		else{
			cout << "Enter a positive value:" <<endl;
		}
	}

	long getBasicPay(){
		return basicPay;
	}

	void setEmpNo(int a){
		empNo = a;
	}

	int getEmpNo(){
		return empNo;
	}

	void calculateHouseRent(){
		houseRent = 0.54 * basicPay;
	}

	void calculateMedicalAllowance(){
		medicalAllow = 0.15* basicPay;
	}

	void calculateConveyanceAllowance(){
		conveyanceAllow = 0.20 * basicPay;
	}

	void calculateNetPay(){
		netpay = basicPay + houseRent + medicalAllow + conveyanceAllow;

	}
	long gethouseRent(){return houseRent;}
	long getMedicalAllowance(){return medicalAllow;}
	long getConveyanceAllowance(){return conveyanceAllow;}
	long getNetPay(){return netpay;}


};

void Swap(Employee &emp1, Employee &emp2){
	Employee temp;
	temp.setEmpNo(emp1.getEmpNo());
	temp.setBasicPay(emp1.getBasicPay());

	emp1.setEmpNo(emp2.getEmpNo());
	emp1.setBasicPay(emp2.getBasicPay());

	emp2.setBasicPay(temp.getBasicPay());
	emp2.setEmpNo(temp.getEmpNo());

	emp1.calculateHouseRent();
	emp1.calculateMedicalAllowance();
	emp1.calculateConveyanceAllowance();
	emp1.calculateNetPay();

	emp2.calculateHouseRent();
	emp2.calculateMedicalAllowance();
	emp2.calculateConveyanceAllowance();
	emp2.calculateNetPay();

}

//Task6
struct accountCategory{
private:
	int Id;
	string Name;
public:
	void setID(int x){ Id =x;}
	void setName(string x){Name =x;}
	int getID(){return Id;}
	string getName(){return Name;}
};

struct BankAccount{
private:
	string depositerName,accountNumber;
	accountCategory accountCat;
	long Balance;
public:
	void Initilaize(string DP, string an,
			int acountTypeId, string accountTypeName, long balance){
		depositerName = DP;
		accountNumber = an;
		accountCat.setID(acountTypeId);
		accountCat.setName(accountTypeName);
		Balance = balance;
	}

	bool deopsitAmount(long amountToDeposite){
		if(amountToDeposite>0){
			Balance += amountToDeposite;
			return true;
		}
		return false;
	}
	bool withdrawAmount(long amountToWithdraw){
		if(Balance > amountToWithdraw){
			Balance -= amountToWithdraw;
			return true;
		}
		return false;
	}

	long getAmount(){return Balance;}

};


//Task7
struct CourseRegestration{
private:
	string CCode,CTitle;
	int CHours,RepeatCount=1;
	char Section;
public:
	void inIt(string code, string title, char sec, int h){
		CCode = code;
		CTitle= title;
		Section = sec;;
		CHours = h;
	}
	string getCode(){return CCode;}
	string getTitle(){return CTitle;}
	char getSection(){return Section;}
	int getCHours(){return CHours;}
	int getRepCount(){return RepeatCount;}
};

struct SemesterRegistration{
private:
	string semesterCode;
	CourseRegestration courses[5];
	int coursecount=0;
public:
	bool Addcourse(string code, string title, char section, int hours){
		if(coursecount <5){
			courses[coursecount].inIt(code,title,section,hours);
			coursecount++;
			return true;
		}
		return false;
	}
	bool isRegistered(string coursecode){
		bool x = false;
		for(int i=0; i<coursecount; i++){
			if(courses[i].getCode() == coursecode){
				x= true;
			}
		}
		return x;
	}

	void setSemCode(string x){semesterCode = x;}
	string getSemCode(){return semesterCode;}

	int getTotalCredHours(){
		int x=0;
		for(int i=0; i<coursecount; i++){
			x+= courses[i].getCHours();
		}
		return x;
	}

};


int GetCreditHoursCount(SemesterRegistration sr){
	return sr.getTotalCredHours();
}

bool FindCourseInSemesterRegistration(SemesterRegistration sr, string Coursecode){
	return sr.isRegistered(Coursecode);
}


//FOr TASK 8 and 9 use the defined member functions in lab task pdf.
//task 8
struct ShoppingItem{
private:
	string Name;
	long bPrice, totalPrice;
	int quantity;
public:
	void InputItem(string n, long price, int quant){
		Name = n;
		bPrice = price;
		quantity = quant;
		totalPrice = bPrice * quantity;
	}

	void Display(){
		cout << Name << ' ' << bPrice << ' ' << quantity << ' ' << totalPrice << endl;
	}

	string getName(){return Name;}
	long getPrice(){return bPrice;}
	long getTotalPrice(){return totalPrice;}
	int getQuant(){return quantity;}
};

struct ShopingList{
private:
	int nItems=0;
	ShoppingItem items[5];
public:
	bool AddItem(string name, long price, int quantity){
		if(nItems<10){
			items[nItems].InputItem(name, price, quantity);
			nItems++;
			return true;
		}
		return false;
	}

	void Print(){
		cout << "Name     "<< "Price       " << "Quantity   " << " Total Price" << endl;
		for(int i=0; i<nItems; i++){
			items[i].Display();
		}
	}

	void TotalCost(){
		long total = 0;
		for(int i=0; i<nItems; i++){
			total += items[i].getTotalPrice();
		}
		cout << total << endl;
	}
};

//task9
struct Car{
private:
	int timeofArival, slot;
	string regno;
public:
	void init(int t=0,int s=0,string no = "\0"){
		timeofArival = t;
		slot = s;
		regno = no;
	}

	void Display(){
		cout << regno << "   " << slot << "    " << timeofArival<<endl;
	}

	int getTimeArival(){return timeofArival;}
	int getSlot(){return slot;}
	string getRegno(){return regno;}

};

struct ParkingGarage{
private:
	bool slots[5];
	Car cars[5];
public:
	void Initialize(){
		for(int i=0;i<5;i++){
			slots[i] = true;
			cars[i].init();
		}
	}
	void Print(){
		cout << "Reg. No.    " << "Slot    " << "Time of Arival" << endl;
		for(int i=0; i<5; i++){
			if(!slots[i]){
				cars[i].Display();
			}
		}
		cout << endl;
		cout << "Empty Slots: ";
		for(int i=0;i<5; i++){
			if(slots[i])
				cout << i+1 << " ";
		}
		cout << endl;

	}
	bool IsFull(){
		int x=0;
		for(int i=0; i<5; i++){
			if(slots[i]){
				x++;
			}
		}
		if(x<5)
			return false;
		else
			return true;
	}

	void ParkCar(string regno, int time){
		int i;
		if(!IsFull()){
			for(i=0; slots[i] == true; i++);
			cars[i].init(time, i, regno);
			slots[i] = false;
		}

	}

	void RemoveCar(string regno){
		int i, currentime,t1h,t1m,t2h,t2m;
		float hours=0;
		for(i=0; cars[i].getRegno() != regno; i++);
		cout << "Enter Time:";
		cin >> currentime;
		t1m = currentime%100;
		t1h = (currentime-t1m)/100;

		t2m = cars[i].getTimeArival()%100;
		t2h = (cars[i].getTimeArival()-t2m)/100;

		if(t1h> t2h){
			hours = (t2h+24)-t1h;
		}
		else if(t1h < t2h){
			hours = t2h-t1h;
		}

		if(t1h == t2h){
			hours = (t2m-t1m) /60.0;
		}
		slots[i] = true;
		cout << "Cost: " << hours*20 << endl;



	}
};
