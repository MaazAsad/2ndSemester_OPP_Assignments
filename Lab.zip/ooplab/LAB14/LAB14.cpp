//============================================================================
// Name        : LAB14.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
#include <fstream>
#define size 2
using namespace std;

class TeleDirectory{
	string name;
	string phone;
	string address;
public:
	void  input();
	string searchByName(string n);
	string searchByNumber(string p);
	void printDirectory();


};
void TeleDirectory::input(){
	fstream file("teledir.txt",ios::out);
	string n, ad, num;
	cout<<"Enter name: ";
	cin>>n;
	cout<<"Enter address:";
	cin>>ad;
	cout<<"Enter phone no:";
	cin>>num;
	this->name=n;
	this->address=ad;
	this->phone=num;
	if(file.is_open()){
		cout<<"File is opened."<<endl;
	}
	if(file){
		string temp;
		temp+=this->name+" "+this->address+" "+this->phone+"\n";
		file<<temp;
	}
	file.close();

}
string TeleDirectory::searchByName(string n){
	ifstream file("teledir.txt");
	file.clear();
	string temp;
	if(file.is_open()){
		cout<<"File is opened"<<endl;
	}
	if(file){
		file>>temp;
		if(temp==n){
			return this->phone;
		}
	}
	file.close();
	return 0;
}
string TeleDirectory::searchByNumber(string p){

	ifstream file("teledir.txt");

			file.clear();
			string temp;
			if(file.is_open()){
				cout<<"File is opened"<<endl;
			}
			if(file.is_open()){
					getline(file,temp,' ');
					getline(file,temp,' ');
					getline(file,temp,'\n');


				if(temp==p){
					cout<<"number found"<<endl;
						return this->name;
					}

			}
			file.close();

	return "not found";
}
void TeleDirectory::printDirectory(){
	ifstream file("teledir.txt");

					file.clear();
					string temp;
					if(file.is_open()){
						cout<<"File is opened"<<endl;
					}
					if(file.is_open()){
							getline(file,temp,' ');
							cout<<"Name: "<<temp<<endl;
							getline(file,temp,' ');
							cout<<"Address: "<<temp<<endl;
							getline(file,temp,'\n');
							cout<<"Phone No: "<<temp<<endl;
					}


}
//tele direc -----------------

class Student{

	string name ;
	int age ;
	string phone ;
	float cgpa;
	int rollNo;
public:
	Student():name("\0"),age(0),phone("\0"), cgpa(0.0), rollNo(0){}

	void setName(string a){name=a;}
	void setAge(int a){age=a;}
	void setRoll(int r){rollNo=r;}
	void setCgpa(float c){cgpa=c;}
	void setPhone(string p){phone=p;}


	string getName(){return name;}
	int getAge(){return age;}
	int getRoll(){return rollNo;}
	float getCgpa(){return cgpa;}
	string getPhone(){return phone;}



	string ReadFromFile(ifstream & );
	void WriteToFile(ofstream &) ;
};

void Student::WriteToFile(ofstream  &x){
	string temp;
	cout<<"Enter name: ";
	cin>>name;
	cout<<"Enter phone: ";
	cin>>phone;
	cout<<"Enter age: ";
	cin>>age;
	cout<<"Enter rollNo: ";
	cin>>rollNo;
	cout<<"Enter cgpa: ";
	cin>>cgpa;
	x<<name<<" "<<age<<" "<<rollNo<<" "<<phone<<" "<<cgpa<<"\n";

}
string Student::ReadFromFile(ifstream &x){
	string temp;
	getline(x,temp);
	return temp;
}



void printLines(int nlines, string filename){
	ifstream f1(filename);
	string temp;
	int i=0,skip;
	if(nlines ==0){
		while(f1.good()){
			getline(f1,temp,'\n');
			cout << temp << endl;
		}

	}
	else{
		if(f1){
			while(f1.good()){
				getline(f1,temp,'\n');
				++i;
			}
		}
	//	cout << i << endl;

		if(i<nlines){
			while(f1.good()){
				getline(f1,temp,'\n');
	//			cout << temp << endl;
			}
		}
		else{
			skip = (i-1)-nlines;

	//		cout << skip<<endl;
			f1.close();
			f1.open(filename);
			while(skip>0){
				getline(f1,temp,'\n');
				--skip;
			}

			while(f1.good()){
				getline(f1,temp,'\n');
				cout << temp << endl;
			}

		}
		f1.close();
	}
	f1.close();

}

void arrayToFile(string name, int* ptr, int _size){
	ofstream file(name);
	if(file.is_open()){
		for(int i=0;i<_size;i++){
			file<< ptr[i];
			if(i<_size-1){
				file<<"\n";
			}
		}
	}

	file.close();

}

void fileToArray(string name,int *&ptr){
	fstream file(name,ios::in);
	if(file.is_open()){

		int _size=0,_i=0;
		string temp;

		file.seekg(0,ios::end);
		_size=file.tellg()/2;
		file.seekg(0,ios::beg);
		//temp="\0";
		ptr=new int[_size];
		file>>temp;
		ptr[_i]=stoi(temp);
		_i++;
		while(file){
			file>>temp;
			ptr[_i]=stoi(temp);
			_i++;

		}
	}

	file.close();

}


int main() {
	cout << "Task 1---------" << endl;
	int rollno[size];
	string	fname[size],lname[size], department[size],section[size];
	ofstream write("Student.txt");
	if(write){
		for(int i=0; i<size; ++i){
			cout << "Enter Students roll no: ";
			cin >> rollno[i];

			cout << "Enter Student's FirstName: ";
			cin.ignore();
			getline(cin,fname[i]);
			cout << "Enter Student's LastName: ";
			getline(cin,lname[i]);

			cout << "Enter Student's Depaptment: ";
			getline(cin,department[i]);
			cout << "Enter Student's Section: ";
			getline(cin,section[i]);
		}

		for(int i=0; i<size; ++i){
			write << rollno[i];
			write << " ";
			write << fname[i];
			write << " ";
			write << lname[i];
			write << " ";
			write << department[i];
			write << " ";
			write << section[i];
			write << "." << endl;
		}
	}
	else{
		cout << "File not opened" << endl;
	}
	write.close();

	cout << endl<< "Task 2-------" << endl;

	ifstream read("Student.txt");
	if(read){
		int i=0;
		char temp;
		while(read.eof()){
			read >> rollno[i];
			read >> fname[i];
			read >> lname[i];
			read >> department[i];
			read >> section[i];
			read >> temp;
			++i;
		}

		for(int i=0; i<size; ++i){
			cout << rollno[i];
			cout << " ";
			cout << fname[i];
			cout << " ";
			cout << lname[i];
			cout << " ";
			cout << department[i];
			cout  << " ";
			cout << section[i];
			cout  << "." << endl;
		}
	}
	else{
		cout << "File not opened"<<endl;
	}
	read.close();

	cout<< endl << "Task 3------" << endl;
	string temp1,temp2;
	ifstream f1("f1.txt");
	ifstream f2("f2.txt");
	if(f1 && f2){

		while(f1.good()){
			getline(f1,temp1,'\n');
			getline(f2,temp2,'\n');
			if(temp1 !=temp2){
				cout << ">" << temp1 << endl << "<" << temp2 << endl;
			}
		}
	}
	else{
		cout << "File not opened" << endl;
	}

	f1.close();f2.close();

	cout<< endl << "Task 4------" << endl;
	printLines(1, "f1.txt");

	cout << endl << "Task 5----" << endl;
	TeleDirectory temp;
	temp.input();
	cout<<temp.searchByName("Maaz")<<endl;
	cout<<temp.searchByNumber("0304")<<endl;
	temp.printDirectory();

	cout <<endl<< "Task 6-----" << endl;

	int *_ptr0= new int[size];
	int *_ptr1;

	for(int i=0;i<size;i++){
		_ptr0[i]=i+1;
	}
	arrayToFile("test.txt",_ptr0,size);
	fileToArray("test.txt",_ptr1);
	for(int i=0;i<size;i++){
		cout<<_ptr1[i]<<" ";
	}


	cout << endl <<"Task 7-----" << endl;
	ofstream file("StudentData.txt", ios::app);
	Student s[size];
	if(file.is_open()){

		for(int i=0;i<size;i++){
			cout<<"enter data for student "<<i+1<<": "<<endl;
			s[i].WriteToFile(file);
		}
	}
	file.close();


	ifstream _read("StudentData.txt");
	if(_read.is_open()){
		for(int i=0;i<size;i++){
				cout<<s[i].ReadFromFile(_read)<<endl;
			}
	}
	_read.close();


	return 0;
}
