#include "submission.cpp"
#include <gtest/gtest.h>

TEST(Task4, Count) {
    ASSERT_EQ(4, countWithRecursion(1234));
    ASSERT_EQ(1, countWithRecursion(0));
    ASSERT_EQ(2, countWithRecursion(23));

    }

TEST(Task6, Power) {
    ASSERT_EQ(8, pow(2,3));
    ASSERT_EQ(1, pow(3,0));
    ASSERT_EQ(0, pow(0,3));
    }

TEST(Task8, DecToOct) {
    ASSERT_EQ(2, decimalToOctalWithRecursion(55));
    ASSERT_EQ(0, decimalToOctalWithRecursion(92));
    ASSERT_EQ(0, decimalToOctalWithRecursion(0));
    }

TEST(Task9, Palindrome) {
        char a[]="madam";
    ASSERT_EQ(true, isPalindrome(a,0,5));
    char a1[]="a";
    ASSERT_EQ(true, isPalindrome(a,0,1));
    char a2[]="aa";
    ASSERT_EQ(true, isPalindrome(a2,0,2));
    char a3[]="ab";
    ASSERT_EQ(false, isPalindrome(a3,0,2));

    }

// TEST(Task10, Reverse) {
//         string s="hello";
//         string actual=Reverse(s,5);
//         string expected="olleh";
//
//
//     ASSERT_EQ(0, expected.compare(actual));
//     string s1="";
//         string actual1=Reverse(s,0);
//         string expected1="";
//
//
//     ASSERT_EQ(0, expected1.compare(actual1));
//
//    string s2="book";
//         string actual2=Reverse(s2,4);
//         string expected2="koob";
//
//
//     ASSERT_EQ(0, expected2.compare(actual2));
//
//  }


TEST(Task11, fab) {
    ASSERT_EQ(3, fab(4));
    ASSERT_EQ(8, fab(6));
    ASSERT_EQ(0, fab(0));

 }


// TEST(Task12, replace) {
//         char a[]="steve";
//         char * b= replace (a, 'e', 'a');
//    char expected[]="stava";
//   for(int i=0;i<5;i++)
//     {
//    //cout<<a[i]<<"  "<<b[i]<<endl;
//     ASSERT_EQ(expected[i], b[i]);
//
//
//     }
//
//     char a1[]="radar";
//         char * b1= replace (a1, 'a', 'o');
//         char expected1[]="rodor";
//   for(int i=0;i<4;i++)
//     {
//     ASSERT_EQ(b1[i], expected1[i]);
//
//
//     }
//
//    // ASSERT_EQ(b1, a1);
//
//     //ASSERT_EQ("rodor", replace ("radar",'a','o') );
//    }

TEST(Task13, Max) {
int a[5]={2,3,4,8,1};
int b[1]={28};
    ASSERT_EQ(8,FindMax(a,0,5));
    ASSERT_EQ(28,FindMax(b,0,1));
   }

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
