//============================================================================
// Name        : recursion.cpp
// Author      :
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
using namespace std;

void func1(int n){
	for(int i=1; i<=n ;i++){
		cout << i;
	}
	for(int i=n; i>0 ;i--){
			cout << i;
		}



}

void func1WithRecursion(int n){

	if(n<=9){
		cout << n;
			func1WithRecursion(n+1);
			cout << n;

	}

}

int count(int n){
	int x = 0;
	for(; n!=0; x++){
		n/=10;
	}
	return x;
}

int countWithRecursion(int n){
	//cout << n <<endl;
	int x=0
	if(n==0){
		return ;
	}
	if(n>0){
		x+=countWithRecursion(n/10);
	}
}

int pow(int b,int e){
		int x=1;
	for(int i=0; i<e; i++){
		x*=b;
	}
	return x;
}

int powWithRecursion(int b,int e){
	if(e == 0){
		return 1;
	}
	else{
		return b*(powWithRecursion(b, e-1));
	}
}

int decimalToOctal(int n){
	int oct =0,placeVal = 1;
	for(int i=0; n!=0; i++){
		oct += (n % 8) * placeVal;
		n /= 8;
		placeVal *= 10;
	}
	return oct;
}

int decimalToOctalWithRecursion(int n){
	// static int oct =0;
	//
	// if(n==0){
	// 		return n;
	// 	}
	// 	else{
	// 		oct *=10;
	// 		oct += (n % 8);
	// 		n /=8;
	// 		decimalToOctalWithRecursion(n);
	//
	// 	}
	// static int count =0, digit;
	// while(oct!=0 ){
	// 	digit = oct%10;
	// 	oct /=10;
	// 	if(digit > 5)
	// 		count ++;
	// }
	//
	// return count;
	int count =0;
	if(n>8){
		count = decimalToOctalWithRecursion(n/8);
		if(n%8>5);
			count ++;
	}
	if(n>5 &&n<=7){
		count++;
	}
	return count;
}


bool isPalindrome(char* str,int s,int l){

    if (s == l-1)
    	return true;

    if (str[s] != str[l-1])
    	return false;

	if (s < l)
    	return isPalindrome(str, s + 1, l - 1);

    return true;


}

string Reverse(string s,int length){
	if(length >=0){
        return s[length-1]+Reverse(s,length-1);
    }
    // if(length == 0){
    //     return s[0];
    // }
}

int fab(int n){
	if((n==1)||(n==0))
    {
        return(n);
    }
    else
    {
        return(fab(n-1)+fab(n-2));
    }
}

char* replace(char* s,char f,char t){
	if(*s){
		if(*s == f){

			*s = t;

		}
			replace(s+1,f,t);
			return s;

	}
	return s;
}

int FindMax(int arr[],int Index, int length){
	if(Index == length){
			return arr[length];
	}
	else if(arr[Index]> arr[length-1]){
		FindMax(arr,Index,length-1);
	}
	else if(arr[Index]< arr[length-1]){
		FindMax(arr,Index+1,length);
	}

}

void printChar(char ch,int t){
    if(t>0){
        cout << ch;
        printChar(ch,t-1);
    }

 }

void PrintPattern3(char ch,int lines){
  if(lines >0){
	  PrintPattern3(ch,lines-1);
	  printChar(ch,lines);
	  cout << endl;
  }
}

void PrintPattern4(char ch,int lines, int start){
	if(lines > 0){
		printChar('_',start);
		printChar(ch, lines);
		cout << endl;
		PrintPattern4(ch,lines-1,start+1);
	}
}

void PrintPattern6(char ch,int lines, int start){
	if(lines>0){
		printChar('_',lines-1);
		printChar(ch,start);
		cout << endl;
		PrintPattern6(ch,lines-1,start+1);
		//cout << lines << endl << start<<endl;
		if(start>1){
			printChar('_',lines);
			printChar(ch,start-1);
			cout << endl;
		}
	}
}

void PrintPattern(int n,int k){
	if(n<=k){
		cout <<n;
		printChar('+',n);
		PrintPattern(n+1,k);

		if(k-n>0){
			cout <<n;
			printChar('-',n);
		}
	}
}

int main() {

	//func1WithRecursion(1);
//	int a= count(55598);
//	cout << a;
	// int a;
	// a =countWithRecursion(55985);
	// cout << a;

//	int a = pow(2,4);
//	cout << a;
//	int a = powWithRecursion(2,3);
//	cout << a;
	//
	int x = decimalToOctal(55);
	cout << x << endl;
	 x = decimalToOctalWithRecursion(55);
	cout << x << endl;

	// bool a = isPalindrome("ZDAZ",0,4);
	// cout << a<<endl;
	//cout << false <<endl;
	// string a;
	// a = Reverse("Maaz", 4);
	// cout << a <<endl;

	//cout << fab(6)<<endl;
	//

	//  char *a;
	//  a = new char[5];
	//  a = "hello";
	// a = replace(a,'l','a');
	// cout << a << endl;
	// int a[]={3,4,22,2,6,10,11,15};
	// cout << FindMax(a,0,8)<<endl;

	//PrintPattern6('*',6,1);

	//PrintPattern(1,6);
	// char *a;
	// a = new char[10];
	// a= "Maaz Asad";
	// a= replace(a,'a','e');
	// cout<<a << endl;


	return 0;
}
