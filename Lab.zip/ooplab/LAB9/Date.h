/*
 * Date.h
 *
 *  Created on: Mar 26, 2019
 *      Author: maaz
 */

#ifndef DATE_H_
#define DATE_H_

#include<string>
class Date {
	int mYear,mMonth,mDay;
public:
	Date(int year, int month, int day);
	int getDay()const;
	int getMonth()const;
	int getYear()const;
	bool isLeapYear()const;
	void operator=(const Date &obj);
	bool operator>(const Date &obj);
	bool operator>=(const Date &obj);
	bool operator<(const Date &obj);
	bool operator<=(const Date &obj);
	bool operator==(const Date &obj);
	bool operator!=(const Date &obj);

	Date operator+(int a);
	Date operator-(int a);
	Date operator+(Date &a);
	Date operator-(Date &a);

	std::string toString();
};

#endif /* DATE_H_ */
