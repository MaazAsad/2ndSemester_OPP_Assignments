/*
 * Distance_test.cpp
 *
 *  Created on: Mar 27, 2019
 *      Author: maaz
 */
#include<iostream>
#include"Distance.h"
using namespace std;

int main(void) {

	Distance h(5,11);
	Distance w(5,11);
	Distance y(5,12);
	Distance z(5,10);
	Distance a =  w+y;
	cout << a.getFeet() << ' ' << a.getInches() << endl;

	cout << (h == w)<<endl
		 << (h<y) << endl
		 << (h>z) << endl
		 << y.getFeet()<< ' ' << y.getInches() << endl;
	h+=w;
	z-=w;
	cout << h.getFeet() << ' ' << h.getInches() << endl;
	cout << z.getFeet() << ' ' << z.getInches() << endl;



}
