/*
 * Counter.cpp
 *
 *  Created on: Mar 26, 2019
 *      Author: maaz
 */

#include "Counter.h"
int Counter::objCount =0;
Counter::Counter() {
	count =1;
	++objCount;
	serialNo = objCount;

}
Counter::Counter(int c){
	count = c;
	++objCount;
	serialNo = objCount;
}

Counter::~Counter(){
	--objCount;
}

void Counter::setCount(int c){
	count = c;
}

int Counter::getCount()const{return count;}
int Counter::getSerialNo()const{return serialNo;}
int Counter::getObjCount(){return objCount;}
int  Counter::IncrementObjCount(){return (++objCount);}

void Counter::operator = (Counter &a){

	this->setCount(a.getCount());

}
Counter& Counter::operator -(){
	this->setCount(this->getCount()*-1);
	return *this;
}
