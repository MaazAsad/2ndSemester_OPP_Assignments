/*
 * Date_test.cpp
 *
 *  Created on: Mar 27, 2019
 *      Author: maaz
 */
#include<iostream>
#include"Counter.h"
#include"Complex.h"
#include"Date.h"
#include"Distance.h"
using namespace std;

int main(void) {
	Date a(1998,5,18);
	Date b(2005,11,21);
	Date c (1998,5,17);
	Date d (1998,5,19);
	Date e(1998,5,18);
	cout << a.toString()<<endl
		 << (a>c) << endl
		 << (a>d) <<endl
		 << (d>c) << endl
		 << (a==e)<< endl
		 << (a!=e) <<endl
		 << (d!=e) << endl;

	Date f = a+24;
	cout << a.toString()<<endl << f.toString();
	return 0;
}




