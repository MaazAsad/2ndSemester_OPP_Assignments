//============================================================================
// Name        : lab9.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C, Ansi-style
//============================================================================

#include<iostream>
#include"Counter.h"
#include"Complex.h"
#include"Date.h"
#include"Distance.h"
using namespace std;

int main(void) {
//	Date a(1998,5,18);
//	Date b(2005,11,21);
//	Date c (1998,5,17);
//	Date d (1998,5,19);
//	Date e(1998,5,18);
//	cout << a.toString()<<endl
//		 << (a>c) << endl
//		 << (a>d) <<endl
//		 << (d>c) << endl
//		 << (a==e)<< endl
//		 << (a!=e) <<endl
//		 << (d!=e) << endl;
//
//	Date f = a+24;
//	cout << a.toString()<<endl << f.toString();




//	Distance h(5,11);
//	Distance w(5,11);
//	Distance y(5,12);
//	Distance z(5,10);
//	Distance a =  w+y;
//	cout << a.getFeet() << ' ' << a.getInches() << endl;
//
//	cout << (h == w)<<endl
//		 << (h<y) << endl
//		 << (h>z) << endl
//		 << y.getFeet()<< ' ' << y.getInches() << endl;
//	h+=w;
//	z-=w;
//	cout << h.getFeet() << ' ' << h.getInches() << endl;
//	cout << z.getFeet() << ' ' << z.getInches() << endl;

	//complex
	Complex a(4,3);
	Complex b(3,4);
	Complex c(5,5);
	Complex d(5,5);
	Complex e = a+b;
	Complex f(0,0);
	Complex g=-a;
	Complex h = a*c;

	cout << (c == d) << endl
		 <<  !f << endl
		 << e.getReal() << ' ' << e.getImaginary()<<endl;

	f.setReal(9);
	f.setImaginary(4);
	cout << f.getReal() << ' ' << f.getImaginary() << endl;

	cout << g.getReal() << ' ' << g.getImaginary() << endl;
	cout << a.getReal() << ' ' << a.getImaginary() << endl;
	cout << h.getReal() << ' ' << h.getImaginary() << endl;

//	Counter a;
//	cout << a.getObjCount() << ' ' << a.getCount()<<endl;
//	Counter b(2);
//	cout << a.getObjCount() << ' ' << b.getObjCount() <<' '<< b.getCount()<<endl;
//	a.setCount(3);
//	Counter c = -a;
//	cout << c.getObjCount() << c.getCount() <<' '<< c.getSerialNo() << endl;
//

	return 0;
}
