#include "Counter.cpp"
#include "Distance.cpp"
#include "Complex.cpp"
#include <gtest/gtest.h>

//-------------------Task1----------------- (1)
TEST(T1, First) {   						

	Counter obj1;
	Counter obj2(5);
	ASSERT_EQ(2,obj1.getObjCount());
	
}

//-------------------Task 1----------------- (2)

TEST(T1, Second) {   						

	Counter obj3(10);
	obj3=-obj3;
	ASSERT_EQ(-10,obj3.getCount());
}

//-------------------Task 1----------------- (2)

TEST(T1, Third) {   						

	Counter obj3(10);
	Counter obj2;
	obj2=-obj3;
	ASSERT_EQ(-10,obj2.getCount());
}


//-------------------Task 2----------------- (3)


TEST(T2, First) {   						

	Distance d1(2,15);
	ASSERT_EQ(3,d1.getFeet());
	
	
}
//-------------------Task 2----------------- (3)


TEST(T2, Second) {   						

	Distance d1(2,15);
	Distance d2(2,15);
	Distance d3=d1+d2;
	ASSERT_EQ(6,d3.getFeet());
	ASSERT_EQ(6,d3.getInches());
	
	
}

//-------------------Task 3----------------- (3)


TEST(T3, First) {   						

	Complex c1;
    	ASSERT_EQ(0.0, c1.getReal());
    	ASSERT_EQ(0.0, c1.getImaginary());
    
	
	
}


//-------------------Task3----------------- (4)


TEST(T3, Second) {   						

	Complex c1(5.0,6.0);
    	Complex c2(7.0,8.0);
    	Complex c3 = c1+c2; 
    	ASSERT_EQ(12.0, c3.getReal());
    	ASSERT_EQ(14.0, c3.getImaginary());
}
//-------------------Task3----------------- (4)


TEST(T3, Third) {   						

	Complex c1(5.0,6.0);
    	Complex c2(7.0,8.0);
    	Complex c3 = c1*c2;
    	ASSERT_EQ(-13.0, c3.getReal());
    	ASSERT_EQ(82.0, c3.getImaginary());
}
int main(int argc, char **argv) {

    testing::InitGoogleTest(&argc, argv);

    return RUN_ALL_TESTS();
}

