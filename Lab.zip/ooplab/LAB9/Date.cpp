/*
 * Date.cpp
 *
 *  Created on: Mar 26, 2019
 *      Author: maaz
 */

#include "Date.h"
#include <string>

Date::Date(int year, int month, int day) {
	mYear = year;
	mMonth = month;
	mDay = day;

}

int Date::getDay()const{
	return mDay;
}
int Date::getMonth()const{return mMonth;}
int Date::getYear()const{return mYear;}

bool Date::isLeapYear()const{
	if(mYear%4){
		return false;
	}
	return true;
}

void Date::operator=(const Date &obj){
	this->mDay = obj.getDay();
	this->mMonth = obj.getMonth();
	this->mYear = obj.getYear();

}

bool Date::operator>(const Date &obj){
	if(mYear > obj.getYear())
		return true;
	else if(mYear == obj.getYear() && mMonth > obj.getMonth())
		return true;
	else if(mYear == obj.getYear() && mMonth == obj.getMonth() && mDay > obj.getDay())
		return true;
	return false;
}
bool Date::operator>=(const Date &obj){
	if(mYear == obj.getYear() && mMonth == obj.getMonth() && mDay == obj.getDay())
		return true;
	else if(mYear > obj.getYear())
		return true;
	else if(mYear == obj.getYear() && mMonth > obj.getMonth())
		return true;
	else if(mYear == obj.getYear() && mMonth == obj.getMonth() && mDay > obj.getDay())
		return true;
	return false;
}
bool Date::operator<(const Date &obj){
	if(mYear < obj.getYear())
			return true;
		else if(mYear == obj.getYear() && mMonth < obj.getMonth())
			return true;
		else if(mYear == obj.getYear() && mMonth == obj.getMonth() && mDay <obj.getDay())
			return true;
		return false;
}
bool Date::operator<=(const Date &obj){
	if(mYear == obj.getYear() && mMonth == obj.getMonth() && mDay == obj.getDay())
		return true;
	else if(mYear < obj.getYear())
		return true;
	else if(mYear == obj.getYear() && mMonth < obj.getMonth())
		return true;
	else if(mYear == obj.getYear() && mMonth == obj.getMonth() && mDay < obj.getDay())
		return true;
	return false;
}
bool Date::operator==(const Date &obj){
	if(mYear == obj.getYear() && mMonth == obj.getMonth() && mDay == obj.getDay())
			return true;
	return false;
}
bool Date::operator!=(const Date &obj){
	return !(*this == obj);
}
Date Date::operator+(int a){
	Date temp(mYear, mMonth, mDay);
	while(a>31){
		switch(mMonth){
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			a-=31;
			mMonth+=1;
			mDay =1;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			a-=30;
			mMonth +=1;
			mDay =1;
			break;
		case 2:
			if(isLeapYear()){
				a-=29;
				mMonth +=1;
				mDay =1;

			}
			else{
				a-=28;
				mMonth +=1;
				mDay =1;
			}
			break;
		}
		if(mMonth>12){
			mMonth =1;
			mYear +=1;
		}
	}
	mDay +=a;
	return *this;
}
Date Date::operator-(int a){

	return *this;
}
Date Date::operator+(Date &a){

	int tempm = a.getMonth();
	int tempd = a.getDay();

	mYear += a.getYear();
	mMonth += tempm;
	while(mMonth>12){
		mMonth-=12;
		mYear +=1;
	}
	*this = *this + tempd;

	return *this;

}
Date Date::operator-(Date &a){

	return *this;
}

std::string Date::toString(){
	std::string temp;
	temp+= std::to_string(mYear);
	temp +='/';
	temp += std::to_string(mMonth);
	temp +='/';
	temp += std::to_string(mDay);
	return temp;
}

