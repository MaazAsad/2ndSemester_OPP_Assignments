/*
 * Counter.h
 *
 *  Created on: Mar 26, 2019
 *      Author: maaz
 */

#ifndef COUNTER_H_
#define COUNTER_H_

class Counter {
	int count,serialNo;
	static int objCount;

public:
	Counter();
	Counter(int c);
	~Counter();
	void setCount(int c);
	int getCount()const;
	int getSerialNo()const;
	 int getObjCount();
	 int  IncrementObjCount();
	void operator =(Counter &a);
	Counter& operator -();

};

#endif /* COUNTER_H_ */
