/*
 * Distance.cpp
 *
 *  Created on: Mar 26, 2019
 *      Author: maaz
 */

#include "Distance.h"

Distance::Distance(int f, int i) {
	feet =f;
	inches = i;
	while(inches>11){
		inches-=12;
		++feet;
	}

}
Distance::~Distance() {
	// TODO Auto-generated destructor stub
}

bool Distance::setFeet(int f){
	feet =f; return true;
}
bool Distance::setInches(int i){
	inches = i;
	while(inches>11){
		inches-=12;
		++feet;
	}
	return true;
}
int Distance::getFeet()const{
	return feet;
}
int Distance::getInches()const {
	return inches;
}

Distance Distance::operator +(const Distance &obj){
	feet += obj.getFeet();
	inches += obj.getInches();

	while(inches>11){
			inches-=12;
			++feet;
		}
	return *this;

}

Distance Distance::operator-(const Distance &obj){
	feet -= obj.getFeet();
	inches -= obj.getInches();

	while(inches<0){
			inches+=12;
			--feet;
		}
	return *this;
}

void Distance::operator +=(const Distance &obj){
	*this = *this + obj;


}
void Distance::operator-=(const Distance &obj){
	*this = *this - obj;
}

bool Distance::operator > (const Distance &obj){
	if(feet> obj.getFeet()){
		return true;
	}
	else if(feet == obj.getFeet() && inches > obj.getInches()){
		return true;
	}
	return false;
}

bool Distance::operator < (const Distance &obj){
	if(feet< obj.getFeet()){
		return true;
	}
	else if(feet == obj.getFeet() && inches < obj.getInches()){
		return true;
	}
	return false;
}
bool Distance::operator == (const Distance &obj){
	if(feet == obj.getFeet() && inches == obj.getInches())
		return true;
	return false;
}

const Distance Distance::operator=(const Distance &obj){
	feet = obj.getFeet();
	inches = obj.getInches();
	return *this;
}

