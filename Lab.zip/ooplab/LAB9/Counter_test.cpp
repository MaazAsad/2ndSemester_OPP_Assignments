/*
 * Counter_test.cpp
 *
 *  Created on: Mar 27, 2019
 *      Author: maaz
 */
#include<iostream>
#include"Counter.h"
using namespace std;

int main(void) {
	Counter a;
	cout << a.getObjCount() << ' ' << a.getCount()<<endl;
	Counter b(2);
	cout << a.getObjCount() << ' ' << b.getObjCount() <<' '<< b.getCount()<<endl;
	a.setCount(3);
	Counter c = -a;
	cout << c.getObjCount() << c.getCount() <<' '<< c.getSerialNo() << endl;


	return 0;
}




