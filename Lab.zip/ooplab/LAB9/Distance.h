/*
 * Distance.h
 *
 *  Created on: Mar 26, 2019
 *      Author: maaz
 */

#ifndef DISTANCE_H_
#define DISTANCE_H_

class Distance {
	int feet,inches;
public:
	Distance(int f, int i);
	virtual ~Distance();
	bool setFeet(int f);
	bool setInches(int i);
	int getFeet()const;
	int getInches()const;

	Distance operator+(const Distance &obj);
	Distance operator-(const Distance &obj);

	void operator +=(const Distance &obj);
	void operator-=(const Distance &obj);

	bool operator>(const Distance &obj);
	bool operator < (const Distance &obj);
	bool operator == (const Distance &obj);

	const Distance operator=(const Distance &obj);
};

#endif /* DISTANCE_H_ */
