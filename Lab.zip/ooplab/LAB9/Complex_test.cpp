/*
 * Complex_test.cpp
 *
 *  Created on: Mar 27, 2019
 *      Author: maaz
 */

#include<iostream>
#include"Complex.h"

using namespace std;
int main(void) {

	Complex a(4,3);
	Complex b(3,4);
	Complex c(5,5);
	Complex d(5,5);
	Complex e = a+b;
	Complex f(0,0);
	Complex g=-a;
	Complex h = a*c;

	cout << (c == d) << endl
		 <<  !f << endl
		 << e.getReal() << ' ' << e.getImaginary()<<endl;

	f.setReal(9);
	f.setImaginary(4);
	cout << f.getReal() << ' ' << f.getImaginary() << endl;

	cout << g.getReal() << ' ' << g.getImaginary() << endl;
	cout << a.getReal() << ' ' << a.getImaginary() << endl;
	cout << h.getReal() << ' ' << h.getImaginary() << endl;
	return 0;
}

