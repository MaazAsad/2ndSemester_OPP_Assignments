#include "submission.cpp"
#include <gtest/gtest.h>
#include <string>
#include <iostream>
using namespace std;
//*****************Task 1

 TEST(SaleClass, Default_Parameter) {
	  Sale s(3);
	 EXPECT_DOUBLE_EQ(3, s.getItemCost());
	 EXPECT_DOUBLE_EQ(0.05, s.getTaxRate());
	 EXPECT_DOUBLE_EQ(0.15, s.getTax());
	 EXPECT_DOUBLE_EQ(3.15, s.getTotal());

}

 TEST(SaleClass, Parameterized_Constructor) {
	double cost=5;
	double tax=0.07;
	double totalTax=0.35;
	double totalcost=5.35;

	 Sale s1(cost,tax);
	 EXPECT_DOUBLE_EQ(cost, s1.getItemCost());
	 EXPECT_DOUBLE_EQ(tax, s1.getTaxRate());
	 EXPECT_DOUBLE_EQ(totalTax, s1.getTax());
	 EXPECT_DOUBLE_EQ(totalcost, s1.getTotal());
}


  //*****************Task 2
 TEST(BoxClass, Func_getVolume) {
	double l=2;
	double b=3;
	double h=4;
	Box box;
	box.setLength(l);
	box.setBreadth(b);
	box.setHeight(h);
	EXPECT_DOUBLE_EQ(24, box.getVolume());
 }

 TEST(BoxClass, Func_getSurfaceArea) {
	double l=2;
	double b=3;
	double h=4;
	Box box;
	box.setLength(l);
	box.setBreadth(b);
	box.setHeight(h);
	EXPECT_DOUBLE_EQ(52, box.getSurfaceArea());
 }

 // TEST(BoxClass,UpdateFunc){
	// Box box;
 //    	Box arr[3];
 //
 //  ASSERT_TRUE(box.update(arr,5,2,5));
 //  EXPECT_DOUBLE_EQ(5, arr[2].getHeight());
 // }

  //*****************Task 3
  TEST(ContainerClass,Func_isFull)
 {
	 Container c(2);
	 c.insert(1);
	 c.insert(3);
	 ASSERT_TRUE(c.isFull());
}

  TEST(ContainerClass,Func_search)
 {
	 Container c(2);
	 c.insert(1);
	 c.insert(3);
	 //Search
	 ASSERT_TRUE(c.search(3));
	 ASSERT_FALSE(c.search(36));
}

  TEST(ContainerClass,Func_Remove)
 {
	 Container c(2);
	 c.insert(1);
	 c.insert(3);
	 ASSERT_TRUE(c.search(3));
	 c.remove(3);
	ASSERT_FALSE(c.search(3));

  }


//************************Task 4


  TEST(CoffeeShotsClass,Func_getSize)
  {
	  //getSize()
	  coffeeShots c(20,55,"latte");
	  EXPECT_EQ('m',c.getSize());
  }

  TEST(CoffeeShotsClass,Func_SpillOver)
  {
	  //spillOver()
	  coffeeShots c(20,55,"latte");
	  EXPECT_EQ(50,c.spillOver(5));


 }

  TEST(CoffeeShotsClass,Func_upSize)
  {
	  coffeeShots c(20,50,"latte");
 	  c.upSize();
	  EXPECT_EQ('m',c.getSize());


  }

// //*************************Task 5
TEST(IntegerListClass,Func_IsValid)
  {
	  IntegerList list(4);

	  ASSERT_TRUE(list.isValid(2));
	  ASSERT_FALSE(list.isValid(-2));
  }

  TEST(IntegerListClass,Func_get_setElement)
  {
	  IntegerList list(4);

	list.setElement(0, 3);
	EXPECT_EQ(3,list.getElement(0) );
  }


int main(int argc, char **argv) {

    testing::InitGoogleTest(&argc, argv);

    return RUN_ALL_TESTS();
}
