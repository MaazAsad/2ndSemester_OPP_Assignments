#include<string>
#include <iostream>
using namespace std;
///////Task 1////////////////////////////////////////////////
class Sale{
	double itemCost; // Cost of the item
	double taxRate; // Sales tax rate
public:
     Sale():itemCost(0),taxRate(0){}

	 Sale(double cost, double rate = 0.05)
	 {
		 itemCost = cost;
		 taxRate = rate;
	 }

	 double getItemCost(){
		 return itemCost;
	 }

	 double getTaxRate(){
		 return taxRate;
	 }

	 double getTax(){
		 return itemCost * taxRate;
	 }

	 double getTotal(){
		 return itemCost + getTax();
	 }
};

 ////Task 2///////////////////////////////////////////////////
 class Box{
	int Blen,Bhe,Bbr;
	string color,material;
public:
	 void setLength(double l){
		 Blen = l;
	 }

	 void setBreadth(double b){
		 Bbr = b;
	 }

	 void setHeight(double h){
		 Bhe = h;
	 }

	 double getLength(){
		 return Blen;
	 }

	 double getHeight(){
		 return Bhe;
	 }

	 double getBreadth(){
		 return Bbr;
	 }

	 string getColor(){
		 return color;
	 }

	void setColor(string c){
		color =c;
	 }

	string getMaterial(){
		return material;
	 }
	void setMaterial(string m){
		material = m;
	}

	double getVolume(){
		return Blen* Bhe * Bbr;
	}

	double getSurfaceArea(){
		return 2*(Blen*Bhe + Blen*Bbr + Bhe*Bbr);
	 }

	 void print(){
		 cout << Blen <<endl<<
				 Bbr <<endl<<
				 Bhe <<endl<<
				 material << endl <<
				 color << endl <<
				 getVolume() << endl<<
				 getSurfaceArea()<<endl;

	 }

};
bool update(Box b[], int size, int index, double height){
	if(index<size){
		b[index].setHeight(height);
			 return true;
	}
	return false;
}

////Task 3////////////////////////////////////////////////////////
class Container{
	int *values;
	int capacity,counter;

public:
	Container(int c){
		capacity = c;
		counter =-1;
		values = new int[capacity];
	}


	bool isFull(){
		return (counter == capacity-1)?true:false;
	}

	void insert(int val){
		if(!isFull()){
			counter++;
			values[counter] = val;
		}
	}

	bool search( int  val){
		for(int i=0; i<= counter; i++){
			if(values[i] == val)
				return true;
		}
		return false;
	}

	void remove(int val){
		for(int i=0; i<= counter; i++){
			if(values[i] == val){
				for(int j=i; j<counter;j++){
					values[j] = values[j+1];
				}
				break;
			}
		}

	}

	void Print( ){
		for(int i=0; i<=counter;i++){
			cout << values[i] << endl;
		}
	}


};


//Task 4/////////////////////////////////////////////////////////
class coffeeShots{
private:
	double price;
	float vol;
	string type;
	char size;

public:
	coffeeShots(double p,float v,string t="latte"){
		price = p;
		vol = v;
		type = t;
		if(v>=0 && v<50)
			size = 's';
		else if(v>50 && v<=75)
			size = 'm';
		else if(v>75)
			size = 'l';
	 }

	 void setPrice(double price){
		 this->price = price;
	 }

	 double getPrice(){
		 return price;
	 }

	 float getVolume(){
		 return vol;
	 }

	 string getType(){
		 return type;
	 }

	 char getSize(){
		 return size;
	 }

	 void upSize(){
		 vol+=5;
		 if(vol>=0 && vol<50)
		 			size = 's';
		 		else if(vol>50 && vol<=75)
		 			size = 'm';
		 		else if(vol>75)
		 			size = 'l';
		 price+=5;
	 }

	 float spillOver(float vol){
		 this->vol -= vol;
		 return this->vol;
	 }

	 void print(){
		 cout << type << endl<<
				 size  << endl<<
				 vol << endl<<
				 price<<endl;

	 }

};
coffeeShots& createMyCofee(){
	double price;
	float vol;
	string type;
	cout << "Enter Type: ";
	getline(cin,type);
	cout << "Enter Volume: ";
	cin >> vol;
	cout << "Enter Price: ";
	cin >> price;

	coffeeShots x(price,vol,type);
	return x;
}


////Task 5////////////////////////////////////////////////////


class IntegerList{
	int *list;
	int numElements;
public:
	 IntegerList(int x){
		 list = new int[x];
		 for(int i=0; i<x; i++)
			 list[i] = 0;
		 numElements = x;

	  }

	 ~IntegerList(){
		 delete []list;
	 }

	  bool isValid(int sub){
		  if(sub >=0 && sub <numElements)
			  return true;
		  return false;
	  }

	 void setElement(int val, int index){
		 if(isValid(index)){
			 list[index] = val;
		 }
	 }

	 int getElement(int index){
		 if(isValid(index)){
			 return list[index];
		 }
		 return -1;
	 }
};

//
//
// ////Task 6////////////////////////////////////////////////////
class Car{
	string regNo;
	int entryTime, exitTime;
public:
	Car(){
		regNo = "\0";
		entryTime = exitTime = 0;
	}
	void setReg(string a){
		regNo = a;
	}
	bool setEntry(int a){
		if(a>0 && a<2359){
			entryTime = a;
			return true;
		}
		return false;
	}
	bool setExit(int a){
		if(a > entryTime && a<2359){
			exitTime = a;
			return true;
		}
		return false;
	}

	string getReg(){return regNo;}
	int getEntry(){return entryTime;}
	int getExit(){return exitTime;}
};
class ParkingGarage {
	int noOfOccupied;
	Car * carPointer;
	double amountCollected;
	int capacity;
public:
	ParkingGarage(){
		noOfOccupied = 0;
		capacity =5;
		carPointer = new Car[5];
		amountCollected = 0;
	}

	ParkingGarage(int c){
			noOfOccupied = 0;
			capacity = c;
			carPointer = new Car[c];
			amountCollected = 0;
	}
	bool IsFull(){
		if(noOfOccupied<capacity)
			return false;
		return true;
	}

	int getRemainingCapacity(){
		return capacity-noOfOccupied;
	}
	double getAmountCollected(){
		return amountCollected;
	}

	bool ParkCar(const string &regnNumber,int entryTime){
		if(!IsFull()){
			carPointer[noOfOccupied].setReg(regnNumber);
			carPointer[noOfOccupied].setEntry(entryTime);
			noOfOccupied++;
			return true;
		}
		return false;
	}

	void RemoveCar(string regno){
			int i, currentime,t1h,t1m,t2h,t2m;
			float hours=0;
			for(i=0; carPointer[i].getReg() != regno; i++);
			cout << "Enter Time:";
			cin >> currentime;
			t1m = currentime%100;
			t1h = (currentime-t1m)/100;

			t2m = carPointer[i].getEntry()%100;
			t2h = (carPointer[i].getEntry()-t2m)/100;

			hours = t2h-t1h;

			noOfOccupied--;
			amountCollected+= (hours*20);

}
};

//  ////Task 7///////////////////////////////////////////////////

class Student{
	int rollNo,batch;
	string name,address;
public:
	Student(){
		name =address = "\0";
		rollNo= batch = 0;
	}
	Student(int r,  string &n,  string &ad, int b){
		name =n;
		address = ad;
		batch =b;
		rollNo = r;
	}

	void setName(string n){
		name =n;
	}
	string getName(){
		return name;
	}

	void setAddress(string add){
		address = add;
	}
	string getAddress(){
		return address;
	}

	void setRoll(int r){
		rollNo = r;
	}

	int getRoll(){
		return rollNo;
	}

	void setBatch(int batchNo){
		batch = batchNo;
	}
	int getBatch(){
		return batch;
	}
};
class Section{
	string sectionName;
	Student *studentPtr;
	int sectionStrenght,currentStudent;
public:
	Section(){
		sectionName = "\0";
		studentPtr = NULL;
		sectionStrenght = currentStudent = 0;
	}
	Section (int s , char name){
		sectionName = name;
		studentPtr = new Student[s];
		sectionStrenght = s;
		currentStudent=0;

	}

	bool setSectionName(string name){
		int i;
		for(i=0; name[i]!='\0';i++);
		if(i<50){
			sectionName = name;
			return true;
		}
		else
			return false;
	}

	bool setSectionStrength(int num){
		if(num>0){
			sectionStrenght = num;
			return true;
		}
		return false;

	}

	string getSectionName(){
		return sectionName;
	}

	int getSectionStrength(){
		return sectionStrenght;
	}
	int getCurrentStudent(){
		return currentStudent;
	}

	bool addStudent(int r, string &n, string &ad, int b){
		if(currentStudent < sectionStrenght){
			studentPtr[currentStudent].setAddress(ad);
			studentPtr[currentStudent].setBatch(b);
			studentPtr[currentStudent].setName(n);
			studentPtr[currentStudent].setRoll(r);
			currentStudent++;
			return true;
		}
		return false;
	}

	bool deleteStudent(){
		if(currentStudent>0){
			currentStudent-=1;
			return true;
		}
		return false;
	}

	string SearchStudent(int r){
		for(int i=0;i<=currentStudent; i++){
			if(studentPtr[i].getRoll() == r){
				return studentPtr[i].getName();
			}

		}
		return "Not Found";
	}

};
